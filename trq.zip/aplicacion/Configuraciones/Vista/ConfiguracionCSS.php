<?php

namespace Configuracion\Vista;

class ConfiguracionCSS
{

    public static function data(): array
    {
        return [
            'version' => '0.0-' . rand(0, PHP_INT_MAX), // Random para depurar
        ];
    }

}
