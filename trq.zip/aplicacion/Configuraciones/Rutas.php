<?php

namespace Configuracion;

use Controlador;
use Gof\Gestor\Enrutador\Rut\Interfaz\Ruta;
use Inter;

/**
 * Define las rutas accesibles
 *
 * @package Margof\Configuracion
 */
class Rutas
{

    /**
     * Constructor
     *
     * Recibe una instancia de la ruta padre donde agregar las rutas hijas.
     *
     * @param Ruta $rutas
     */
    public function __construct(Ruta $rutas)
    {
        $this->paginaInexistente($rutas);
        $this->paginaPrincipal($rutas);
        $this->paginaPerfil($rutas);
    }

    public function paginaInexistente(Ruta $rutas)
    {
        $rutas->inexistente(Controlador\E404::class);
    }

    public function paginaPrincipal(Ruta $rutas)
    {
        $index = $rutas->agregar('', Controlador\Index::class);
        $index->alias('index');
    }

    public function paginaPerfil(Ruta $rutas)
    {
        $perfil = $rutas->agregar('perfil', Controlador\Perfil\Index::class);

        $registro = $perfil->agregar('registrar', Controlador\Perfil\Registrar::class);
        $registro->inters()->agregar(Inter\Cuenta\InterRedireccionarSiEstaAutenticado::class);

        $ingreso = $perfil->agregar('ingresar', Controlador\Perfil\Ingresar::class);
        $ingreso->inters()->agregar(Inter\Cuenta\InterRedireccionarSiEstaAutenticado::class);

        $perfil->agregar('cerrar', Controlador\Perfil\Cerrar::class);
    }

}
