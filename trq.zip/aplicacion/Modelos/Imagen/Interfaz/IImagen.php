<?php

namespace Imagen\Interfaz;

use Contrato\Componente\IId;

/**
 * Interfaz para acceder a una imagen
 *
 * @package Imagen\Interfaz
 */
interface IImagen extends IId
{

    /**
     * Obtiene el nombre del archivo
     *
     * @return string
     */
    public function nombre(): string;

}
