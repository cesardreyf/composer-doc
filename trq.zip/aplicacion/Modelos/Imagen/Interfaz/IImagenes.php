<?php

namespace Imagen\Interfaz;

/**
 * Interfaz de acceso a un contenedor de imágenes
 *
 * @package Imagen\Interfaz
 */
interface IImagenes
{

    /**
     * Obtiene la lista de imágenes
     *
     * @return IImagen[]
     */
    public function lista(): array;

}
