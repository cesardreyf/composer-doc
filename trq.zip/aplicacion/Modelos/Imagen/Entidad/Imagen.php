<?php

namespace Imagen\Entidad;

use Imagen\Interfaz\IImagen;

/**
 * Entidad que representa una imagen
 *
 * @package Imagen\Entidad
 */
class Imagen implements IImagen
{

    /**
     * Constructor
     *
     * @param int    $id     Identificador de la imagen
     * @param string $nombre Nombre completo del archivo
     */
    public function __construct(private int $id, private string $nombre)
    {
    }

    /**
     * Obtiene el id de la imagen
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * Obtiene el nombre completo de la imagen
     *
     * @return string
     */
    public function nombre(): string
    {
        return $this->nombre;
    }

}
