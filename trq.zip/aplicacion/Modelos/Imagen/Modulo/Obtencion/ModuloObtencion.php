<?php

namespace Imagen\Modulo\Obtencion;

use Imagen\Excepcion\ExcepcionImagenInexistente;
use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;
use Imagen\Modulo\Obtencion\Interfaz\IRepositorioObtencion;

/**
 * Módulo de obtención de imágenes
 *
 * @package Imagen\Modulo\Obtencion
 */
class ModuloObtencion
{

    /**
     * Constructor
     *
     * @param IRepositorioObtencion $repositorio
     */
    public function __construct(private IRepositorioObtencion $repositorio)
    {
    }

    /**
     * Obtiene una imagen del repositorio segun el id especificado
     *
     * @param int $id Id de la imagen a obtener
     *
     * @return IImagen
     *
     * @throws ExcepcionImagenInexistente si no existe la imagen solicitada en el repositorio
     */
    public function obtenerImagenSegunId(int $id): IImagen
    {
        if( !$this->repositorio->imagenExisteSegunId($id) ) {
            throw new ExcepcionImagenInexistente("No existe ninguna imagen con el id {$id}");
        }
        return $this->repositorio->obtenerImagenSegunId($id);
    }

    /**
     * Obtiene una lista de imágenes del repositorio según los ID's especificados
     *
     * @param int $id
     * @param int ...$masIds
     *
     * @return IImagenes
     *
     * @throws ExcepcionImagenInexistente si úno o más imágenes no existene en el repositorio
     */
    public function obtenerImagenesSegunId(int $id, int ...$masIds): IImagenes
    {
        $imagenesInexistentes = $this->repositorio->consultarExistenciaDeImagenesSegunId($id, ...$masIds);
        if( !empty($imagenesInexistentes) ) {
            $listaDeImagenes = implode(', ', $imagenesInexistentes);
            throw new ExcepcionImagenInexistente("Las siguientes imágenes no existen en el repositorio: {$listaDeImagenes}");
        }
        return $this->repositorio->obtenerImagenesSegunId($id, ...$masIds);
    }

}
