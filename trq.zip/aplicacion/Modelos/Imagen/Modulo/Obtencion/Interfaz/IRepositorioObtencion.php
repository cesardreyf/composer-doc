<?php

namespace Imagen\Modulo\Obtencion\Interfaz;

use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;

/**
 * Interfaz de acceso a un repositorio de obtención de imágenes
 *
 * @package Imagen\Modulo\Obtencion\Interfaz
 */
interface IRepositorioObtencion
{

    /**
     * Verifica si existe la imagen según su id
     *
     * @param int $id
     *
     * @return bool
     */
    public function imagenExisteSegunId(int $id): bool;

    /**
     * Verifica si existen las imágenes segun la lista de id solicitadas
     *
     * En caso de existir todas devuelve un array vacío, caso contrario se
     * devuelve un array con los id que no existen en el repositorio.
     *
     * @param int $id
     * @param int ...$masIds
     *
     * @return int[]
     */
    public function consultarExistenciaDeImagenesSegunId(int $id, int ...$masIds): array;

    /**
     * Obtiene la imagen del repositorio según su id
     *
     * @param int $id
     *
     * @return IImagen
     *
     * @throws \Throwable en caso de errores
     */
    public function obtenerImagenSegunId(int $id): IImagen;

    /**
     * Obtiene una lista de imágenes
     *
     * @param int $id
     * @param int ...$masIds
     *
     * @return IImagenes
     */
    public function obtenerImagenesSegunId(int $id, int ...$masIds): IImagenes;

}
