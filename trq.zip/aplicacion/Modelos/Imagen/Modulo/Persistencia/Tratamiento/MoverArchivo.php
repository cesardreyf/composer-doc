<?php

namespace Imagen\Modulo\Persistencia\Tratamiento;

use Contrato\Tratamiento\ITratable;
use Imagen\Excepcion\ExcepcionErrorAlAlmacenarImagen;

/**
 * Componente que mueve el archivo subido a la carpeta indicada
 *
 * @package Imagen\Modulo\Persistencia\Tratamiento
 */
class MoverArchivo implements ITratable
{

    /**
     * Constructor
     *
     * @param string $nombre Nombre del archivo
     * @param string &$ruta Ruta del archivo a mover
     * @param string $carpetaDestino Ruta de la carpeta donde se moverá
     */
    public function __construct(private string $nombre, private string &$ruta, private string $carpetaDestino)
    {
    }

    /**
     * Mueve el archivo a la carpeta destino otorgándole un nombre aleatorio
     *
     * Si la operación se ejecuta correctamente se cambia el valor de la
     * propiedad $ruta por la nueva donde se movió la imagen.
     *
     * @see MoverArchivo::obtenerNombreAleatorio()
     *
     * @throws ExcepcionErrorAlAlmacenarImagen si no se pudo mover el archivo
     */
    public function tratar()
    {
        $rutaOrigen = $this->ruta;
        $extension = pathinfo($this->nombre, PATHINFO_EXTENSION);
        $rutaDestino = $this->carpetaDestino . $this->obtenerNombreAleatorio() . ".{$extension}";

        if( !move_uploaded_file($rutaOrigen, $rutaDestino) ) {
            throw new ExcepcionErrorAlAlmacenarImagen($rutaOrigen, $rutaDestino);
        }

        $this->ruta = $rutaDestino;
    }

    public function obtenerNombreAleatorio(): string
    {
        return uniqid() . '_' . bin2hex(random_bytes(16));
    }

}
