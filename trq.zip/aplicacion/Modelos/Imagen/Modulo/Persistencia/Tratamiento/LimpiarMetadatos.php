<?php

namespace Imagen\Modulo\Persistencia\Tratamiento;

use Contrato\Tratamiento\ITratable;
use Gmagick;

/**
 * Limpia los metadatos de la imagen
 *
 * @package Imagen\Modulo\Persistencia\Tratamiento
 */
class LimpiarMetadatos implements ITratable
{

    /**
     * Constructor
     *
     * @param string &$ruta Ruta del archivo
     */
    public function __construct(private string &$ruta)
    {
    }

    /**
     * Elimina los metadatos de la imagen
     *
     * Remueve los datos exif que existan en la imagen.
     *
     * @see MoverArchivo::obtenerNombreAleatorio()
     *
     * @throws ExcepcionErrorAlAlmacenarImagen si no se pudo mover el archivo
     */
    public function tratar()
    {
        $imagen = new Gmagick();
        $imagen->readImage($this->ruta);
        // $imagen->setImageFormat('JPG');
        $imagen->stripImage();
        $imagen->profileImage('*', '');
        $imagen->writeImage($this->ruta);
        $imagen->destroy();
    }

}
