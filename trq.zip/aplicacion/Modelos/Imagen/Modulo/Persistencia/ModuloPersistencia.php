<?php

namespace Imagen\Modulo\Persistencia;

use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;
use Imagen\Modulo\Persistencia\Excepcion\ExcepcionImagenesNoPersistidos;
use Imagen\Modulo\Persistencia\Excepcion\ExcepcionImagenNoPersistido;
use Imagen\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;

/**
 * Módulo de persistencia de imágenes
 *
 * @package Imagen\Modulo\Persistencia
 */
class ModuloPersistencia
{

    /**
     * Constructor
     *
     * @param IRepositorioPersistencia $repositorio
     */
    public function __construct(private IRepositorioPersistencia $repositorio)
    {
    }

    /**
     * Persiste una imagen en el repositorio
     *
     * @param IImagen $imagen Imagen a persistir
     *
     * @throws ExcepcionImagenNoPersistido si el repositorio devuelve false al intentar persistir la imagen
     */
    public function persistirImagen(IImagen $imagen)
    {
        if( !$this->repositorio->persistirImagen($imagen) ) {
            throw new ExcepcionImagenNoPersistido($imagen);
        }
    }

    /**
     * Persiste las imágenes en el repositorio
     *
     * @param IImagenes $imagenes Imágenes a persitir
     *
     * @throws ExcepcionImagenesNoPersistidos si el repositorio devuelve false al intentar persistir las imágenes
     */
    public function persistirImagenes(IImagenes $imagenes)
    {
        if( !$this->repositorio->persistirImagenes($imagenes) ) {
            throw new ExcepcionImagenesNoPersistidos($imagenes);
        }
    }

}
