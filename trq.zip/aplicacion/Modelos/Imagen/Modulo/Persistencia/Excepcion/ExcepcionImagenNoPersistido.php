<?php

namespace Imagen\Modulo\Persistencia\Excepcion;

use Imagen\Interfaz\IImagen;

/**
 * Excepcion lanzado cuando el repositorio devuelve false al persistir la imagen
 *
 * @package Imagen\Modulo\Persistencia\Excepcion
 */
class ExcepcionImagenNoPersistido extends ExcepcionDePersistencia
{

    /**
     * Constructor
     *
     * @param IImagen $imagen
     */
    public function __construct(public readonly IImagen $imagen)
    {
        parent::__construct('No se pudo persistir correctamente la imagen');
    }

}
