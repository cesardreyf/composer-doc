<?php

namespace Imagen\Modulo\Persistencia\Excepcion;

use Imagen\Excepcion\Excepcion;

/**
 * Excepción del que extienden las excepciones relacionadas con el módulo de persistencia
 *
 * @package Imagen\Modulo\Persistencia\Excepcion
 */
class ExcepcionDePersistencia extends Excepcion
{
}
