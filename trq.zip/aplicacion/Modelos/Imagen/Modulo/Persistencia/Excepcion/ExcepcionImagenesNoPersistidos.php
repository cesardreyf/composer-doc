<?php

namespace Imagen\Modulo\Persistencia\Excepcion;

use Imagen\Interfaz\IImagenes;

/**
 * Excepcion lanzado cuando el repositorio devuelve false al persistir las imágenes
 *
 * @package Imagen\Modulo\Persistencia\Excepcion
 */
class ExcepcionImagenesNoPersistidos extends ExcepcionDePersistencia
{

    /**
     * Constructor
     *
     * @param IImagenes $imagenes
     */
    public function __construct(public readonly IImagenes $imagenes)
    {
        parent::__construct('No se pudieron persistir la lista de imágenes');
    }

}
