<?php

namespace Imagen\Modulo\Persistencia\Entidad;

use Componente\Archivo\ArchivoSubido;
use Componente\Extension\ExtensionContenedorDeComponentes;
use Contrato\Componente\IEntidad;
use Imagen\Interfaz\IImagen;
use Imagen\Modulo\Persistencia\Propiedad\ArchivoImagen;

/**
 * Entidad que representa una imagen persistible
 *
 * La entidad puede ser validada y se le pueden aplicar tratamiento a sus
 * propiedades para su persistencia.
 *
 * @package Imagen\Modulo\Persistencia\Entidad
 */
class ImagenPersistible implements IImagen, IEntidad
{
    use ExtensionContenedorDeComponentes;

    /**
     * Constructor
     *
     * @param int           $id      Identificador numérico de la imagen
     * @param ArchivoImagen $archivo Propiedad del archivo que representa la imagen
     */
    public function __construct(private int $id, private ArchivoImagen $archivo)
    {
        $this->agregarComponente($archivo);
    }

    /**
     * Obtiene el id
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * Obtiene el nombre completo de la imagen
     *
     * @return string
     */
    public function nombre(): string
    {
        return $this->archivo->nombre();
    }

    /**
     * Edita el id de la imagen
     *
     * @param int $id
     */
    public function editarId(int $id)
    {
        $this->id = $id;
    }

}
