<?php

namespace Imagen\Modulo\Persistencia\Entidad;

use Componente\Extension\ExtensionContenedorDeComponentes;
use Contrato\Componente\IEntidad;
use Imagen\Interfaz\IImagen;
use Imagen\Modulo\Persistencia\Propiedad\ImagenSubido;

class Imagen implements IImagen, IEntidad
{
    use ExtensionContenedorDeComponentes;

    public function __construct(private int $id, private ImagenSubido $archivo)
    {
        $this->agregarComponente($archivo);
    }

    public function id(): int
    {
        return $this->id;
    }

    public function ruta(): string
    {
        return $this->archivo->ruta();
    }

}
