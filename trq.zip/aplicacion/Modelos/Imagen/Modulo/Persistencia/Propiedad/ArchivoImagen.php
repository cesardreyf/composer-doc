<?php

namespace Imagen\Modulo\Persistencia\Propiedad;

use Componente\Extension\ExtensionComponenteTratable;
use Componente\Extension\ExtensionComponenteValidable;
use Componente\Tratamiento\Archivo\Imagen\LimpiarMetadatos;
use Componente\Tratamiento\Archivo\MoverArchivo;
use Componente\Validacion\Archivo\Imagen\ValidarImagen;
use Componente\Validacion\Archivo\ValidarFile;
use Contrato\Componente\IComponente;
use Contrato\Tratamiento\ITratable;
use Contrato\Validacion\IValidable;
use Gof\Interfaz\Archivos\Archivo;
use Gof\Interfaz\Archivos\Carpeta;

class ArchivoImagen implements IComponente, IValidable, ITratable, Archivo
{
    use ExtensionComponenteValidable;
    use ExtensionComponenteTratable;

    /**
     * @var int Tamaño máximo permitido para las imágenes (4 Megabytes)
     */
    public const MAXSIZE = 4194304;

    /**
     * @var string[] Extensiones de imágenes permitidas
     */
    public const EXTENSIONES_VALIDAS = ['jpg', 'jpeg', 'png'];

    /**
     * Nombre de la propiedad
     *
     * Nombre al que se asociarán los mensajes de error.
     *
     * @var string
     */
    public string $identificacion = 'imagen';

    /**
     * @var string
     */
    private string $nombre;

    /**
     * @var string
     */
    private string $ruta;

    /**
     * Constructor
     *
     * @param array   $file    Array con los datos del archivo
     * @param Carpeta $carpeta Carpeta donde se moverá la imagen
     */
    public function __construct(private array $file, Carpeta $carpeta)
    {
        $this->nombre = $this->obtenerStringDelFile('name');
        $this->ruta   = $this->obtenerStringDelFile('tmp_name');

        $this->validaciones = [
            new ValidarFile($file, self::MAXSIZE, self::EXTENSIONES_VALIDAS),
            new ValidarImagen($this->ruta),
        ];

        $this->tratamientos = [
            new MoverArchivo($this->nombre, $this->ruta, $carpeta->ruta()),
            new LimpiarMetadatos($this->ruta),
        ];
    }

    public function nombre(): string
    {
        return $this->nombre;
    }

    public function ruta(): string
    {
        return $this->ruta;
    }

    private function obtenerStringDelFile(string $clave): string
    {
        return isset($this->file[$clave]) && is_string($this->file[$clave]) ? $this->file[$clave] : '';
    }

}
