<?php

namespace Imagen\Modulo\Persistencia\Interfaz;

use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;

/**
 * Interfaz de acceso a un repositorio persistencia de imágenes
 *
 * @package Imagen\Modulo\Persistencia\Interfaz
 */
interface IRepositorioPersistencia
{

    /**
     * Persiste una imagen en el repositorio
     *
     * @param IImagen $imagen
     *
     * @return bool
     */
    public function persistirImagen(IImagen $imagen): bool;

    /**
     * Persiste las imágenes en el repositorio
     *
     * @param IImagenes $imagenes
     *
     * @return bool
     */
    public function persistirImagenes(IImagenes $imagenes): bool;

}
