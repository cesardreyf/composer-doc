<?php

namespace Imagen\Modulo\Persistencia\Validacion;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;
use Gmagick;
use GmagickException;

/**
 * Componente de validación para verificar que la imagen es válida y no tremendo virus cumbiero
 *
 * @package Imagen\Modulo\Persistencia\Validacion
 */
class ValidarImagen implements IComponenteValidable
{

    /**
     * Constructor
     *
     * @param array $file Array con los datos de la imagen
     */
    public function __construct(private array $file)
    {
    }

    /**
     * Valida que el archivo sea una imagen válida
     *
     * @param IRegistro $errores Registro donde se almacenarán los mensajes de error
     *
     * @return bool
     */
    public function validar(IRegistro $errores): bool
    {
        try {
            new Gmagick($this->file['tmp_name']);
            return true;
        } catch( GmagickException $e ) {
            $errores->agregarMensaje('El archivo subido no es una imagen válida');
        }
        return false;
    }

}
