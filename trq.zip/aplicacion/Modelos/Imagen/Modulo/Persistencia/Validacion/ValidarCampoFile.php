<?php

namespace Imagen\Modulo\Persistencia\Validacion;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;

/**
 * Componente de validación de datos proporcionados por la variable súper global _FILE
 *
 * @package Imagen\Modulo\Persistencia\Validacion
 */
class ValidarCampoFile implements IComponenteValidable
{

    /**
     * @var int Tamaño máximo para las imágenes (en bytes)
     */
    public const LIMITE_MAXIMO_BYTES = 4194304;

    /**
     * @var string[] Enumera las extensiones permitidas
     */
    public const EXTENSIONES_PERMITIDAS = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

    /**
     * @var string[] Determina las columnas obligatorias para el array
     */
    public const COLUMNAS_REQUERIDAS = ['name', 'type', 'size', 'tmp_name', 'error'];

    /**
     * Constructor
     *
     * @param array $file Array con los datos de la imagen
     */
    public function __construct(private array $file)
    {
    }

    /**
     * Valida la imagen
     *
     * @param IRegistro $errores Registro donde se almacenarán los mensajes de error
     *
     * @return bool
     */
    public function validar(IRegistro $errores): bool
    {
        return $this->columnasRequeridasExisten($errores)
            && $this->tipoDeDatosDelArraySonValidos($errores)
            && $this->codigoDeErrorValido($errores)
            && $this->limiteNoExcedido($errores)
            && $this->extensionValido($errores);
    }

    /**
     * Verifica que las columnas obligatorias existan en el array
     *
     * @param IRegistro $errores
     *
     * @return bool
     */
    private function columnasRequeridasExisten(IRegistro $errores): bool
    {
        $columnasFaltantes = array_diff(self::COLUMNAS_REQUERIDAS, array_keys($this->file));

        if( !empty($columnasFaltantes) ) {
            $error = $errores->preparar('Array inválido. Faltan columnas (\1)');
            $error->vincular(1, implode(', ', $columnasFaltantes));
            $error->guardar();
            return false;
        }
        return true;
    }

    /**
     * Verifica que el tipo de dato de los elementos del array correspondan con lo esperado
     *
     * Verifica que las columnas 'size' y 'error' sean de tipo Integer y que
     * las columnas 'name', 'tmp_name' y 'type' sean de tipo String.
     *
     * @param IRegistro $errores
     *
     * @return bool
     */
    private function tipoDeDatosDelArraySonValidos(IRegistro $errores): bool
    {
        static $tipoInt = ['size', 'error'];
        static $tipoString = ['name', 'tmp_name', 'type'];

        $error = $errores->preparar('La columna \1 debe ser de tipo \2');

        foreach( $tipoString as $columna ) {
            if( !is_string($this->file[$columna]) ) {
                $error->vincular(1, $columna);
                $error->vincular(2, 'string');
                $error->guardar();
                return false;
            }
        }

        foreach( $tipoInt as $columna ) {
            if( !is_int($this->file[$columna]) ) {
                $error->vincular(1, $columna);
                $error->vincular(2, 'int');
                $error->guardar();
                return false;
            }
        }

        return true;
    }

    /**
     * Verifica el código de error de la imágen subida
     *
     * @param IRegistro $errores
     *
     * @return bool
     */
    private function codigoDeErrorValido(IRegistro $errores): bool
    {
        switch( $this->file['error'] ) {
            case UPLOAD_ERR_OK:
                return true;

            case UPLOAD_ERR_INI_SIZE:
                $error = $errores->preparar('El tamaño de la imagen supera el máximo permitido por el servidor (\1)');
                $error->vincular(1, ini_get('upload_max_filesize') . 'b');
                $error->guardar();
                break;

            case UPLOAD_ERR_PARTIAL:
                $errores->agregarMensaje('El archivo no se subió correctamente');
                break;

            case UPLOAD_ERR_NO_FILE:
                $errores->agregarMensaje('No se subió ningún archivo');
                break;

            // TAREA: Generar un reporte
            case UPLOAD_ERR_NO_TMP_DIR:
            case UPLOAD_ERR_CANT_WRITE:
                $errores->agregarMensaje('Ocurrió un error interno en el servidor al momento de guardar la imagen');
                break;
        }
        return false;
    }

    /**
     * Verifica que el tamaño de la imagen no exceda los límites establecidos
     *
     * @param IRegistro $errores
     *
     * @return bool
     */
    private function limiteNoExcedido(IRegistro $errores): bool
    {
        if( $this->file['size'] > self::LIMITE_MAXIMO_BYTES ) {
            $error = $errores->preparar('El tamaño máximo permitido es de \1 Mb');
            $error->vincular(1, number_format(self::LIMITE_MAXIMO_BYTES / 1048576, 2));
            $error->guardar();
            return false;
        }
        return true;
    }

    /**
     * Verifica que la extensión de la imagen sea válido
     *
     * @param IRegistro $errores
     *
     * @return bool
     */
    private function extensionValido(IRegistro $errores): bool
    {
        $extensionDeLaImagen = pathinfo($this->file['name'], PATHINFO_EXTENSION);
        if( !in_array($extensionDeLaImagen, self::EXTENSIONES_PERMITIDAS) ) {
            $error = $errores->preparar('Solo se permiten imágenes con extensión: \1');
            $error->vincular(1, implode(', ', self::EXTENSIONES_PERMITIDAS));
            $error->guardar();
            return false;
        }
        return true;
    }

}
