<?php

namespace Imagen\Contenedor;

use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;

/**
 * Contenedor de imágenes
 *
 * @package Imagen\Contenedor
 */
class Imagenes implements IImagenes
{

    /**
     * @var IImagen[]
     */
    private array $lista = [];

    /**
     * Agrega una imagen al contenedor
     *
     * @param IImagen $imagen
     */
    public function agregar(IImagen $imagen)
    {
        $this->lista[] = $imagen;
    }

    /**
     * Limpia la lista de imágenes
     */
    public function limpiar()
    {
        $this->lista = [];
    }

    /**
     * Obtiene la lista de imágenes
     *
     * @return IImagen[]
     */
    public function lista(): array
    {
        return $this->lista;
    }

}
