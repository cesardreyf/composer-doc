<?php

namespace Imagen\Excepcion;

/**
 * Excepción lanzado cuando no se encuentra la imagen solicitada
 *
 * @package Imagen\Excepcion
 */
class ExcepcionImagenInexistente extends Excepcion
{
}
