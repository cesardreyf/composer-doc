<?php

namespace Imagen\Excepcion;

/**
 * Excepción lanzado cuando no se puede almacenar la imagen en el servidor
 *
 * @package Imagen\Excepcion
 */
class ExcepcionErrorAlAlmacenarImagen extends Excepcion
{

    /**
     * Constructor
     *
     * @param int $id Id de la imagen inexistente
     */
    public function __construct(string $rutaOrigen, string $rutaDestino)
    {
        parent::__construct("No se pudo almacenar el archivo '{$rutaOrigen}' en '{$rutaDestino}'");
    }

}
