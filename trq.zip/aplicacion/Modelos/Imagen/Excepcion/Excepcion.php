<?php

namespace Imagen\Excepcion;

use Exception;
use Contrato\Excepcion\IExcepcionPadre;

/**
 * Excepción del que extienden todas las excepciones del modelo imagen
 *
 * @package Imagen\Excepcion
 */
class Excepcion extends Exception implements IExcepcionPadre
{
}
