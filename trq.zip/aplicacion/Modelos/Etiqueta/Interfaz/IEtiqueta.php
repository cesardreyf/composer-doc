<?php

namespace Etiqueta\Interfaz;

use Contrato\Componente\IId;

/**
 * Interfaz de acceso a una etiqueta
 *
 * @package Etiqueta\Interfaz
 */
interface IEtiqueta extends IId
{

    /**
     * Obtiene el nombre de la etiqueta
     *
     * @return string
     */
    public function nombre(): string;

}
