<?php

namespace Etiqueta\Interfaz;

use Contrato\Componente\IId;

/**
 * Interfaz para los contenedores de etiquetas
 *
 * @package Etiqueta\Interfaz
 */
interface IEtiquetas
{

    /**
     * Obtiene la lista de etiquetas
     *
     * @return IEtiqueta[]
     */
    public function lista(): array;

}
