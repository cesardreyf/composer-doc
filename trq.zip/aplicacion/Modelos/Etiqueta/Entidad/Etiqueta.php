<?php

namespace Etiqueta\Entidad;

use Etiqueta\Interfaz\IEtiqueta;

/**
 * Entidad que representa una etiqueta
 *
 * @package Etiqueta\Entidad
 */
class Etiqueta implements IEtiqueta
{

    /**
     * Constructor
     *
     * @param int    $id     Id de la etiqueta
     * @param string $nombre Nombre de la etiqueta
     */
    public function __construct(private int $id, private string $nombre)
    {
    }

    /**
     * Obtiene el nombre de la etiqueta
     *
     * @return string
     */
    public function nombre(): string
    {
        return $this->nombre;
    }

    /**
     * Obtiene el id
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

}
