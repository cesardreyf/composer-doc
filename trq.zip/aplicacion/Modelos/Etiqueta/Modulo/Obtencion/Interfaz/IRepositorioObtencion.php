<?php

namespace Etiqueta\Modulo\Obtencion\Interfaz;

use Etiqueta\Interfaz\IEtiqueta;
use Etiqueta\Interfaz\IEtiquetas;

interface IRepositorioObtencion
{

    /**
     * Verifica si existe la etiqueta con el ID indicado
     *
     * @param int $id Id de la etiqueta a verificar
     *
     * @return bool Devuelve el estado de la validación
     */
    public function etiquetaExiste(int $id): bool;

    /**
     * Obtiene una etiqueta según su ID
     *
     * @param int $id
     *
     * @return IEtiqueta
     *
     * @throws \Throwable en caso de error
     */
    public function obtenerEtiquetaSegunId(int $id): IEtiqueta;

    /**
     * Obtiene una lista de etiquetas según los IDs especificados
     *
     * @param int $id
     * @param int ...$masIds
     *
     * @return IEtiquetas
     */
    public function obtenerEtiquetasSegunIds(int $id, int ...$masIds): IEtiquetas;

}
