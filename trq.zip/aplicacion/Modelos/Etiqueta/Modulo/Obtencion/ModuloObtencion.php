<?php

namespace Etiqueta\Modulo\Obtencion;

use Etiqueta\Excepcion\ExcepcionEtiquetaInexistente;
use Etiqueta\Interfaz\IEtiqueta;
use Etiqueta\Interfaz\IEtiquetas;
use Etiqueta\Modulo\Obtencion\Interfaz\IRepositorioObtencion;

/**
 * Módulo de obtención de etiquetas
 *
 * @package Etiqueta\Modulo\Obtencion
 */
class ModuloObtencion
{

    /**
     * Constructor
     *
     * @param IRepositorioObtencion $repositorio
     */
    public function __construct(private IRepositorioObtencion $repositorio)
    {
    }

    /**
     * Obtiene una etiqueta según el ID
     *
     * @param int $id Id de la etiqueta a obtener
     *
     * @return IEtiqueta
     *
     * @throws ExcepcionEtiquetaInexistente si la etiqueta solicitada no existe en el repositorio
     */
    public function obtenerEtiquetaSegunId(int $id): IEtiqueta
    {
        if( !$this->repositorio->etiquetaExiste($id) ) {
            throw new ExcepcionEtiquetaInexistente($id);
        }

        return $this->repositorio->obtenerEtiquetaSegunId($id);
    }

    /**
     * Obtiene una lista de etiquetas según un conjunto de id
     *
     * @param int $id
     * @param int ...$masIds
     *
     * @return IEtiquetas
     */
    public function obtenerListaDeEtiquetasSegunIds(int $id, int ...$masIds): IEtiquetas
    {
        return $this->repositorio->obtenerEtiquetasSegunIds($id, ...$masIds);
    }

}
