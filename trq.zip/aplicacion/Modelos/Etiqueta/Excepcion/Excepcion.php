<?php

namespace Etiqueta\Excepcion;

use Contrato\Excepcion\IExcepcionPadre;
use Exception;

/**
 * Excepción del que extienden todas las excepciones del modelo Etiqueta
 *
 * @package Etiqueta\Excepcion
 */
class Excepcion extends Exception implements IExcepcionPadre
{
}
