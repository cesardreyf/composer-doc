<?php

namespace Etiqueta\Excepcion;

/**
 * Excepción lanzado cuando no se encuentra una excepción con el ID especificado
 *
 * @package Etiqueta\Excepcion
 */
class ExcepcionEtiquetaInexistente extends Excepcion
{

    /**
     * Constructor
     *
     * @param int $id Id de la etiqueta inexistente
     */
    public function __construct(int $id)
    {
        parent::__construct("No existe ninguna etiqueta con el ID {$id}");
    }

}
