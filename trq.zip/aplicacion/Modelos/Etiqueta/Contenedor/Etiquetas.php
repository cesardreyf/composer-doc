<?php

namespace Etiqueta\Contenedor;

use Etiqueta\Interfaz\IEtiqueta;
use Etiqueta\Interfaz\IEtiquetas;

/**
 * Contenedor de etiquetas
 *
 * @package Etiqueta\Contenedor
 */
class Etiquetas implements IEtiquetas
{

    /**
     * @var IEtiqueta[]
     */
    private array $lista = [];

    /**
     * Agrega una etiqueta a la lista
     *
     * @param IEtiqueta $etiqueta
     */
    public function agregar(IEtiqueta $etiqueta)
    {
        $this->lista[] = $etiqueta;
    }

    /**
     * Limpia la lista de etiquetas
     */
    public function limpiar()
    {
        $this->lista = [];
    }

    /**
     * Obtiene la lista de etiquetas
     *
     * @return IEtiqueta[]
     */
    public function lista(): array
    {
        return $this->lista;
    }

}
