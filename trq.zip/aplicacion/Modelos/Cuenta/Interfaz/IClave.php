<?php

namespace Cuenta\Interfaz;

/**
 * Interfaz para acceder a la clave
 *
 * @package Cuenta\Interfaz
 */
interface IClave
{

    /**
     * Obtiene la clave
     *
     * @return string
     */
    public function valor(): string;

}
