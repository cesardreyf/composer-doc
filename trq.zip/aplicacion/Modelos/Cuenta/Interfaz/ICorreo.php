<?php

namespace Cuenta\Interfaz;

/**
 * Interfaz para acceder a la dirección de correo electrónico
 *
 * @package Cuenta\Interfaz
 */
interface ICorreo
{

    /**
     * Obtiene la dirección de correo electrónico
     *
     * @return string
     */
    public function valor(): string;

}
