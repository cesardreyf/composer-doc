<?php

namespace Cuenta\Interfaz;

/**
 * Interfaz para acceder al nombre de usuario
 *
 * @package Cuenta\Interfaz
 */
interface IUsuario
{

    /**
     * Obtiene el nombre de usuario
     *
     * @return string
     */
    public function valor(): string;

}
