<?php

namespace Cuenta\Modulo\Autenticacion\Interfaz;

use Cuenta\Interfaz\ICorreo;

/**
 * Interfaz para acceder a un repositorio de autenticación de cuentas
 *
 * @package Cuenta\Modulo\Autenticacion\Interfaz
 */
interface IRepositorioAutenticacion
{

    /**
     * Obtiene el hash de una cuenta según el correo electrónico
     *
     * @param ICorreo $correo
     *
     * @return string Devuelve el hash
     *
     * @throws \Throwable en caso de error
     */
    public function obtenerClaveSegunCorreo(ICorreo $correo): string;

    /**
     * Verifica si el correo existe en el repositorio
     *
     * @param ICorreo $correo
     *
     * @return bool Devuelve el estado de la validación
     */
    public function correoExiste(ICorreo $correo): bool;

    /**
     * Obtiene el ID de una cuenta según el correo electrónico
     *
     * @param ICorreo $correo
     *
     * @return int
     *
     * @throws \Throwable en caso de error
     */
    public function obtenerIdSegunCorreo(ICorreo $correo): int;
    
}
