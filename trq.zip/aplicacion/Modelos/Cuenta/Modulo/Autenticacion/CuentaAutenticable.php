<?php

namespace Cuenta\Modulo\Autenticacion;

use Componente\Extension\ExtensionContenedorDeComponentes;
use Componente\Seguridad\Clave;
use Contrato\Componente\IEntidad;
use Contrato\Componente\IId;
use Cuenta\Interfaz\IClave;
use Cuenta\Interfaz\ICorreo;
use Cuenta\Modulo\Autenticacion\Interfaz\IRepositorioAutenticacion;

/**
 * Módulo de autenticación de cuenta
 *
 * Módulo encargado de validar que el correo y la clave proporcionada sean válidos.
 *
 * @package Cuenta\Modulo\Autenticacion
 */
class CuentaAutenticable implements IEntidad
{
    use ExtensionContenedorDeComponentes;

    private int $id = 0;

    /**
     * Constructor
     *
     * @param ICorreo $correo Datos del correo electrónico
     * @param IClave  $clave  Datos de la clave a validar
     * @param IRepositorioAutenticacion $repositorio
     */
    public function __construct(private ICorreo $correo, private IClave $clave, private IRepositorioAutenticacion $repositorio)
    {
        $this->agregarComponente(
            $this->correo,
            $this->clave,
        );
    }

    /**
     * Verifica si los datos de autenticación son válidos
     *
     * @return bool Devuelve el estado de la validación
     */
    public function autenticar(): bool
    {
        $hash = $this->repositorio->obtenerClaveSegunCorreo($this->correo);

        if( Clave::validar($this->clave->valor(), $hash) == false ) {
            return false;
        }

        $this->id = $this->repositorio->obtenerIdSegunCorreo($this->correo);
        return true;
    }

    /**
     * Obtiene el ID de la cuenta
     *
     * Llamar antes a la función autenticar
     *
     * @return int
     *
     * @see CuentaAutenticable::autenticar() para actualizar el ID
     */
    public function id(): int
    {
        return $this->id;
    }

}
