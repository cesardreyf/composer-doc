<?php

namespace Cuenta\Modulo\Autenticacion\Propiedad;

use Componente\Extension\ExtensionComponenteValidable;
use Componente\Validacion\Cadena\ValidarCampoVacio;
use Contrato\Componente\IComponente;
use Contrato\Validacion\IValidable;
use Cuenta\Interfaz\IClave;

/**
 * Propiedad clave
 *
 * @package Cuenta\Modulo\Autenticacion\Propiedad
 */
class Clave implements IClave, IComponente, IValidable
{
    use ExtensionComponenteValidable;

    /**
     * @var string Nombre de la propiedad
     */
    protected string $identificacion = 'clave';

    /**
     * Constructor
     *
     * @param string $clave Contraseña
     */
    public function __construct(private string $clave)
    {
        $this->validaciones = [
            new ValidarCampoVacio($clave),
        ];
    }

    /**
     * Obtiene la clave
     *
     * @return string
     */
    public function valor(): string
    {
        return $this->clave;
    }

}
