<?php

namespace Cuenta\Modulo\Autenticacion\Propiedad;

use Componente\Extension\ExtensionComponenteValidable;
use Componente\Validacion\Cadena\ValidarCorreoElectronico;
use Contrato\Componente\IComponente;
use Contrato\Validacion\IValidable;
use Cuenta\Interfaz\ICorreo;
use Cuenta\Modulo\Autenticacion\Interfaz\IRepositorioAutenticacion;
use Cuenta\Modulo\Autenticacion\Validacion\ValidarQueElCorreoExiste;

/**
 * Propiedad correo
 *
 * @package Cuenta\Modulo\Autenticacion\Propiedad
 */
class Correo implements ICorreo, IComponente, IValidable
{
    use ExtensionComponenteValidable;

    /**
     * @var string Nombre de la propiedad
     */
    protected string $identificacion = 'correo';

    /**
     * Constructor
     *
     * @param string $correo Dirección de correo electrónico
     */
    public function __construct(private string $correo, private IRepositorioAutenticacion $repositorio)
    {
        $this->validaciones = [
            new ValidarCorreoElectronico($correo),
            new ValidarQueElCorreoExiste($this, $repositorio),
        ];
    }

    /**
     * Obtiene la dirección de correo electrónico
     *
     * @return string
     */
    public function valor(): string
    {
        return $this->correo;
    }

}
