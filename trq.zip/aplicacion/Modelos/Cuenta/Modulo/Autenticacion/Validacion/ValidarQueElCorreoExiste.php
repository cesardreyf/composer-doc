<?php

namespace Cuenta\Modulo\Autenticacion\Validacion;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;
use Cuenta\Interfaz\ICorreo;
use Cuenta\Modulo\Autenticacion\Interfaz\IRepositorioAutenticacion;

/**
 * Componente de validación de correos existente
 *
 * @package Cuenta\Modulo\Autenticacion\Validacion
 */
class ValidarQueElCorreoExiste implements IComponenteValidable
{

    /**
     * @var string Mensaje de error
     */
    public const ERROR_MENSAJE = 'El correo electrónico no pertenece a ninguna cuenta existente';

    /**
     * Constructor
     *
     * @param ICorreo $correo Dirección de correo electrónico a validar
     * @param IRepositorioAutenticacion Instancia del repositorio donde consultar
     */
    public function __construct(private ICorreo $correo, private IRepositorioAutenticacion $repositorio)
    {
    }

    /**
     * Valida que exista una cuenta con el correo indicado
     *
     * @param IRegistro $errores Registro donde se almacenarán los errores
     *
     * @return bool
     */
    public function validar(IRegistro $errores): bool
    {
        if( $this->repositorio->correoExiste($this->correo) == false ) {
            $errores->agregarMensaje(self::ERROR_MENSAJE);
            return false;
        }
        return true;
    }

}
