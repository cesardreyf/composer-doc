<?php

namespace Cuenta\Modulo\Persistencia\Propiedad;

use Componente\Extension\ExtensionComponenteTratable;
use Componente\Extension\ExtensionComponenteValidable;
use Componente\Tratamiento\Cadena\CifrarCadena;
use Componente\Validacion\Cadena\ValidarLongitudLimitado;
use Componente\Validacion\Cadena\ValidarQueContieneAlMenosUnCaracterEnMayuscula;
use Componente\Validacion\Cadena\ValidarQueContieneAlMenosUnCaracterEnMinuscula;
use Componente\Validacion\Cadena\ValidarQueContieneAlMenosUnCaracterEspecial;
use Componente\Validacion\Cadena\ValidarQueContieneAlMenosUnCaracterNumerico;
use Contrato\Componente\IComponente;
use Contrato\Tratamiento\ITratable;
use Contrato\Validacion\IValidable;
use Cuenta\Interfaz\IClave;

/**
 * Propiedad clave
 *
 * @package Cuenta\Modulo\Persistencia\Propiedad
 */
class Clave implements IClave, IComponente, IValidable, ITratable
{
    use ExtensionComponenteValidable;
    use ExtensionComponenteTratable;

    /**
     * @var int Longitud mínimo permitido para la clave
     */
    public const LONGITUD_MINIMO = 8;

    /**
     * @var int Longitud máximo permitido para la clave
     */
    public const LONGITUD_MAXIMO = 64;

    /**
     * @var string Nombre de la propiedad
     */
    protected string $identificacion = 'clave';

    /**
     * Constructor
     *
     * @param string $clave Contraseña
     */
    public function __construct(private string $clave)
    {
        $this->validaciones = [
            new ValidarLongitudLimitado($clave, self::LONGITUD_MINIMO, self::LONGITUD_MAXIMO),
            new ValidarQueContieneAlMenosUnCaracterEnMinuscula($clave),
            new ValidarQueContieneAlMenosUnCaracterEnMayuscula($clave),
            new ValidarQueContieneAlMenosUnCaracterNumerico($clave),
            new ValidarQueContieneAlMenosUnCaracterEspecial($clave),
        ];

        $this->tratamientos = [
            new CifrarCadena($this->clave),
        ];
    }

    /**
     * Obtiene la clave
     *
     * @return string
     */
    public function valor(): string
    {
        return $this->clave;
    }

}
