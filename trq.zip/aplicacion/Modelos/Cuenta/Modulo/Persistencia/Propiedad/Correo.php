<?php

namespace Cuenta\Modulo\Persistencia\Propiedad;

use Componente\Extension\ExtensionComponenteTratable;
use Componente\Extension\ExtensionComponenteValidable;
use Componente\Tratamiento\Cadena\ConvertirTodoEnMinuscula;
use Componente\Validacion\Cadena\ValidarCorreoElectronico;
use Contrato\Componente\IComponente;
use Contrato\Tratamiento\ITratable;
use Contrato\Validacion\IValidable;
use Cuenta\Interfaz\ICorreo;
use Cuenta\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;
use Cuenta\Modulo\Persistencia\Validacion\ValidarQueElCorreoNoExista;

/**
 * Propiedad correo
 *
 * @package Cuenta\Modulo\Persistencia\Propiedad
 */
class Correo implements ICorreo, IComponente, IValidable, ITratable
{
    use ExtensionComponenteValidable;
    use ExtensionComponenteTratable;

    /**
     * @var string Nombre de la propiedad
     */
    protected string $identificacion = 'correo';

    /**
     * Constructor
     *
     * @param string $correo Dirección de correo electrónico
     */
    public function __construct(private string $correo, private IRepositorioPersistencia $repositorio)
    {
        $this->validaciones = [
            new ValidarCorreoElectronico($correo),
            new ValidarQueElCorreoNoExista($correo, $repositorio),
        ];

        $this->tratamientos = [
            new ConvertirTodoEnMinuscula($this->correo),
        ];
    }

    /**
     * Obtiene la dirección de correo electrónico
     *
     * @return string
     */
    public function valor(): string
    {
        return $this->correo;
    }

}
