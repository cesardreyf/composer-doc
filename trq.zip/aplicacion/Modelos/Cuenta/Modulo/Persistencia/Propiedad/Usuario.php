<?php

namespace Cuenta\Modulo\Persistencia\Propiedad;

use Componente\Extension\ExtensionComponenteTratable;
use Componente\Extension\ExtensionComponenteValidable;
use Componente\Tratamiento\Cadena\ConvertirPrimeraLetraDeCadaPalabraEnMayuscula;
use Componente\Validacion\Cadena\ValidarLongitudLimitado;
use Componente\Validacion\Cadena\ValidarSoloCaracteresAlfabeticosYEspacio;
use Contrato\Componente\IComponente;
use Contrato\Tratamiento\ITratable;
use Contrato\Validacion\IValidable;
use Cuenta\Interfaz\IUsuario;

/**
 * Propiedad usuario
 *
 * @package Cuenta\Modulo\Persistencia\Propiedad
 */
class Usuario implements IUsuario, IComponente, IValidable, ITratable
{
    use ExtensionComponenteValidable;
    use ExtensionComponenteTratable;

    /**
     * @var int Longitud mínimo permitido para el nombre de usuario
     */
    public const LONGITUD_MINIMO = 5;

    /**
     * @var int Longitud máximo permitido para el nombre de usuario
     */
    public const LONGITUD_MAXIMO = 32;

    /**
     * @var string Nombre de la propiedad
     */
    protected string $identificacion = 'usuario';

    /**
     * Constructor
     *
     * @param string $usuario Nombre de usuario
     */
    public function __construct(private string $usuario)
    {
        $this->validaciones = [
            new ValidarLongitudLimitado($usuario, self::LONGITUD_MINIMO, self::LONGITUD_MAXIMO),
            new ValidarSoloCaracteresAlfabeticosYEspacio($usuario),
        ];

        $this->tratamientos = [
            new ConvertirPrimeraLetraDeCadaPalabraEnMayuscula($this->usuario),
        ];
    }

    /**
     * Obtiene el nombre de usuario
     *
     * @return string
     */
    public function valor(): string
    {
        return $this->usuario;
    }

}
