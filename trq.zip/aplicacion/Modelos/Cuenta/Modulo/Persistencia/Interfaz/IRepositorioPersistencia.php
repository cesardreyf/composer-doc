<?php

namespace Cuenta\Modulo\Persistencia\Interfaz;

use Cuenta\Interfaz\IClave;
use Cuenta\Interfaz\ICorreo;
use Cuenta\Interfaz\IUsuario;

/**
 * Intefaz para acceder a un repositorio de persistencia
 *
 * @package Cuenta\Modulo\Persistencia\Interfaz
 */
interface IRepositorioPersistencia
{

    /**
     * Verifica si el correo ya existe en el repositorio
     *
     * @param string $correo Correo a validar
     *
     * @return bool Devuelve el estado de la validación
     */
    public function correoExiste(string $correo): bool;

    /**
     * Persiste los datos de la cuenta en el repositorio
     *
     * @param IUsuario $usuario Datos del usuario
     * @param ICorreo  $correo  Datos del correo
     * @param IClave   $clave   Datos de la clave
     *
     * @return bool Devuelve **true** si se persistió correctamente o **false** de lo contrario
     */
    public function persistirCuenta(IUsuario $usuario, ICorreo $correo, IClave $clave): bool;

}
