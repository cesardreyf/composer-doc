<?php

namespace Cuenta\Modulo\Persistencia\Interfaz;

/**
 * Interfaz para acceder a los datos de la cuenta
 *
 * @package Cuenta\Modulo\Persistencia\Interfaz
 */
interface ICuenta
{

    /**
     * Obtiene el nombre de usuario
     *
     * @return string
     */
    public function usuario(): string;

    /**
     * Obtiene la dirección de correo electrónico
     *
     * @return string
     */
    public function correo(): string;

    /**
     * Obtiene la contraseña
     *
     * @return string
     */
    public function clave(): string;

    /**
     * Obtiene el ID de la cuenta
     *
     * @return int
     */
    public function id(): int;

}
