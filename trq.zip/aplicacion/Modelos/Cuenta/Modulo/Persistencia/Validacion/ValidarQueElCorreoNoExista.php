<?php

namespace Cuenta\Modulo\Persistencia\Validacion;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\Iregistro;
use Cuenta\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;

/**
 * Componente de validación de correos existente
 *
 * @package Cuenta\Modulo\Persistencia\Validacion
 */
class ValidarQueElCorreoNoExista implements IComponenteValidable
{

    /**
     * @var string Mensaje de error
     */
    public const ERROR_MENSAJE = 'El correo electrónico ya está siendo usado por alguien';

    /**
     * Constructor
     *
     * @param string $correo Dirección de correo electrónico a validar
     * @param IRepositorioPersistencia Instancia del repositorio donde consultar
     */
    public function __construct(private string $correo, private IRepositorioPersistencia $repositorio)
    {
    }

    /**
     * Valida que el correo no esté en el repositorio
     *
     * @param IRegistro $errores Registro donde se almacenarán los errores
     *
     * @return bool Devuelve **true** si no existe ningún correo igual, **false** de lo contrario
     */
    public function validar(IRegistro $errores): bool
    {
        if( $this->repositorio->correoExiste($this->correo) ) {
            $errores->agregarMensaje(self::ERROR_MENSAJE);
            return false;
        }
        return true;
    }

}
