<?php

namespace Cuenta\Modulo\Persistencia;

use Componente\Extension\ExtensionContenedorDeComponentes;
use Contrato\Componente\IEntidad;
use Contrato\Componente\IId;
use Cuenta\Interfaz\IClave;
use Cuenta\Interfaz\ICorreo;
use Cuenta\Interfaz\IUsuario;
use Cuenta\Modulo\Persistencia\Interfaz\ICuenta;
use Cuenta\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;

/**
 * Módulo de persistencia de cuenta
 *
 * Módulo encargado de gestionar la persistencia de cuentas y sus propiedades.
 *
 * @package Cuenta\Modulo\Persistencia
 */
class CuentaPersistible implements IEntidad, ICuenta
{
    use ExtensionContenedorDeComponentes;

    /**
     * Constructor
     *
     * @param IId $id
     * @param IUsuario $usuario
     * @param ICorreo $correo
     * @param IClave $clave
     * @param IRepositorioPersistencia $repositorio
     */
    public function __construct(
        private IId $id,
        private IUsuario $usuario,
        private ICorreo $correo,
        private IClave $clave,
        private IRepositorioPersistencia $repositorio
    )
    {
        $this->agregarComponente(
            $this->id,
            $this->usuario,
            $this->correo,
            $this->clave
        );
    }

    /**
     * Persiste la cuenta
     *
     * Persiste los datos de la cuenta en el repositorio.
     *
     * @return bool Devuelve **true** si se persistió o **false** de lo contrario
     */
    public function persistir(): bool
    {
        return $this->repositorio->persistirCuenta(
            $this->usuario,
            $this->correo,
            $this->clave
        );
    }

    /**
     * Obtiene el nombre de usuario
     *
     * @return string
     */
    public function usuario(): string
    {
        return $this->usuario->valor();
    }

    /**
     * Obtiene la dirección de correo electrónio
     *
     * @return string
     */
    public function correo(): string
    {
        return $this->correo->valor();
    }

    /**
     * Obtiene la contraseña de la cuenta
     *
     * @return string
     */
    public function clave(): string
    {
        return $this->clave->valor();
    }

    /**
     * Obtiene el ID de la cuenta
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id->id();
    }

}
