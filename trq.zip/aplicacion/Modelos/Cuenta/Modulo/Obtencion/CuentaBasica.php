<?php

namespace Cuenta\Modulo\Obtencion;

use Contrato\Componente\IId;
use Cuenta\Modulo\Obtencion\Excepcion\ExcepcionCuentaInexistente;
use Cuenta\Modulo\Obtencion\Interfaz\ICuentaBasica;
use Cuenta\Modulo\Obtencion\Interfaz\IRepositorioObtencion;

/**
 * Cuenta con propiedades básicas
 *
 * Obtiene los datos de la cuenta desde el repositorio y los almacena.
 *
 * @package Cuenta\Modulo\Obtencion
 */
class CuentaBasica implements ICuentaBasica
{

    /**
     * @var string Almacena el nombre de usuario
     */
    private string $usuario;

    /**
     * @var string Almacena la dirección de correo electrónico
     */
    private string $correo;

    /**
     * Constructor
     *
     * @param IId $cuenta Identificador de la cuenta a obtener
     * @param IRepositorioObtencion $repositorio Repositorio desde donde se obtendrán los datos
     *
     * @throws ExcepcionCuentaInexistente si el ID no corresponde con ninguna cuenta
     */
    public function __construct(private IId $cuenta, private IRepositorioObtencion $repositorio)
    {
        if( !$this->repositorio->existe($cuenta) ) {
            throw new ExcepcionCuentaInexistente($cuenta);
        }

        $this->usuario = $this->repositorio->obtenerUsuarioSegunId($cuenta);
        $this->correo = $this->repositorio->obtenerCorreoSegunId($cuenta);
    }

    /**
     * Obtiene el nombre de usuario
     *
     * @return string
     */
    public function usuario(): string
    {
        return $this->usuario;
    }

    /**
     * Obtiene el correo
     *
     * @return string
     */
    public function correo(): string
    {
        return $this->correo;
    }

    /**
     * Obtiene el ID de la cuenta
     *
     * @return int
     */
    public function id(): int
    {
        $this->cuenta->id();
    }

}
