<?php

namespace Cuenta\Modulo\Obtencion\Interfaz;

use Contrato\Componente\IId;

/**
 * Interfaz para acceder a un repositorio de obtención de propiedades de una cuenta
 *
 * @package Cuenta\Modulo\Obtenecion\Interfaz
 */
interface IRepositorioObtencion
{

    /**
     * Verifica si existe una cuenta con el ID indicado
     *
     * @param IId $cuenta Id de la cuenta a verificar
     *
     * @return bool
     */
    public function existe(IId $cuenta): bool;

    /**
     * Obtiene el nombre de usuario según el ID de la cuenta
     *
     * @return string
     */
    public function obtenerUsuarioSegunId(IId $cuenta): string;

    /**
     * Obtiene el correo electrónico según el ID de la cuenta
     *
     * @return string
     */
    public function obtenerCorreoSegunId(IId $cuenta): string;

}
