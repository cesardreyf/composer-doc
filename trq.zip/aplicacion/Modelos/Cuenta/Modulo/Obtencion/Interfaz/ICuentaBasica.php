<?php

namespace Cuenta\Modulo\Obtencion\Interfaz;

use Contrato\Componente\IId;

/**
 * Interfaz para la cuenta básica
 *
 * @package Cuenta\Modulo\Obtencion
 */
interface ICuentaBasica extends IId
{

    /**
     * Obtiene el nombre de usuario
     *
     * @return string
     */
    public function usuario(): string;

    /**
     * Obtiene el correo
     *
     * @return string
     */
    public function correo(): string;

}
