<?php

namespace Cuenta\Modulo\Obtencion\Excepcion;

use Contrato\Excepcion\IExcepcionPadre;
use Exception;

/**
 * Excepción del que extienden todas las excepciones del módulo de obtención
 *
 * @package Cuenta\Modulo\Obtencion\Excepcion
 */
class Excepcion extends Exception implements IExcepcionPadre
{
}
