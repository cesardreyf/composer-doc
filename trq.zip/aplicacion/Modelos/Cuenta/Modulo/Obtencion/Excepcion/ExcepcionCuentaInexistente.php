<?php

namespace Cuenta\Modulo\Obtencion\Excepcion;

use Contrato\Componente\IId;

/**
 * Excepción lanzado cuando no se encuentra ninguna cuenta con el ID indicado
 *
 * @package Cuenta\Modulo\Obtencion\Excepcion
 */
class ExcepcionCuentaInexistente extends Excepcion
{

    /**
     * Constructor
     +
     * @param IId $cuenta
     */
    public function __construct(IId $cuenta)
    {
        parent::__construct("No existe ninguna cuenta con el ID {$cuenta->id()}");
    }

}
