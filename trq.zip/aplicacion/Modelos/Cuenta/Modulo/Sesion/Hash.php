<?php

namespace Cuenta\Modulo\Sesion;

use Cuenta\Modulo\Sesion\Interfaz\IHash;
use Gof\Contrato\Cookies\Cookies;
use Gof\Contrato\Session\Session;

class Hash implements IHash
{

    /**
     * @var string Clave asociada para el hash
     */
    public const CLAVE_PRINCIPAL = 'uidhash';

    /**
     * @var int Duración de la cookie en segundos (~3 meses)
     */
    public const COOKIES_DURACION = 7897088;

    /**
     * @var int
     */
    public const NIVEL_SEGURIDAD = 32;

    /**
     * @var ?string Almacena el hash
     */
    private ?string $hash = null;

    /**
     * @var bool Indica si almacenar el hash en cookies
     */
    public bool $recordar = false;

    /**
     * Constructor
     *
     * @param Cookies $gCookies Gestor de cookies
     * @param Session $gSession Gestor de session
     */
    public function __construct(
        private Cookies $gCookies,
        private Session $gSession,
    )
    {
        $this->hash = $this->gCookies->obtener(self::CLAVE_PRINCIPAL);

        if( is_null($this->hash) ) {
            if( $this->gSession->existe(self::CLAVE_PRINCIPAL) ) {
                $this->hash = $this->gSession->obtener(self::CLAVE_PRINCIPAL);
            }
        }
    }

    /**
     * Guarda el hash en la session o cookies
     *
     * Si la propiedad $recordar está activo se almacenará el hash en cookies,
     * caso contrario se hará en session.
     *
     * @return bool
     */
    public function guardar(): bool
    {
        if( $this->recordar ) {
            $this->gCookies->duracion(self::COOKIES_DURACION, true);
            return $this->gCookies->definir(self::CLAVE_PRINCIPAL, $this->obtenerHash());
        }

        $this->gSession->definir(self::CLAVE_PRINCIPAL, $this->obtenerHash());
        return true;
    }

    /**
     * Obtiene el hash
     *
     * @return string
     */
    public function obtenerHash(): string
    {
        if( is_null($this->hash) ) {
            $this->regenerarHash();
        }
        return $this->hash;
    }

    /**
     * Regenera el hash
     */
    public function regenerarHash()
    {
        $this->hash = bin2hex(random_bytes(self::NIVEL_SEGURIDAD));
    }

    /**
     * Busca en session o cookies el hash
     *
     * @return bool Devuelve **true** si existe, **false** de lo contrario
     */
    public function existe(): bool
    {
        return !is_null($this->hash);
    }

    /**
     * Elimina el hash
     *
     * Remueve el hash de session y cookies
     */
    public function eliminar()
    {
        if( !is_null($this->hash) ) {
            $this->gCookies->eliminar(self::CLAVE_PRINCIPAL);
            $this->gSession->eliminar(self::CLAVE_PRINCIPAL);
        }
    }

}
