<?php

namespace Cuenta\Modulo\Sesion\Interfaz;

/**
 * Interfaz para acceder a un hash de sesión
 *
 * @package Cuenta\Modulo\Sesion\Interfaz
 */
interface IHash
{

    /**
     * Verifica si existe el hash
     *
     * @return bool
     */
    public function existe(): bool;

    /**
     * Obtiene el hash (si existe)
     *
     * @return string
     */
    public function obtenerHash(): string;

    /**
     * Elimina el hash
     */
    public function eliminar();

    /**
     * Persiste el hash
     *
     * @return bool
     */
    public function guardar(): bool;

    /**
     * Regenera el hash
     */
    public function regenerarHash();

}
