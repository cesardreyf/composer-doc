<?php

namespace Cuenta\Modulo\Sesion\Interfaz;

use Contrato\Componente\IId;

/**
 * Interfaz para acceder al repositorio de hash de sesión
 *
 * @package Cuenta\Modulo\Sesion\Interfaz
 */
interface IRepositorioSesion
{

    /**
     * Verifica si existe en hash en el repositorio
     *
     * @param string $hash
     *
     * @return bool
     */
    public function hashExiste(string $hash): bool;

    /**
     * Elimina el hash del repositorio
     */
    public function eliminarHash(string $hash);

    /**
     * Persiste los datos del hash de sesión
     *
     * @param string $hash Hash
     * @param IId    $id   Id de la cuenta a asociar
     */
    public function persistirHash(string $hash, IId $id): bool;

    /**
     * Obtiene los datos de una cuenta según el hash
     *
     * @param string $hash
     *
     * @return ICuenta
     */
    public function obtenerCuentaIdSegunHash(string $hash): IId;

}
