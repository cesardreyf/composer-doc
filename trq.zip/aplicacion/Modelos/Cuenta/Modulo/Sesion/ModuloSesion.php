<?php

namespace Cuenta\Modulo\Sesion;

use Contrato\Componente\IId;
use Cuenta\Modulo\Sesion\Excepcion\ExcepcionHashIndefinido;
use Cuenta\Modulo\Sesion\Excepcion\ExcepcionHashInexistente;
use Cuenta\Modulo\Sesion\Interfaz\IHash;
use Cuenta\Modulo\Sesion\Interfaz\IRepositorioSesion;

/**
 * Módulo de sesiones de cuentas
 *
 * @package Cuenta\Modulo\Sesion
 */
class ModuloSesion
{

    /**
     * @var bool Almacena el estado de la sesión
     */
    public bool $sesionIniciado = false;

    /**
     * Constructor
     *
     * @param IHash $hash
     * @param IRepositorioSesion $repositorio
     */
    public function __construct(
        private IHash $hash,
        private IRepositorioSesion $repositorio,
    )
    {
    }

    /**
     * Inicia la sesión
     *
     * Inicia la sesión si existe el hash y si existe el mismo en el
     * repositorio.
     *
     * @return bool Devuelve **true** si se pudo iniciar sesión
     */
    public function iniciarSesion()
    {
        if( !$this->hash->existe() ) {
            return false;
        }

        $hash = $this->hash->obtenerHash();
        $this->sesionIniciado = $this->repositorio->hashExiste($hash);
        return $this->sesionIniciado;
    }

    /**
     * Finaliza la sesión
     *
     * Elimina el hash del cliente y del servidor (si existen).
     *
     * @return bool Devuelve **true** si se borró exitosamente
     */
    public function finalizarSesion(): bool
    {
        if( !$this->hash->existe() ) {
            return false;
        }

        $hash = $this->hash->obtenerHash();
        $this->repositorio->eliminarHash($hash);
        $this->hash->eliminar();
        $this->sesionIniciado = false;
        return true;
    }

    /**
     * Verifica si se inició sesión
     *
     * @return bool
     */
    public function verificarSesion(): bool
    {
        return $this->sesionIniciado;
    }

    /**
     * Crea la sesión
     *
     * Crea un hash único y luego lo persiste en el cliente y en el repositorio
     *
     * @param IId $id Id de la cuenta a asociar a la sesión
     *
     * @return bool Devuelve el estado de la operación
     */
    public function crearSesion(IId $id): bool
    {
        if( $this->hash->existe() == false ) {
            $this->hash->regenerarHash();
        }

        return $this->hash->guardar() && $this->repositorio->persistirHash($this->hash->obtenerHash(), $id);
    }

    /**
     * Obtiene el id asociado al hash
     *
     * @return IId Devuelve el ID asociado al hash
     *
     * @throws ExcepcionHashIndefinido si no existe ningún hash en cookies
     * @throws ExcepcionHashInexistente si no existe ninguna cuenta asociada al hash
     */
    public function obtenerCuentaId(): IId
    {
        if( $this->hash->existe() == false ) {
            throw new ExcepcionHashIndefinido();
        }

        $hash = $this->hash->obtenerHash();
        if( $this->repositorio->hashExiste($hash) == false ) {
            $this->hash->eliminar();
            throw new ExcepcionHashInexistente($hash);
        }

        return $this->repositorio->obtenerCuentaIdSegunHash($hash);
    }

    /**
     * Establece si recordar la sesión
     *
     * @param bool $estado
     */
    public function recordar(bool $estado)
    {
        $this->hash->recordar = $estado;
    }

}
