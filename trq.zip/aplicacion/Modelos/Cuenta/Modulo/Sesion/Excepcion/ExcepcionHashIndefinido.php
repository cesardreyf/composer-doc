<?php

namespace Cuenta\Modulo\Sesion\Excepcion;

/**
 * Excepción lanzado cuando no existe ningún hash en cookies
 *
 * @package Cuenta\Modulo\Sesion\Excepcion
 */
class ExcepcionHashIndefinido extends Excepcion
{

    public $message = 'No se definió el Hash para la sesión';

}
