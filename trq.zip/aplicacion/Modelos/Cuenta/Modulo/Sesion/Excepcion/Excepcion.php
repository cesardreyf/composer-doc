<?php

namespace Cuenta\Modulo\Sesion\Excepcion;

use Contrato\Excepcion\IExcepcionPadre;
use Exception;

/**
 * Excepción del que extienden todas las excepciones del módulo
 *
 * @package Cuenta\Modulo\Sesion\Excepcion
 */
class Excepcion extends Exception implements IExcepcionPadre
{
}
