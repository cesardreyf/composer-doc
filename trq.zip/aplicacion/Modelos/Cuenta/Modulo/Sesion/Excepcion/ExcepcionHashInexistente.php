<?php

namespace Cuenta\Modulo\Sesion\Excepcion;

/**
 * Excepción lanzado cuando no existe el hash en el repositorio
 *
 * @package Cuenta\Modulo\Sesion\Excepcion
 */
class ExcepcionHashInexistente extends Excepcion
{

    /**
     * Constructor
     *
     * @param string $hash
     */
    public function __construct(string $hash)
    {
        parent::__construct("El hash '{$hash}' no existe en el repositorio");
    }

}
