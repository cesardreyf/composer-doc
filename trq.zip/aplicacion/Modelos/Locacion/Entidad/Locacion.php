<?php

namespace Locacion\Entidad;

use Locacion\Interfaz\ILocacion;

/**
 * Entidad que representa una ubicación
 *
 * @package Locacion\Entidad
 */
class Locacion implements ILocacion
{

    /**
     * Constructor
     *
     * @param int        $id
     * @param string     $nombre
     * @param ?ILocacion $padre
     */
    public function __construct(
        private int $id,
        private string $nombre,
        private ?ILocacion $padre = null
    )
    {
    }

    /**
     * Obtiene el identificador
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * Obtiene el nombre de la ubicación
     *
     * @return string
     */
    public function nombre(): string
    {
        return $this->nombre;
    }

    /**
     * Obtiene la locación padre
     *
     * @return ?ILocacion
     */
    public function padre(): ?ILocacion
    {
        return $this->padre;
    }

}
