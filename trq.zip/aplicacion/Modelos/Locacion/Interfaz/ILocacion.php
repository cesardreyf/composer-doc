<?php

namespace Locacion\Interfaz;

use Contrato\Componente\IId;

/**
 * Interfaz de acceso a los datos de una locación
 *
 * @package Locacion\Interfaz
 */
interface ILocacion extends IId
{

    /**
     * Obtiene el nombre de la ubicación
     *
     * @return string
     */
    public function nombre(): string;

    /**
     * Obtiene la locación padre
     *
     * Devuelve la instancia de la locación padre o null si no tiene.
     *
     * @return ?ILocacion
     */
    public function padre(): ?self;

}
