<?php

namespace Locacion\Interfaz;

/**
 * Interfaz para los contenedores de locaciones
 *
 * @package Locacion\Interfaz
 */
interface ILocaciones
{

    /**
     * Obtiene la lista de locaciones
     *
     * @return ILocacion[]
     */
    public function lista(): array;

}
