<?php

namespace Locacion\Modulo\Obtencion\Interfaz;

use Locacion\Interfaz\ILocacion;
use Locacion\Interfaz\ILocaciones;

/**
 * Interfaz para el repositorio de obtención de locaciones
 *
 * @package Locacion\Modulo\Obtencion\Interfaz
 */
interface IRepositorioObtencion
{

    /**
     * Verifica si existe la locación en el repositorio
     *
     * @param int $id Id de la locación a verificar
     *
     * @return bool
     */
    public function locacionExiste(int $id): bool;

    /**
     * Obtiene una locación completa según el ID
     *
     * @param int $id Id de la locación a obtener (junto a sus locaciones padres)
     *
     * @return ILocacion
     *
     * @throws \Throwable en caso de errores
     */
    public function obtenerLocacionCompletaPorId(int $id): ILocacion;

    /**
     * Obtiene una lista de locaciones según el ID de la locación padre
     *
     * @param ?ILocacion $padre Locación padre o null para obtener las locaciones principales
     *
     * @return ILocaciones
     *
     * @throws \Throwable en caso de errores
     */
    public function obtenerLocacionesSegunPadre(?ILocacion $padre): ILocaciones;

}
