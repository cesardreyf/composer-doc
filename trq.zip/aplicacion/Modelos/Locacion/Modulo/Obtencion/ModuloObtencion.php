<?php

namespace Locacion\Modulo\Obtencion;

use Locacion\Excepcion\ExcepcionLocacionInexistente;
use Locacion\Interfaz\ILocacion;
use Locacion\Interfaz\ILocaciones;
use Locacion\Modulo\Obtencion\Interfaz\IRepositorioObtencion;

/**
 * Módulo de obtención de locaciones
 *
 * @package Locacion\Modulo\Obtencion
 */
class ModuloObtencion
{

    /**
     * Constructor
     *
     * @param IRepositorioObtencion $repositorio Instancia del repositorio de obtención
     */
    public function __construct(private IRepositorioObtencion $repositorio)
    {
    }

    /**
     * Obtiene una locación basado en un identificador
     *
     * @param int $id Id de la ubicación principal
     *
     * @return ILocacion Devuelve una locación completa
     *
     * @throws ExcepcionLocacionInexistente si la locación solicitada no existe
     */
    public function obtenerLocacionPorId(int $id): ILocacion
    {
        if( $this->repositorio->locacionExiste($id) == false ) {
            throw new ExcepcionLocacionInexistente($id);
        }

        return $this->repositorio->obtenerLocacionCompletaPorId($id);
    }

    /**
     * Obtiene una lista de locaciones según el ID de la locación indicado
     *
     * @param int $id Id de la locación padre
     *
     * @return ILocaciones
     *
     * @throws ExcepcionLocacionInexistente si la locación padre no existe
     */
    public function obtenerLocacionesHijos(int $id): ILocaciones
    {
        if( $id == 0 ) {
            $locacionPadre = null;
        } else {
            // Si la locación no existe esta función lanzará la excepción
            $locacionPadre = $this->obtenerLocacionPorId($id);
        }

        return $this->repositorio->obtenerLocacionesSegunPadre($locacionPadre);
    }

    /**
     * Obtiene una lista de locaciones según los ID's solicitados
     *
     * @param int $id Id de la locación (obligatorio)
     * @param int ...$masIds Más id de locaciones (opcionales)
     *
     * @return ILocaciones
     */
    public function obtenerListaDeLocacionesSegunIds(int $id, int ...$masIds): ILocaciones
    {
        return $this->repositorio->obtenerLocacionesSegunIds($id, ...$masIds);
    }

}
