<?php

namespace Locacion\Excepcion;

/**
 * Excepcion lanzado cuando no se encuentra la locación solicitada
 *
 * @package Locacion\Excepcion
 */
class ExcepcionLocacionInexistente extends Excepcion
{

    /**
     * Constructor
     *
     * @param int $id Id de la locación inexistente
     */
    public function __construct(int $id)
    {
        parent::__construct("No existe ninguna locación que coincida con el ID {$id}");
    }

}
