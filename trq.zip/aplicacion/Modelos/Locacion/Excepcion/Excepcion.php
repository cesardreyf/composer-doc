<?php

namespace Locacion\Excepcion;

use Contrato\Excepcion\IExcepcionPadre;
use Exception;

/**
 * Excepción del que extienden todas las excepciones del modelo Locacion
 *
 * @package Locacion\Excepcion
 */
class Excepcion extends Exception implements IExcepcionPadre
{
}
