<?php

namespace Locacion\Contenedor;

use Locacion\Interfaz\ILocacion;
use Locacion\Interfaz\ILocaciones;

/**
 * Contenedor de locaciones
 *
 * @package Locacion\Contenedor
 */
class Locaciones implements ILocaciones
{

    /**
     * @var ILocacion[]
     */
    private array $locaciones = [];

    /**
     * Agrega una locación al contenedor
     *
     * @param ILocacion $locacion
     */
    public function agregar(ILocacion $locacion)
    {
        $this->locaciones[] = $locacion;
    }

    /**
     * Obtiene la lista de locaciones
     *
     * @return ILocacion[]
     */
    public function lista(): array
    {
        return $this->locaciones;
    }

    /**
     * Limpia la lista de locaciones
     */
    public function limpiar()
    {
        $this->locaciones = [];
    }

}
