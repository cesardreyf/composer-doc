<?php

namespace Categoria\Interfaz;

use Contrato\Componente\IId;

/**
 * Interfaz de acceso a los datos de una categoría
 *
 * @package Categoria\Interfaz
 */
interface ICategoria extends IId
{

    /**
     * Obtiene el nombre de la categoría
     *
     * @return string
     */
    public function nombre(): string;

    /**
     * Obtiene el alias de la categoría
     *
     * @return string
     */
    public function alias(): string;

}
