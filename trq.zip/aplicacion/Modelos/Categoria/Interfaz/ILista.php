<?php

namespace Categoria\Interfaz;

/**
 * Interfaz para acceder a un contenedor de categorías
 *
 * @package Categoria\Interfaz
 */
interface ILista
{

    /**
     * Obtiene la lista de categorías
     *
     * @return ICategoria[]
     */
    public function lista(): array;

}
