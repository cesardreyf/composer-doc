<?php

namespace Categoria\Excepcion;

use Contrato\Excepcion\IExcepcionPadre;
use Exception;

/**
 * Excepción del que extienden todas las excepciones del modelo Categoria
 *
 * @package Categoria\Excepcion
 */
class Excepcion extends Exception implements IExcepcionPadre
{
}
