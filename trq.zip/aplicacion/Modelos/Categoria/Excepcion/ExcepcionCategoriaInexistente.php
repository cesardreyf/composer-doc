<?php

namespace Categoria\Excepcion;

/**
 * Excepción lanzado cuando no se encuantra la categoría solicitada
 *
 * @package Categoria\Excepcion
 */
class ExcepcionCategoriaInexistente extends Excepcion
{
}
