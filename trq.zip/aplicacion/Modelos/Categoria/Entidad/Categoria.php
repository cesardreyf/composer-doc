<?php

namespace Categoria\Entidad;

use Categoria\Interfaz\ICategoria;

/**
 * Entidad que representa una categoría
 *
 * @package Categoria\Entidad
 */
class Categoria implements ICategoria
{

    /**
     * Constructor
     *
     * @param int    $id     Id de la categoría
     * @param string $alias  Alias de la categoría
     * @param string $nombre Nombre de la categoría
     */
    public function __construct(
        private int $id,
        private string $alias,
        private string $nombre
    )
    {
    }

    /**
     * Obtiene el identificador de la categoría
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * Obtiene el alias de la categoría
     *
     * @return string
     */
    public function alias(): string
    {
        return $this->alias;
    }

    /**
     * Obtiene el nombre de la categoría
     *
     * @return string
     */
    public function nombre(): string
    {
        return $this->nombre;
    }

}
