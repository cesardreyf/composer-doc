<?php

namespace Categoria\Modulo\Obtencion;

use Categoria\Excepcion\ExcepcionCategoriaInexistente;
use Categoria\Interfaz\ICategoria;
use Categoria\Interfaz\ILista;
use Categoria\Modulo\Obtencion\Interfaz\IRepositorioObtencion;

/**
 * Módulo de obtención de categorías
 *
 * @package Categoria\Modulo\Obtencion
 */
class ModuloObtencion
{

    /**
     * Constructor
     *
     * @param IRepositorioObtencion $repositorio
     */
    public function __construct(private IRepositorioObtencion $repositorio)
    {
    }

    /**
     * Obtiene todas las categorías
     *
     * @return ILista
     */
    public function obtenerCategorias(): ILista
    {
        return $this->repositorio->obtenerTodos();
    }

    /**
     * Obtiene una categoría según el alias
     *
     * @param string $alias
     *
     * @return ICategoria
     *
     * @throws ExcepcionCategoriaInexistente si la categoría solicitada no existe
     */
    public function obtenerCategoriaPorAlias(string $alias): ICategoria
    {
        if( !$this->repositorio->categoriaExiste($alias) ) {
            throw new ExcepcionCategoriaInexistente("No existe ninguna categoría con el alias '{$alias}' en el repositorio");
        }
        return $this->repositorio->obtenerCategoriaPorAlias($alias);
    }

}
