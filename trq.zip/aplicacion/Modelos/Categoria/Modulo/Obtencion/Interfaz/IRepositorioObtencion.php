<?php

namespace Categoria\Modulo\Obtencion\Interfaz;

use Categoria\Interfaz\ICategoria;
use Categoria\Interfaz\ILista;

/**
 * Interfaz para los repositorios de obtención de categorías
 *
 * @package Categoria\Modulo\Obtencion\Interfaz
 */
interface IRepositorioObtencion
{

    /**
     * Obtiene una lista con todas las categorías disponibles
     *
     * @return ILista
     */
    public function obtenerTodos(): ILista;

    /**
     * Verifica si existe la categoría en el repositorio
     *
     * @param string $alias Alias de la categoría
     *
     * @return bool
     */
    public function categoriaExiste(string $alias): bool;

    /**
     * Obtiene una categoría según el alias indicado
     *
     * @param string $alias Alias de la categoría
     *
     * @return ICategoria
     *
     * @throws \Throwable en caso de error
     */
    public function obtenerCategoriaPorAlias(string $alias): ICategoria;

}
