<?php

namespace Categoria\Contenedor;

use Categoria\Interfaz\ICategoria;
use Categoria\Interfaz\ILista;

/**
 * Contenedor de categorías
 *
 * @package Categoria\Contenedor
 */
class Categorias implements ILista
{

    /**
     * @var ICategoria[]
     */
    private array $lista;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->limpiar();
    }

    /**
     * Agrega una categoría a la lista
     *
     * @param ICategoria $categoria
     */
    public function agregar(ICategoria $categoria)
    {
        $this->lista[] = $categoria;
    }

    /**
     * Limpia la lista de categorías
     */
    public function limpiar()
    {
        $this->lista = [];
    }

    /**
     * Obtiene la lista de categorías almacenadas
     *
     * @return ICategoria[]
     */
    public function lista(): array
    {
        return $this->lista;
    }

}
