<?php

namespace Publicacion\Modulo\Persistencia\Excepcion;

use Publicacion\Excepcion\Excepcion;

/**
 * Excepción padre de las excepciones del módulo de persistencia
 *
 * @package Publicacion\Modulo\Persistencia\Excepcion
 */
class ExcepcionDePersistencia extends Excepcion
{
}
