<?php

namespace Publicacion\Modulo\Persistencia\Excepcion;

use Publicacion\Interfaz\IPublicacion;

/**
 * Excepción lanzado cuando no se puede persistir una publicación en el repositorio
 *
 * @package Publicacion\Modulo\Persistencia\Excepcion
 */
class ExcepcionErrorAlPersistir extends ExcepcionDePersistencia
{

    /**
     * Constructor
     *
     * @param IPublicacion $publicacion
     */
    public function __construct(public readonly IPublicacion $publicacion)
    {
        $this->message = 'No se pudo persistir la publicación en el repositorio. Consultar los errores del repositorio';
    }

}
