<?php

namespace Publicacion\Modulo\Persistencia\Interfaz;

use Publicacion\Interfaz\IPublicacion;

/**
 * Interfaz de acceso a un repositorio de persistencia de publicaciones
 *
 * @package Publicacion\Modulo\Persistencia\Interfaz
 */
interface IRepositorioPersistencia
{

    /**
     * Persiste los datos de la publicación
     *
     * @param IPublicacion $publicacion
     *
     * @throws \Throwable en caso de errores
     */
    public function persistirPublicacion(IPublicacion $publicacion);

}
