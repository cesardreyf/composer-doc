<?php

namespace Publicacion\Modulo\Persistencia\Entidad;

use Componente\Extension\ExtensionContenedorDeComponentes;
use Contrato\Componente\IEntidad;
use Contrato\Componente\IId;
use DateTime;
use Publicacion\Interfaz\IPublicacion;
use Publicacion\Modulo\Persistencia\Propiedad\Descripcion;
use Publicacion\Modulo\Persistencia\Propiedad\Titulo;

/**
 * Entidad que representa una publicación persistible
 *
 * La entidad almacena un conjunto de propiedades que pueden ser usados por un
 * gestor de validación y tratamiento de datos antes de pasarlo al módulo de
 * persistencia.
 *
 * @package Publicacion\Modulo\Persistencia\Entidad
 */
class PublicacionPersistible implements IPublicacion, IEntidad
{
    use ExtensionContenedorDeComponentes;

    /**
     * Constructor
     *
     * @param IId         $id          Identificador
     * @param IId         $autor       Id del autor
     * @param Titulo      $titulo      Propiedad título
     * @param Descripcion $descripcion Propiedad descripción
     * @param DateTime    $creacion    Fecha de creación
     */
    public function __construct(
        private IId $id,
        private IId $autor,
        private Titulo $titulo,
        private Descripcion $descripcion,
        private DateTime $creacion
    )
    {
        $this->agregarComponente(
            $titulo,
            $descripcion
        );
    }

    /**
     * Obtiene el identificador
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id->id();
    }

    /**
     * Obtiene el autor
     *
     * @return IId
     */
    public function autor(): IId
    {
        return $this->autor;
    }

    /**
     * Obtiene el título
     *
     * @return string
     */
    public function titulo(): string
    {
        return $this->titulo->valor();
    }

    /**
     * Obtiene la descripción
     *
     * @return string
     */
    public function descripcion(): string
    {
        return $this->descripcion->valor();
    }

    /**
     * Obtiene la fecha de creación
     *
     * @return DateTime
     */
    public function creacion(): DateTime
    {
        return $this->creacion;
    }

}
