<?php

namespace Publicacion\Modulo\Persistencia;

use Publicacion\Interfaz\IPublicacion;
use Publicacion\Modulo\Persistencia\Excepcion\ExcepcionErrorAlPersistir;
use Publicacion\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;

/**
 * Módulo de persistencia de publicaciones
 *
 * @package Publicacion\Modulo\Persistencia
 */
class ModuloPersistencia
{

    /**
     * Constructor
     *
     * @param IRepositorioPersistencia $repositorio
     */
    public function __construct(private IRepositorioPersistencia $repositorio)
    {
    }

    /**
     * Persiste la publicación en el repositorio
     *
     * @param IPublicacion $publicacion
     *
     * @throws ExcepcionErrorAlPersistir si no se pudo persistir la publicación
     */
    public function persistir(IPublicacion $publicacion)
    {
        if( !$this->repositorio->persistirPublicacion($publicacion) ) {
            throw new ExcepcionErrorAlPersistir($publicacion);
        }
    }

}
