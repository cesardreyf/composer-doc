<?php

namespace Publicacion\Modulo\Persistencia\Propiedad;

use Componente\Extension\ExtensionComponenteTratable;
use Componente\Extension\ExtensionComponenteValidable;
use Componente\Tratamiento\Cadena\ConvertirPrimeraLetraDeCadaPalabraEnMayuscula;
use Componente\Validacion\Cadena\ValidarLongitudLimitado;
use Componente\Validacion\Cadena\ValidarTitulo;
use Contrato\Componente\IComponente;
use Contrato\Tratamiento\ITratable;
use Contrato\Validacion\IValidable;

/**
 * Propiedad título
 *
 * La propiedad es validable y tratable.
 *
 * @package Publicacion\Modulo\Persistencia\Propiedad
 */
class Titulo implements IComponente, IValidable, ITratable
{
    use ExtensionComponenteTratable;
    use ExtensionComponenteValidable;

    /**
     * @var int Longitud mínimo exigido
     */
    public const LONGITUD_MINIMO = 5;

    /**
     * @var int Longitud máximo permitido
     */
    public const LONGITUD_MAXIMO = 128;

    /**
     * Nombre de la propiedad
     *
     * Nombre al que se asociarán los mensajes de error.
     *
     * @var string
     */
    public string $identificacion = 'titulo';

    /**
     * Constructor
     *
     * @param string $titulo
     */
    public function __construct(private string $titulo)
    {
        $this->validaciones = [
            new ValidarLongitudLimitado($titulo, self::LONGITUD_MINIMO, self::LONGITUD_MAXIMO),
            new ValidarTitulo($titulo),
        ];

        $this->tratamientos = [
            new ConvertirPrimeraLetraDeCadaPalabraEnMayuscula($this->titulo),
        ];
    }

    /**
     * Obtiene el título
     *
     * @return string
     */
    public function valor(): string
    {
        return $this->titulo;
    }

}
