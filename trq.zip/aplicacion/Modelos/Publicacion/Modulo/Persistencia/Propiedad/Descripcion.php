<?php

namespace Publicacion\Modulo\Persistencia\Propiedad;

use Componente\Extension\ExtensionComponenteTratable;
use Componente\Extension\ExtensionComponenteValidable;
use Componente\Validacion\Cadena\ValidarLongitudLimitado;
use Contrato\Componente\IComponente;
use Contrato\Tratamiento\ITratable;
use Contrato\Validacion\IValidable;

/**
 * Propiedad descripción
 *
 * La propiedad es validable y tratable.
 *
 * @package Publicacion\Modulo\Persistencia\Propiedad
 */
class Descripcion implements IComponente, IValidable//, ITratable
{
    // use ExtensionComponenteTratable;
    use ExtensionComponenteValidable;

    /**
     * @var int Longitud mínimo exigido
     */
    public const LONGITUD_MINIMO = 0;

    /**
     * @var int Longitud máximo permitido
     */
    public const LONGITUD_MAXIMO = 64000;

    /**
     * Constructor
     *
     * @param string $descripcion
     */
    public function __construct(private string $descripcion)
    {
        $this->validaciones = [
            new ValidarLongitudLimitado($descripcion, self::LONGITUD_MINIMO, self::LONGITUD_MAXIMO),
        ];

        // $this->tratamientos = [
        // ];
    }

    /**
     * Obtiene la descripción
     *
     * @return string
     */
    public function valor(): string
    {
        return $this->descripcion;
    }

}
