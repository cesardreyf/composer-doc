<?php

namespace Publicacion\Excepcion;

use Contrato\Excepcion\IExcepcionPadre;
use Exception;

/**
 * Excepción del que extienden todas las excepciones del modelo Publicacion
 *
 * @package Publicacion\Excepcion
 */
class Excepcion extends Exception implements IExcepcionPadre
{
}
