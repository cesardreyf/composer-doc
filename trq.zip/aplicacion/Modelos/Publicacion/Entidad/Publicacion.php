<?php

namespace Publicacion\Entidad;

use Contrato\Componente\IId;
use DateTime;
use Publicacion\Interfaz\IPublicacion;

/**
 * Entidad que representa una publicacion
 *
 * @package Publicacion\Entidad
 */
class Publicacion implements IPublicacion
{

    /**
     * Constructor
     *
     * @param int      $id          Id de la publicacion
     * @param IId      $autor       Id del autor de la publicacion
     * @param string   $titulo      Titulo de la publicacion
     * @param string   $descripcion Descripcion de la publicacion
     * @param DateTime $creacion    Fecha de creacion de la publicacion
     */
    public function __construct(
        private int $id,
        private IId $autor,
        private string $titulo,
        private string $descripcion,
        private DateTime $creacion
    )
    {
    }

    /**
     * Obtiene el id de la publicacion
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

    /**
     * Obtiene el id del autor de la publicacion
     *
     * @return IId
     */
    public function autor(): IId
    {
        return $this->autor;
    }

    /**
     * Obtiene el titulo de la publicacion
     *
     * @return string
     */
    public function titulo(): string
    {
        return $this->titulo;
    }

    /**
     * Obtiene la descripcion de la publicacion
     *
     * @return string
     */
    public function descripcion(): string
    {
        return $this->descripcion;
    }

    /**
     * Obtiene la fecha de creacion de la publicacion
     *
     * @return DateTime
     */
    public function creacion(): DateTime
    {
        return $this->creacion;
    }

}
