<?php

namespace Publicacion\Interfaz;

use Contrato\Componente\IId;
use DateTime;

/**
 * Interfaz de acceso a una publicación
 *
 * @package Publicacion\Interfaz
 */
interface IPublicacion extends IId
{

    /**
     * Obtiene el título de la publicación
     *
     * @return string
     */
    public function titulo(): string;

    /**
     * Obtiene el id del autor
     *
     * @return IId
     */
    public function autor(): IId;

    /**
     * Obtiene la descripción de la publicación
     *
     * @return string
     */
    public function descripcion(): string;

    /**
     * Obtiene el título de la publicación
     *
     * @return string
     */
    public function creacion(): DateTime;

}
