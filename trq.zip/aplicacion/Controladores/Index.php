<?php

namespace Controlador;

use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;

class Index implements Ejecutable
{

    public function ejecutar(DAP $app)
    {
        $app->datos();
        $app->vista()->renderizar();
    }

}
