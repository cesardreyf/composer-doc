<?php

namespace Controlador\Perfil;

use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;

class Ingresar implements Ejecutable
{

    public function ejecutar(DAP $app)
    {
        $this->definirDatos($app);
        $this->recordarDatos($app);

        if( $this->autenticarCuenta($app) ) {
            $app->redirigir()->a('');
            return;
        }

        $app->vista()->renderizar();
    }

    public function autenticarCuenta(DAP $app): bool
    {
        $solicitud = $this->obtenerDatosDelFormulario($app);

        if( !$solicitud->existe('enviado') ) {
            return false;
        }

        $gestorDeCuentas = $app->gestorDeCuentas();
        $resultado = $gestorDeCuentas->autenticarCuenta(
            $solicitud->obtenerString('correo'),
            $solicitud->obtenerString('clave')
        );

        if( $resultado == false ) {
            $errores = $gestorDeCuentas->errores()->lista();
            $app->datos()->definir('errores', $errores);
            return false;
        }

        return $this->guardarSesion($app);
    }

    public function definirDatos(DAP $app)
    {
        $app->datos()->web()->titulo('Iniciar sesión');
    }

    public function recordarDatos(DAP $app)
    {
        $solicitud = $this->obtenerDatosDelFormulario($app);
        $app->datos()->definir('recordar', [
            'correo' => $solicitud->obtenerString('correo')
        ]);
    }

    public function guardarSesion(DAP $app): bool
    {
        $gestorDeCuentas = $app->gestorDeCuentas();
        $cuenta = $gestorDeCuentas->obtenerCuentaId();
        $solicitud = $this->obtenerDatosDelFormulario($app);

        if( $cuenta->id() === 0 ) {
            return false;
        }

        $gestorDeSesion = $gestorDeCuentas->sesion();
        $gestorDeSesion->recordar($solicitud->obtenerBool('recordar'));

        // TAREA
        // Lanzar algún tipo de error si la función devuelve false lo que indicaría
        // que no se pudo crear la sesión en el cliente y/o en el servidor...
        return $gestorDeSesion->crearSesion($cuenta);
    }

    public function obtenerDatosDelFormulario(DAP $app)
    {
        return $app->solicitud()->desde()->post();
    }

}
