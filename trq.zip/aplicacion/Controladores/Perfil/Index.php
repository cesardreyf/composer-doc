<?php

namespace Controlador\Perfil;

use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;

class Index implements Ejecutable
{

    public function ejecutar(DAP $app)
    {
    }

}
