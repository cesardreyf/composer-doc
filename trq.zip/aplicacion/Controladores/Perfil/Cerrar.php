<?php

namespace Controlador\Perfil;

use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;

class Cerrar implements Ejecutable
{

    public function ejecutar(DAP $app)
    {
        $sesion = $app->gestorDeCuentas()->sesion();

        if( $sesion->verificarSesion() ) {
            $sesion->finalizarSesion();
        }

        $app->redirigir()->a('');
    }

}
