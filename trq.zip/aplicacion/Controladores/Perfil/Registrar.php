<?php

namespace Controlador\Perfil;

use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;

class Registrar implements Ejecutable
{

    public function ejecutar(DAP $app)
    {
        $this->definirDatos($app);
        $this->recordarDatos($app);

        if( $this->crearCuenta($app) ) {
            $app->redirigir()->a('perfil/ingresar');
            return;
        }

        $app->vista()->renderizar();
    }

    public function definirDatos(DAP $app)
    {
        $datos = $app->datos();
        $datos->web()->titulo('Crear cuenta');
    }

    public function crearCuenta(DAP $app): bool
    {
        // De momento GET, cuando se haga la plantilla para
        // la vista se cambiará por el método POST
        $solicitud = $app->solicitud()->desde()->post();

        if( !$solicitud->existe('enviado') ) {
            return false;
        }

        $gestorDeCuentas = $app->gestorDeCuentas();
        $cuenta = $gestorDeCuentas->crearCuenta(
            $solicitud->obtenerString('usuario'),
            $solicitud->obtenerString('correo'),
            $solicitud->obtenerString('clave'),
        );

        if( $gestorDeCuentas->errores()->hay() ) {
            $app->datos()->definir('errores', $gestorDeCuentas->errores()->lista());
            return false;
        }

        $app->datos()->definir('cuenta', $cuenta);
        return true;
    }

    public function recordarDatos(DAP $app)
    {
        $app->datos()->definir('recordar', $_POST);
    }

}
