<?php

namespace Gestor\Tratamiento;

use Contrato\Componente\IEntidad;
use Contrato\Tratamiento\ITratable;
use Contrato\Tratamiento\ITratador;

/**
 * Gestiona la aplicación de tratamiento a los componentes
 *
 * @package Gestor\Tratamiento
 */
class GestorDeTratamiento implements ITratador
{

    /**
     * Aplica el tratamiento a los datos del componente
     *
     * @param ITratable $componente
     */
    public function tratarComponente(ITratable $componente)
    {
        $componente->tratar();
    }

    /**
     * Aplica el tratamiento a los datos de los componentes
     *
     * @param ITratable $componente
     * @param ITratable ...$componentes
     */
    public function tratarComponentes(ITratable $componente, ITratable ...$componentes)
    {
        array_unshift($componentes, $componente);
        foreach( $componentes as $componente ) {
            $this->tratarComponente($componente);
        }
    }

    /**
     * Aplica el tratamiento a todos los componentes de la entidad
     *
     * Recorre la lista de componentes de la entidad y aplica el tratamiento a
     * todos los componentes que sean tratables.
     *
     * @param IEntidad $entidad
     */
    public function tratarEntidad(IEntidad $entidad)
    {
        foreach( $entidad->componentes() as $componente ) {
            if( $componente instanceof ITratable ) {
                $this->tratarComponente($componente);
            }
        }
    }

}
