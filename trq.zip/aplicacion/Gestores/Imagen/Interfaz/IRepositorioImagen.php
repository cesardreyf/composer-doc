<?php

namespace Gestor\Imagen\Interfaz;

use Contrato\Repositorio\IRepositorioBase;
use Imagen\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;

/**
 * Interfaz de acceso a los repositorios de imágenes
 *
 * @package Gestor\Imagen\Interfaz
 */
interface IRepositorioImagen extends IRepositorioBase
{

    /**
     * Obtiene el repositorio de persistencia de imágenes
     *
     * @return IRepositorioPersistencia
     */
    public function persistencia(): IRepositorioPersistencia;

}
