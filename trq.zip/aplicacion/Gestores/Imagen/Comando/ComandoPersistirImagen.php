<?php

namespace Gestor\Imagen\Comando;

use Contrato\Tratamiento\ITratador;
use Contrato\Validacion\IValidador;
use Gestor\Imagen\Interfaz\IRepositorioImagen;
use Gof\Interfaz\Archivos\Carpeta;
use Imagen\Contenedor\Imagenes;
use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;
use Imagen\Modulo\Persistencia\Entidad\ImagenPersistible;
use Imagen\Modulo\Persistencia\ModuloPersistencia;
use Imagen\Modulo\Persistencia\Propiedad\ArchivoImagen;

/**
 * Comando del gestor de imagen encargado de persistir imágenes
 *
 * @package Gestor\Imagen\Comando
 */
class ComandoPersistirImagen
{

    /**
     * @var ModuloPersistencia
     */
    private ModuloPersistencia $modulo;

    /**
     * @var ?IImagen Almacena la última imagen persistida
     */
    private ?IImagen $imagenPersistido = null;

    /**
     * @var ?IImagenes Almacena la última lista de imagenes persistidas
     */
    private ?IImagenes $imagenesPersistidos = null;

    /**
     * @var ?string Clave al que se asociarán los mensajes de errores en el registro
     */
    private ?string $claveDeError = null;

    /**
     * Constructor
     *
     * @param Carpeta            $carpetaDestino Carpeta local donde se alojarán las imágenes
     * @param IValidador         $validacion     Gestor de validación
     * @param ITratador          $tratamiento    Gestor de tratamiento
     * @param IRepositorioImagen $repositorio    Repositorio de imágenes
     */
    public function __construct(
        private Carpeta $carpetaDestino,
        private IValidador $validacion,
        private ITratador $tratamiento,
        private IRepositorioImagen $repositorio
    )
    {
        $this->modulo = new ModuloPersistencia($this->repositorio->persistencia());
    }

    /**
     * Persiste la imagen
     *
     * Valida los datos, le aplica un tratamiento a la imagen y luego lo
     * persiste en el repositorio. Si la operación es exitosa devolverá true,
     * caso contrario será false y los errores se deberán ver en el gestor de
     * validación.
     *
     * La imagen persistida se almacena internamente y es accesible a través
     * del método imagenPersitido.
     *
     * @param array $file Array con los datos de la imagen a persistir
     *
     * @return bool Devuelve el estado de la operación
     *
     * @see ComandoPersistirImagen::imagenPersistido()
     */
    public function persistirImagen(array $file): bool
    {
        $archivo = new ArchivoImagen($file, $this->carpetaDestino);
        $entidad = new ImagenPersistible(0, $archivo);

        // Cambia el nombre con el que se asociarán los errores en el registro
        if( !is_null($this->claveDeError) ) {
            $archivo->identificacion = $this->claveDeError;
        }

        if( !$this->validacion->validarEntidad($entidad) ) {
            return false;
        }

        $this->tratamiento->tratarEntidad($entidad);
        $this->modulo->persistirImagen($entidad);
        $this->imagenPersistido = $entidad;

        $this->imagenPersistido->editarId(
            $this->repositorio->ultimoIdInsertado()
        );

        return true;
    }

    /**
     * Persiste todas las imágenes del array
     *
     * Si una o más persistencia de la imagen falla se devuelve false y no se
     * continúan con las siguientes. Para ver los errores consultar con el
     * registro de mensajes.
     *
     * @param array $files Array con los datos de las imágenes a persistir
     *
     * @return bool Devuelve el estado de la operación
     */
    public function persistirImagenes(array $files): bool
    {
        if( empty($files) ) {
            return true;
        }

        $imagenes = new Imagenes();
        $this->ordenarDatosDelArray($files);

        foreach( $files as $clave => $file ) {
            $this->claveDeError = $clave;

            if( !$this->persistirImagen($file) ) {
                return false;
            }

            $imagenes->agregar($this->imagenPersistido());
        }

        $this->imagenesPersistidos = $imagenes;
        $this->claveDeError = null;
        return true;
    }

    /**
     * Obtiene la última imagen persitida
     *
     * @return ?IImagen
     */
    public function imagenPersistido(): ?IImagen
    {
        return $this->imagenPersistido;
    }

    /**
     * Obtiene la última lista de imágenes persistido
     *
     * @return ?IImagenes
     */
    public function imagenesPersistidos(): ?IImagenes
    {
        return $this->imagenesPersistidos;
    }

    /**
     * Ordena el array de datos de archivos por grupos
     *
     * @param array $files
     *
     * @return array
     *
     * @access private
     */
    private function ordenarDatosDelArray(array &$files)
    {
        $resultado = [];
        $cantidad = count($files['name']);
        $claves = array_keys($files);

        for( $i = 0; $i < $cantidad; $i++ ) {
            foreach( $claves as $clave ) {
                $resultado[$i][$clave] = $files[$clave][$i];
            }
        }

        $files = $resultado;
    }

}
