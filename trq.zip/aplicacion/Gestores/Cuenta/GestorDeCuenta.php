<?php

namespace Gestor\Cuenta;

use Componente\Extension\ExtensionComponenteInstanciador;
use Componente\Identificador;
use Contrato\Componente\IId;
use Contrato\Registro\IRegistro;
use Contrato\Tratamiento\ITratador;
use Contrato\Validacion\IValidador;
use Cuenta\Modulo\Obtencion\CuentaBasica;
use Cuenta\Modulo\Obtencion\Interfaz\ICuentaBasica;
use Cuenta\Modulo\Persistencia\Interfaz\ICuenta;
use Cuenta\Modulo\Sesion\Hash;
use Cuenta\Modulo\Sesion\ModuloSesion;
use Gestor\Cuenta\Comando\ComandoAutenticarCuenta;
use Gestor\Cuenta\Comando\ComandoCrearCuenta;
use Gestor\Cuenta\Interfaz\IRepositorioCuenta;
use Gof\Contrato\Cookies\Cookies;
use Gof\Contrato\Session\Session;

class GestorDeCuenta
{
    use ExtensionComponenteInstanciador;

    private ModuloSesion $moduloSesion;

    private IId $cuentaId;

    public function __construct(
        private IRegistro $registro,
        private IValidador $validacion,
        private ITratador $tratamiento,
        private IRepositorioCuenta $repositorio,
        private Cookies $gestorDeCookies,
        private Session $gestorDeSession,
    )
    {
        $this->cuentaId = new Identificador(0);
        $hash = new Hash($gestorDeCookies, $gestorDeSession);
        $this->moduloSesion = new ModuloSesion($hash, $this->repositorio->sesion());
    }

    public function crearCuenta(string $usuario, string $correo, string $clave): ICuenta
    {
        $comando = $this->instanciar(ComandoCrearCuenta::class, $usuario, $correo, $clave, $this->validacion, $this->tratamiento, $this->repositorio);
        return $comando->obtenerCuenta();
    }

    /**
     * Verifica si los datos proporcionados son auténticos
     *
     * Si los datos son válidos almacena el Id de la cuenta en el registro CuentaId.
     *
     * @param string $correo
     * @param string $clave
     *
     * @return bool Devuelve ele stado de la validación
     *
     * @see GestorDeCuenta::obtenerCuentaId() para obtener el ID
     */
    public function autenticarCuenta(string $correo, string $clave): bool
    {
        $comando = $this->instanciar(ComandoAutenticarCuenta::class, $correo, $clave, $this->validacion, $this->repositorio->autenticacion());

        if( $comando->estado() == false ) {
            return false;
        }

        $this->cuentaId = $comando->obtenerCuentaId();
        return true;
    }

    public function sesion(): ModuloSesion
    {
        return $this->moduloSesion;
    }

    public function obtenerCuentaSegunId(IId $cuenta): ICuentaBasica
    {
        return new CuentaBasica($cuenta, $this->repositorio->obtencion());
    }

    /**
     * Obtiene el registro de errores
     *
     * @return IRegistro
     */
    public function errores(): IRegistro
    {
        return $this->registro;
    }

    /**
     * Obtiene el valor del registro CuentaId
     *
     * El registro CuentaId puede ser modificado por las acciones del gestor.
     *
     * @return IId
     */
    public function obtenerCuentaId(): IId
    {
        return $this->cuentaId;
    }

}
