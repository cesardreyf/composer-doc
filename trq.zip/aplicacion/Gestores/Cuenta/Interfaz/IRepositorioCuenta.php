<?php

namespace Gestor\Cuenta\Interfaz;

use Contrato\Repositorio\IRepositorioBase;
use Cuenta\Modulo\Autenticacion\Interfaz\IRepositorioAutenticacion;
use Cuenta\Modulo\Obtencion\Interfaz\IRepositorioObtencion;
use Cuenta\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;
use Cuenta\Modulo\Sesion\Interfaz\IRepositorioSesion;

/**
 * Interfaz para el contenedor de repositorios para el gestor de cuentas
 *
 * @package Gestor\Cuenta\Interfaz
 */
interface IRepositorioCuenta extends IRepositorioBase
{

    /**
     * Obtiene el repositorio de persistencia
     *
     * @return IRepositorioPersistencia
     */
    public function persistencia(): IRepositorioPersistencia;

    /**
     * Obtiene el repositorio de autenticación
     *
     * @return IRepositorioAutenticacion
     */
    public function autenticacion(): IRepositorioAutenticacion;

    /**
     * Obtiene el repositorio de sesiones
     *
     * @return IRepositorioSesion
     */
    public function sesion(): IRepositorioSesion;

    /**
     * Obtiene el repositorio de obtención
     *
     * @return IRepositorioObtencion
     */
    public function obtencion(): IRepositorioObtencion;

}
