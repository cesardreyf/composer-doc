<?php

namespace Gestor\Cuenta\Comando;

use Componente\IdentificadorEditable;
use Contrato\Tratamiento\ITratador;
use Contrato\Validacion\IValidador;
use Cuenta\Modulo\Persistencia\CuentaPersistible;
use Cuenta\Modulo\Persistencia\Interfaz\ICuenta;
use Cuenta\Modulo\Persistencia\Propiedad\Clave;
use Cuenta\Modulo\Persistencia\Propiedad\Correo;
use Cuenta\Modulo\Persistencia\Propiedad\Usuario;
use Gestor\Cuenta\Interfaz\IRepositorioCuenta;

/**
 * Comando del gestor de cuentas encargado de crear una cuenta y persistirlo
 *
 * Crea una cuenta, valida los datos, le aplica un tratamiento y se lo pasa al
 * módulo de persistencia de cuentas.
 *
 * @package Gestor\Cuenta\Comando
 */
class ComandoCrearCuenta
{

    /**
     * @var Cuenta Almacena la cuenta
     */
    private readonly ICuenta $cuenta;

    /**
     * Constructor
     *
     * @param string             $usuario     Nombre de usuario
     * @param string             $correo      Dirección de correo electrónico
     * @param string             $clave       Contraseña
     * @param IValidador         $validacion  Gestor de validación
     * @param ITratador          $tratamiento Gestor de tratamientos
     * @param IRepositorioCuenta $repositorio Repositorio de persistencia
     */
    public function __construct(string $usuario, string $correo, string $clave, IValidador $validacion, ITratador $tratamiento, IRepositorioCuenta $repositorio)
    {
        $identificador = new IdentificadorEditable(0);
        $repositorioDePersistencia = $repositorio->persistencia();

        $this->cuenta = new CuentaPersistible(
            $identificador,
            new Usuario($usuario),
            new Correo($correo, $repositorioDePersistencia),
            new Clave($clave),
            $repositorioDePersistencia,
        );

        if( $validacion->validarEntidad($this->cuenta) ) {
            $tratamiento->tratarEntidad($this->cuenta);

            $repositorio->iniciarTransaccion();
            $this->cuenta->persistir();

            $identificador->editarId(
                $repositorio->ultimoIdInsertado()
            );

            $repositorio->finalizarTransaccion();
        }
    }

    /**
     * Obtiene la cuenta creada
     *
     * @return ICuenta
     */
    public function obtenerCuenta(): ICuenta
    {
        return $this->cuenta;
    }

}
