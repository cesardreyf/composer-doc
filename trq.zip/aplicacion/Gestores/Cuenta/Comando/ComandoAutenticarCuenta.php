<?php

namespace Gestor\Cuenta\Comando;

use Contrato\Componente\IId;
use Contrato\Validacion\IValidador;
use Cuenta\Modulo\Autenticacion\CuentaAutenticable;
use Cuenta\Modulo\Autenticacion\Interfaz\IRepositorioAutenticacion;
use Cuenta\Modulo\Autenticacion\Propiedad\Clave;
use Cuenta\Modulo\Autenticacion\Propiedad\Correo;

/**
 * Comando del gestor de cuentas encargado de autenticar los datos
 *
 * @package Gestor\Cuenta\Comando
 */
class ComandoAutenticarCuenta
{

    /**
     * @var Cuenta Almacena el estado de la autenticación
     */
    private bool $estado;

    /**
     * @var IId
     */
    private IId $cuentaId;

    /**
     * Constructor
     *
     * @param string     $correo      Correo
     * @param string     $clave       Contraseña
     * @param IValidador $validacion  Gestor de validación
     * @param IRepositorioAutenticacion $repositorio Repositorio de autenticación
     */
    public function __construct(string $correo, string $clave, IValidador $validacion, IRepositorioAutenticacion $repositorio)
    {
        $cuenta = new CuentaAutenticable(
            new Correo($correo, $repositorio),
            new Clave($clave),
            $repositorio,
        );

        $this->estado = $validacion->validarEntidad($cuenta) && $cuenta->autenticar();
        $this->cuentaId = $cuenta;
    }

    /**
     * Obtiene el estado de la validación de la autenticación
     *
     * @return bool
     */
    public function estado(): bool
    {
        return $this->estado;
    }

    public function obtenerCuentaId(): IId
    {
        return $this->cuentaId;
    }

}
