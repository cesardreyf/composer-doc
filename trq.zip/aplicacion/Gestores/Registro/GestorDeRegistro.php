<?php

namespace Gestor\Registro;

use Contrato\Registro\IRegistro;
use Gof\Gestor\Registro\Mensajes\RegistroDeMensajes;

/**
 * Gestor de registro de mensajes
 *
 * @package Gestor\Registro
 */
class GestorDeRegistro extends RegistroDeMensajes implements IRegistro
{
}
