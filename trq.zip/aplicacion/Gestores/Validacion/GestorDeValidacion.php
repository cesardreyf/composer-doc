<?php

namespace Gestor\Validacion;

use Contrato\Componente\IEntidad;
use Contrato\Registro\IRegistro;
use Contrato\Validacion\IValidable;
use Contrato\Validacion\IValidador;

/**
 * Gestor de validación de componentes
 *
 * Clase encargada de gestionar las validaciones de componentes como las
 * propiedades de una entidad.
 *
 * @package Gestor\Validacion
 */
class GestorDeValidacion implements IValidador
{

    /**
     * Constructor
     *
     * @param IRegistro $errores Registro de mensajes para los errores
     */
    public function __construct(private IRegistro $errores)
    {
    }

    /**
     * Valida el componente
     *
     * @param IValidable Componente a validar
     *
     * @return bool Devuelve el estado de la validación
     */
    public function validarComponente(IValidable $componente): bool
    {
        return $componente->validar($this->errores);
    }

    /**
     * Valida los componentes
     *
     * Valida todos los componentes pasados, pero solo devuelve **true** si
     * todos los componentes son válidos, caso contrario se devolverá **false**.
     *
     * Los mensajes de errores de cada propiedad los almacena en el registro
     * asociándolo al nombre del componente (identificacion).
     *
     * @param IValidable $componente     Componente a validar
     * @param IValidable ...$componentes Más componentes a validar
     *
     * @return bool Devuelve el estado de las validaciones general
     */
    public function validarComponentes(IValidable $componente, IValidable ...$componentes): bool
    {
        $resultadoGeneral = true;
        array_unshift($componentes, $componente);

        foreach( $componentes as $componente ) {
            $identificador = $componente->identificacion();
            $resultado = $componente->validar($this->errores->crearSubregistro($identificador));

            if( $resultadoGeneral == true ) {
                $resultadoGeneral = $resultado;
            }
        }

        if( $this->errores->hay() ) {
            $this->errores->guardar();
        }

        return $resultadoGeneral;
    }

    /**
     * Valida todos los componentes de una entidad
     *
     * Si la entidad no tiene componentes se devuelve **true**.
     *
     * @param IEntidad $entidad Entidad a validar sus componentes
     *
     * @return bool Devuelve **true** si todos sus componentes son válidos
     */
    public function validarEntidad(IEntidad $entidad): bool
    {
        $listaDeComponentes = $entidad->componentes();

        if( empty($listaDeComponentes) ) {
            return true;
        }

        $componentesValidables = [];
        foreach( $listaDeComponentes as $componente ) {
            if( $componente instanceof IValidable ) {
                $componentesValidables[] = $componente;
            }
        }

        return $this->validarComponentes(...$componentesValidables);
    }

}
