<?php

namespace Inter\Vista;

use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;
use Configuracion\Vista\ConfiguracionCSS;

/**
 * Inter encargado de agregar el gestor de datos a la app
 *
 * @package Inter
 */
class InterCssData implements Ejecutable
{

    /**
     * Agrega el gestor de datos a la app
     *
     * @param Gof\Sistema\MVC\Aplicacion\DAP\N2 $app Instancia del DAP.
     */
    public function ejecutar(DAP $app)
    {
        $app->datos()->definir('css', ConfiguracionCSS::data());
    }

}
