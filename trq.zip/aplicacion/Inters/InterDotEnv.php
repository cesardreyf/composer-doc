<?php

namespace Inter;

use Dotenv;
use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;

/**
 * Inter encargado de cargar las variables de entorno almacenadas en el archivo .env del proyecto
 *
 * @package Inter
 */
class InterDotEnv implements Ejecutable
{

    /**
     * @var array Variables de entorno requeridos
     */
    public const REQUERIDOS = [
        'BD_SERVIDOR',
        'BD_NOMBRE',
        'BD_USUARIO',
        'BD_CLAVE',
    ];

    /**
     * Carga las variables de entorno almacenadas en el archivo .env del proyecto
     *
     * @param Gof\Sistema\MVC\Aplicacion\DAP\N2 $app Instancia del DAP.
     *
     * @throws \Dotenv\Exception\InvalidPathException si el archivo .env no existe en la carpeta principal del proyecto
     */
    public function ejecutar(DAP $app)
    {
        $rutaDelArchivo = dirname(dirname(__DIR__));
        $dotEnv = Dotenv\Dotenv::createImmutable($rutaDelArchivo);
        $dotEnv->load();
        $dotEnv->required(self::REQUERIDOS);
    }

}
