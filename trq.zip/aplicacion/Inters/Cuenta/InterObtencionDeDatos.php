<?php

namespace Inter\Cuenta;

use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;

/**
 * Inter encargado de obtener los datos básicos de una cuenta si inició sesión
 *
 * @package Inter
 */
class InterObtencionDeDatos implements Ejecutable
{

    /**
     * Si el usuario inició sesión correctamente se obtiene los datos básicos de su cuenta
     *
     * Obtiene los datos básicos de la cuenta y lo agrega en Datos bajo la clave asociada 'cuenta'.
     *
     * @param Gof\Sistema\MVC\Aplicacion\DAP\N2 $app Instancia del DAP.
     */
    public function ejecutar(DAP $app)
    {
        $gestorDeCuentas = $app->gestorDeCuentas();
        if( $gestorDeCuentas->sesion()->iniciarSesion() === true ) {
            $cuentaId = $gestorDeCuentas->sesion()->obtenerCuentaId();
            $app->datos()->definir('cuenta', $gestorDeCuentas->obtenerCuentaSegunId($cuentaId));
        }
    }

}
