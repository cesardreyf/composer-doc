<?php

namespace Inter\Cuenta;

use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;

/**
 * Inter encargado de redireccionar al cliente a la página principal si está autenticado
 *
 * @package Inter
 */
class InterRedireccionarSiEstaAutenticado implements Ejecutable
{

    /**
     * Si el usuario está autenticado lo redirecciona a la página principal
     *
     * Si la cuenta está autenticada envía una cabecera HTTP de redirección y
     * finaliza la ejecución de la aplicación del sistema por lo que el controlador
     * y los siguientes inters no se ejecutarán.
     *
     * @param Gof\Sistema\MVC\Aplicacion\DAP\N2 $app Instancia del DAP.
     */
    public function ejecutar(DAP $app)
    {
        if( $app->gestorDeCuentas()->sesion()->iniciarSesion() === true ) {
            $app->redirigir()->paginaPrincipal();
            $app->sistema()->aplicacion()->interrumpir();
        }
    }

}
