<?php

namespace Inter;

use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;
use PDO;

/**
 * Inter encargado de agregar una instancia PDO al gestor de dependencias para su uso en los controladores
 *
 * @package Inter
 */
class InterPDO implements Ejecutable
{

    /**
     * Agrega una instancia PDO al gestor de dependencias
     *
     * @param Gof\Sistema\MVC\Aplicacion\DAP\N2 $app Instancia del DAP.
     */
    public function ejecutar(DAP $app)
    {
        $app->agregar(PDO::class, function() {
            return new PDO(
                "mysql:host={$_ENV['BD_SERVIDOR']};dbname={$_ENV['BD_NOMBRE']};charset=utf8",
                $_ENV['BD_USUARIO'],
                $_ENV['BD_CLAVE'],
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
                ]
            );
        });

        $app->asociarMetodo('pdo', PDO::class);
    }

}
