<?php

namespace Inter;

use Gestor\Cuenta\GestorDeCuenta;
use Gestor\Registro\GestorDeRegistro;
use Gestor\Tratamiento\GestorDeTratamiento;
use Gestor\Validacion\GestorDeValidacion;
use Gof\Sistema\MVC\Aplicacion\DAP\DAP;
use Gof\Sistema\MVC\Interfaz\Ejecutable;
use Repositorio\PDO\Cuenta\RepositorioCuenta;

/**
 * Inter encargado de agregar un gestor de cuentas a la app
 *
 * @package Inter
 */
class InterGestorDeCuenta implements Ejecutable
{

    /**
     * Agrega un gestor de cuentas al DAP y lo asocia al método gestorDeCuentas
     *
     * @param Gof\Sistema\MVC\Aplicacion\DAP\N2 $app Instancia del DAP.
     */
    public function ejecutar(DAP $app)
    {
        $registro = new GestorDeRegistro();

        $app->definir(GestorDeCuenta::class, new GestorDeCuenta(
            $registro,
            new GestorDeValidacion($registro),
            new GestorDeTratamiento(),
            new RepositorioCuenta($app->pdo()),
            $app->cookies(),
            $app->session(),
        ));

        // Asocia el método vista a la app
        $app->asociarMetodo('gestorDeCuentas', GestorDeCuenta::class);
    }

}
