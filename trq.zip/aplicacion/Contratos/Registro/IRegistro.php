<?php

namespace Contrato\Registro;

use Gof\Contrato\Registro\Mensajes\RegistroDeMensajes;

/**
 * Contrato para los gestores de registros de mensajes
 *
 * @package Contrato\Registro
 */
interface IRegistro extends RegistroDeMensajes
{
}
