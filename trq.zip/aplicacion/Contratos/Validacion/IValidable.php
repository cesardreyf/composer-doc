<?php

namespace Contrato\Validacion;

use Contrato\Componente\IComponenteValidable;
use Contrato\Componente\IIdentificacion;

/**
 * Contrato para las componentes validables
 *
 * @package contrato\Validacion
 */
interface IValidable extends IComponenteValidable, IIdentificacion
{
}
