<?php

namespace Contrato\Validacion;

use Contrato\Componente\IEntidad;

/**
 * Contrato para los gestores de validación
 *
 * @package Contrato\Validacion
 */
interface IValidador
{

    /**
     * Valida el componente
     *
     * @param IValidable $componente Componente a validar
     *
     * @return bool Devuelve el estado de la validación
     */
    public function validarComponente(IValidable $componente): bool;

    /**
     * Valida los componentes
     *
     * El valor de retorno solo será **true** si todas las validaciones son válidas.
     *
     * @param IValidable $componente     Componente a validar
     * @param IValidable ...$componentes Componentes a validar
     *
     * @return bool Devuelve el estado de la validación de todas las propiedades
     */
    public function validarComponentes(IValidable $componente, IValidable ...$componentes): bool;

    /**
     * Valida los componentes de una entidad
     *
     * @param IEntidad $entidad Entidad a validar sus componentes
     *
     * @return bool Devuelve **true** si todos sus componentes son válidos
     */
    public function validarEntidad(IEntidad $entidad): bool;

}
