<?php

namespace Contrato\Repositorio;

/**
 * Interfaz para acceder a operaciones atómicas
 *
 * @package Contrato\Repositorio
 */
interface IRepositorioAtomico
{

    /**
     * Inicializa una transacción
     *
     * @throws \Throwable en caso de error
     */
    public function iniciarTransaccion();

    /**
     * Finaliza una transacción
     *
     * @throws \Throwable en caso de error
     */
    public function finalizarTransaccion();

    /**
     * Revierte la transacción inicializada
     *
     * @throws \Throwable en caso de error
     */
    public function revertirTransaccion();

}
