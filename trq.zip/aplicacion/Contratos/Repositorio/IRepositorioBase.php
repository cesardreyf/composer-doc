<?php

namespace Contrato\Repositorio;

/**
 * Contrato para los repositorios base
 *
 * @package Contrato\Repositorio
 */
interface IRepositorioBase extends IRepositorioAtomico
{

    /**
     * Obtiene el último ID insertado
     *
     * @return int
     *
     * @throws \Throwable si no hubo ninguna inserción
     */
    public function ultimoIdInsertado(): int;

}
