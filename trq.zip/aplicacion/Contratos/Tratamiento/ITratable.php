<?php

namespace Contrato\Tratamiento;

/**
 * Interfaz para los componentes que requieran de un tratamiento de sus datos
 *
 * @package Contrato\Tratamiento
 */
interface ITratable
{

    /**
     * Aplica un tratamiento a los datos
     */
    public function tratar();

}
