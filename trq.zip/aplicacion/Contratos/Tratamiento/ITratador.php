<?php

namespace Contrato\Tratamiento;

use Contrato\Componente\IEntidad;

/**
 * Contrato para los gestores de tratamiento de datos
 *
 * @package Contrato\Tratamiento
 */
interface ITratador
{

    /**
     * Aplica un tratamiento al componente
     *
     * @param ITratable $componente
     */
    public function tratarComponente(ITratable $componente);

    /**
     * Aplica un tratamiento a los componentes
     *
     * @param ITratable $componente
     * @param ITratable ...$componentes
     */
    public function tratarComponentes(ITratable $componente, ITratable ...$componentes);

    /**
     * Aplica un tratamiento a todos los componentes de una entidad
     *
     * @param IEntidad $entidad
     */
    public function tratarEntidad(IEntidad $entidad);

}
