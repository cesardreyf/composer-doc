<?php

namespace Contrato\Componente;

/**
 * Contrato para el contenedor de componentes
 *
 * @package Contrato\Componente
 */
interface IListaDeComponentes
{

    /**
     * Obtiene la lista de componentes
     *
     * @return IComponente[]
     */
    public function lista(): array;

}
