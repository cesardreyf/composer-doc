<?php

namespace Contrato\Componente;

/**
 * Contrato base para los componentes
 *
 * Interfaz para acceder a un componente.
 *
 * @package Contrato\Componente
 */
interface IComponente
{
}
