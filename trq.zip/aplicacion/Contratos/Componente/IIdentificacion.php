<?php

namespace Contrato\Componente;

/**
 * Contrato para acceder al identificador de un componente
 *
 * @package Contrato\Componente
 */
interface IIdentificacion
{

    /**
     * Nombre con el que se puede identificar al componente
     *
     * @return string
     */
    public function identificacion(): string;

}
