<?php

namespace Contrato\Componente;

/**
 * Contrato para acceder a un componente que represente una entidad
 *
 * @package Contrato\Componente
 */
interface IEntidad extends IId
{

    /**
     * Obtiene el contenedor de componentes de la entidad
     *
     * @return IComponente[]
     */
    public function componentes(): array;

}
