<?php

namespace Contrato\Componente;

/**
 * Contrato para acceder al identificador numérico de un componente
 *
 * @package Contrato\Componente
 */
interface IId
{

    /**
     * Obtiene el identificador numérico
     *
     * @return int
     */
    public function id(): int;

}
