<?php

namespace Contrato\Componente;

use Contrato\Registro\IRegistro;

/**
 * Interfaz para los componentes validables
 *
 * @package Contrato\Componente
 */
interface IComponenteValidable
{

    /**
     * Valida los datos
     *
     * @param IRegistro $registro Registro de mensajes donde almacenar los errores
     *
     * @return bool Devuelve el estado de la validación
     */
    public function validar(IRegistro $registro): bool;

}
