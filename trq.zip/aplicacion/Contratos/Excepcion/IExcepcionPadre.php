<?php

namespace Contrato\Excepcion;

/**
 * Contrato para todas las excepciones de la aplicación
 *
 * @package Contrato\Excepcion
 */
interface IExcepcionPadre extends \Throwable
{
}
