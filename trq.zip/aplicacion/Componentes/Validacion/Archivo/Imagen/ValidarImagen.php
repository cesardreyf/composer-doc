<?php

namespace Componente\Validacion\Archivo\Imagen;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;
use Gmagick;
use GmagickException;
use RuntimeException;

/**
 * Componente que verifica si un archivo es una imagen válida
 *
 * @package Componente\Validacion\Archivo\Imagen
 */
class ValidarImagen implements IComponenteValidable
{

    /**
     * Constructor
     *
     * @param string $ruta Ruta de la imagen
     */
    public function __construct(private string $ruta)
    {
    }

    /**
     * Valida si el archivo es una imagen válida
     *
     * @param IRegistro $errores Registro donde se almacenarán los errores
     *
     * @return bool Devuelve el estado de la validación
     *
     * @throws RuntimeException si la ruta apunta a un archivo inexistente
     */
    public function validar(IRegistro $errores): bool
    {
        if( file_exists($this->ruta) == false ) {
            throw new RuntimeException("No existe el archivo: '{$this->ruta}'");
        }

        try {
            new Gmagick($this->ruta);
        } catch( GmagickException $e ) {
            $errores->agregarMensaje('El archivo subido no es una imagen válida');
            return false;
        }

        return true;
    }

}
