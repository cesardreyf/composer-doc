<?php

namespace Componente\Validacion\Archivo;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;
use InvalidArgumentException;

/**
 * Componente que valida los datos de un archivo subido al servidor
 *
 * @package Componente\Validacion\Archivo
 */
class ValidarFile implements IComponenteValidable
{

    /**
     * @var string[] Determina las columnas obligatorias para el array
     */
    public const COLUMNAS_REQUERIDAS = ['name', 'type', 'size', 'tmp_name', 'error'];

    /**
     * Constructor
     *
     * @param array $file      Array con los datos
     * @param int   $maxsize   Tamaño máximo en bytes permitido
     * @param array $extension Extensiones válidas para el archivo
     */
    public function __construct(
        private array $file,
        private int $maxsize,
        private array $extensiones
    )
    {
        $this->validarColumnasRequeridas();
        $this->validarTipoDeDatosDelArray();

        if( $maxsize < 0 ) {
            throw new InvalidArgumentException('El valor para el tamaño máximo del archivo no puede ser un número negativo');
        }
    }

    /**
     * Valida la imagen
     *
     * @param IRegistro $errores Registro donde se almacenarán los mensajes de error
     *
     * @return bool
     */
    public function validar(IRegistro $errores): bool
    {
        return $this->codigoDeErrorValido($errores)
            && $this->limiteNoExcedido($errores)
            && $this->extensionValido($errores);
    }

    /**
     * Verifica que las columnas obligatorias existan en el array
     *
     * @throws InvalidArgumentException si faltan columnas necesarias en el array
     */
    private function validarColumnasRequeridas()
    {
        $columnasFaltantes = array_diff(self::COLUMNAS_REQUERIDAS, array_keys($this->file));
        if( !empty($columnasFaltantes) ) {
            $columnasFaltantes = implode(', ', $columnasFaltantes);
            throw new InvalidArgumentException("Array inválido. Faltan columnas ({$columnasFaltantes})");
        }
    }

    /**
     * Verifica que el tipo de dato de los elementos del array correspondan con lo esperado
     *
     * Verifica que las columnas 'size' y 'error' sean de tipo Integer y que
     * las columnas 'name', 'tmp_name' y 'type' sean de tipo String.
     *
     * @throws InvalidArgumentException si los tipos de datos no son los esperados
     */
    private function validarTipoDeDatosDelArray()
    {
        static $tipoInt = ['size', 'error'];
        static $tipoString = ['name', 'tmp_name', 'type'];

        foreach( $tipoString as $columna ) {
            if( !is_string($this->file[$columna]) ) {
                throw new InvalidArgumentException("La columna {$columna} debe ser de tipo string");
            }
        }

        foreach( $tipoInt as $columna ) {
            if( !is_int($this->file[$columna]) ) {
                throw new InvalidArgumentException("La columna {$columna} debe ser de tipo int");
            }
        }
    }

    /**
     * Verifica el código de error de la imágen subida
     *
     * @param IRegistro $errores
     *
     * @return bool
     */
    private function codigoDeErrorValido(IRegistro $errores): bool
    {
        switch( $this->file['error'] ) {
            case UPLOAD_ERR_OK:
                return true;

            case UPLOAD_ERR_INI_SIZE:
                $error = $errores->preparar('El tamaño del archivo supera el máximo permitido por el servidor (\1)');
                $error->vincular(1, ini_get('upload_max_filesize') . 'b');
                $error->guardar();
                break;

            case UPLOAD_ERR_PARTIAL:
                $errores->agregarMensaje('El archivo no se subió correctamente');
                break;

            case UPLOAD_ERR_NO_FILE:
                $errores->agregarMensaje('No se subió ningún archivo');
                break;

            // TAREA: Generar un reporte
            case UPLOAD_ERR_NO_TMP_DIR:
            case UPLOAD_ERR_CANT_WRITE:
                $errores->agregarMensaje('Ocurrió un error interno en el servidor al momento de guardar la imagen');
                break;

            default:
                $errores->agregarMensaje('Error inesperado');
                break;
        }
        return false;
    }

    /**
     * Verifica que el tamaño de la imagen no exceda los límites establecidos
     *
     * @param IRegistro $errores
     *
     * @return bool
     */
    private function limiteNoExcedido(IRegistro $errores): bool
    {
        if( $this->file['size'] > $this->maxsize ) {
            $error = $errores->preparar('El tamaño máximo permitido es de \1 Mb');
            $error->vincular(1, number_format($this->maxsize / 1048576, 2));
            $error->guardar();
            return false;
        }
        return true;
    }

    /**
     * Verifica que la extensión de la imagen sea válido
     *
     * @param IRegistro $errores
     *
     * @return bool
     */
    private function extensionValido(IRegistro $errores): bool
    {
        $extensionDeLaImagen = pathinfo($this->file['name'], PATHINFO_EXTENSION);
        if( !in_array($extensionDeLaImagen, $this->extensiones) ) {
            $error = $errores->preparar('Solo se permiten archivos con extensión: \1');
            $error->vincular(1, implode(', ', $this->extensiones));
            $error->guardar();
            return false;
        }
        return true;
    }

}
