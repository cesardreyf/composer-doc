<?php

namespace Componente\Validacion\Cadena;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;

/**
 * Componente abstracto para la validación de expresiones regulares
 *
 * @package Componente\Validacion\Cadena
 */
abstract class ValidarExpresionRegular implements IComponenteValidable
{

    /**
     * @var string Almacena la expresión regular
     */
    protected string $expresionRegular = '';

    /**
     * @var string Almacena el mensaje de error
     */
    protected string $mensajeDeError = '';

    /**
     * Constructor
     *
     * @param string $cadena Cadena a validar
     */
    public function __construct(public string $cadena)
    {
    }

    /**
     * Valida la expresión regular
     *
     * @param IRegistro $errores
     *
     * @return bool
     */
    public function validar(IRegistro $errores): bool
    {
        if( !preg_match($this->expresionRegular, $this->cadena) ) {
            $errores->agregarMensaje($this->mensajeDeError);
            return false;
        }

        return true;
    }

}
