<?php

namespace Componente\Validacion\Cadena;

/**
 * Componente de validación de cadenas que deben contener al menos un carácter numérico
 *
 * @package Componente\Validacion\Cadena
 */
class ValidarQueContieneAlMenosUnCaracterNumerico extends ValidarExpresionRegular
{

    /**
     * @var string
     */
    public const ERROR_MENSAJE = 'Debe contener al menos un carácter numérico';

    /**
     * @var string Expresión regular
     */
    protected string $expresionRegular = '/[0-9]+/';

    /**
     * @var string Mensaje de error
     */
    protected string $mensajeDeError = self::ERROR_MENSAJE;

}
