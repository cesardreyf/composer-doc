<?php

namespace Componente\Validacion\Cadena;

/**
 * Componente de validación de cadenas que deben contener al menos un caracter en minúscula
 *
 * @package Componente\Validacion\Cadena
 */
class ValidarQueContieneAlMenosUnCaracterEnMinuscula extends ValidarExpresionRegular
{

    /**
     * @var string
     */
    public const ERROR_MENSAJE = 'Debe contener al menos un caracter en minúscula';

    /**
     * @var string Expresión regular
     */
    protected string $expresionRegular = '/[\p{Ll}]+/u';

    /**
     * @var string Mensaje de error
     */
    protected string $mensajeDeError = self::ERROR_MENSAJE;

}
