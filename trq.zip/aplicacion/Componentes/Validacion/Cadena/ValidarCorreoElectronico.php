<?php

namespace Componente\Validacion\Cadena;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;

/**
 * Componente de validación de direcciones de correo electrónico
 *
 * Este compomente se encarga de validar que la dirección de correo tenga el
 * formato correcto.
 *
 * @package Componente\Validacion\Cadena
 */
class ValidarCorreoElectronico implements IComponenteValidable
{

    /**
     * @var string Mensaje de error
     */
    public const ERROR_MENSAJE = 'La dirección del correo electrónico no es válido';

    /**
     * Constructor
     *
     * @param string $correo Dirección de correo electrónico
     */
    public function __construct(public string $correo)
    {
    }

    /**
     * Valida que el correo sea válido
     *
     * @param IRegistro $errores Registro donde se almacenarán los errores
     *
     * @return bool Devuelve el estado de la validación
     */
    public function validar(IRegistro $errores): bool
    {
        if( !filter_var($this->correo, FILTER_VALIDATE_EMAIL) ) {
            $errores->agregarMensaje(self::ERROR_MENSAJE);
            return false;
        }

        return true;
    }

}
