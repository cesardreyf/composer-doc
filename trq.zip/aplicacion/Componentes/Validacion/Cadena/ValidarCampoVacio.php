<?php

namespace Componente\Validacion\Cadena;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;

/**
 * Componente de validación que verifica si el campo está vacío
 *
 * @package Componente\Validacion\Cadena
 */
class ValidarCampoVacio implements IComponenteValidable
{

    /**
     * @var string Mensaje de error para cuando la longitud es menor al permitido
     */
    public const ERROR_MENSAJE = 'Campo vacío';

    /**
     * Constructor
     *
     * @param string $cadena Cadena a validar
     */
    public function __construct(public string $cadena)
    {
    }

    /**
     * Valida que la cadena no esté vacía
     *
     * @param IRegistro $errores Registro donde se almacenarán los mensajes de error
     *
     * @return bool Devuelve el estado de la validación
     */
    public function validar(IRegistro $errores): bool
    {
        if( trim($this->cadena) == '' ) {
            $errores->agregarMensaje(self::ERROR_MENSAJE);
            return false;
        }

        return true;
    }

}
