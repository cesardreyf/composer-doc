<?php

namespace Componente\Validacion\Cadena;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;

/**
 * Componente de validación para títulos
 *
 * Este componente valida una cadena para verificar que sea propicio para un título.
 *
 * @package Componente\Validacion\Cadena
 */
class ValidarTitulo extends ValidarExpresionRegular implements IComponenteValidable
{

    /**
     * @var string Mensaje de error
     */
    public const ERROR_MENSAJE = 'El título solo puede contener caracteres alfanuméricos y signos (¿?¡!.,\'"/°$%&())';

    /**
     * @var string Expresión regular para la validación de la cadena
     */
    protected string $expresionRegular = '/^[0-9a-zñáéíóúü\s¿?¡!.,\'"\/°\$%&()]+$/ui';

    /**
     * @var string Mensaje de error
     */
    protected string $mensajeDeError = self::ERROR_MENSAJE;

}
