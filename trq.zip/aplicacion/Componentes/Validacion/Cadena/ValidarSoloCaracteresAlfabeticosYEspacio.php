<?php

namespace Componente\Validacion\Cadena;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;

/**
 * Componente de validación de caracteres
 *
 * Este componente valida que la cadena contenga caracteres del alfabeto
 * español y espacios. No es sensible a mayúsculas.
 *
 * @package Componente\Validacion\Cadena
 */
class ValidarSoloCaracteresAlfabeticosYEspacio extends ValidarExpresionRegular implements IComponenteValidable
{

    /**
     * @var string Mensaje de error
     */
    public const ERROR_MENSAJE = 'Solo puede contener caracteres alfabéticos(a-z) y espacio';

    /**
     * @var string Expresión regular para la validación de la cadena
     */
    protected string $expresionRegular = '/^[a-zñáéíóúü\s]+$/i';

    /**
     * @var string Mensaje de error
     */
    protected string $mensajeDeError = self::ERROR_MENSAJE;

}
