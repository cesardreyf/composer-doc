<?php

namespace Componente\Validacion\Cadena;

/**
 * Componente de validación de cadenas que deben contener al menos un carácter en mayúscula
 *
 * @package Componente\Validacion\Cadena
 */
class ValidarQueContieneAlMenosUnCaracterEnMayuscula extends ValidarExpresionRegular
{

    /**
     * @var string
     */
    public const ERROR_MENSAJE = 'Debe contener al menos un caracter en mayúscula';

    /**
     * @var string Expresión regular
     */
    protected string $expresionRegular = '/[\p{Lu}]+/u';

    /**
     * @var string Mensaje de error
     */
    protected string $mensajeDeError = self::ERROR_MENSAJE;

}
