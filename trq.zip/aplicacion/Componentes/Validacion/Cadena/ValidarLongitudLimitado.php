<?php

namespace Componente\Validacion\Cadena;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;

/**
 * Componente de validación de datos relacionados con la longitud de una cadena
 *
 * @package Componente\Validacion\Cadena
 */
class ValidarLongitudLimitado implements IComponenteValidable
{

    /**
     * @var string Mensaje de error para cuando la longitud es menor al permitido
     */
    public const ERROR_LONGITUD_MINIMO_INCUMPLIDO = 'La longitud mínimo es de \1 caracteres';

    /**
     * @var string Mensaje de error para cuando la longitud es mayor al permitido
     */
    public const ERROR_LONGITUD_MAXIMO_EXCEDIDO = 'La longitud máximo es de \1 caracteres';

    /**
     * Constructor
     *
     * @param string $cadena Cadena a validar
     * @param int    $minimo Longitud mínimo de caracteres permitidos
     * @param int    $maximo Longitud máximo de caracteres permitidos
     */
    public function __construct(public string $cadena, public int $minimo, public int $maximo)
    {
    }

    /**
     * Valida que la cadena esté dentro de los límites permitidos
     *
     * @param IRegistro $errores Registro donde se almacenarán los mensajes de error
     *
     * @return bool Devuelve el estado de la validación
     */
    public function validar(IRegistro $errores): bool
    {
        $longitud = mb_strlen($this->cadena);

        if( $longitud < $this->minimo ) {
            $error = $errores->preparar(self::ERROR_LONGITUD_MINIMO_INCUMPLIDO);
            $error->vincular(1, $this->minimo);
            $error->guardar();
            return false;
        }

        if( $longitud > $this->maximo ) {
            $error = $errores->preparar(self::ERROR_LONGITUD_MAXIMO_EXCEDIDO);
            $error->vincular(1, $this->maximo);
            $error->guardar();
            return false;
        }

        return true;
    }

}
