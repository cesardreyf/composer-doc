<?php

namespace Componente\Tratamiento\Archivo;

use Contrato\Tratamiento\ITratable;
use RuntimeException;

/**
 * Componente que mueve un archivo (subido) a otro sitio (local)
 *
 * Recibe los datos del archivo a mover y una vez llamado a la función 'tratar'
 * ejecuta la operación. Si la misma es exitosa los datos de las propiedades
 * nombre y ruta de la clase cambiarán con los nuevos valores asignados.
 *
 * La clase hace uso de la función move_uploaded_file por lo que solo moverá
 * archivos subidos por los clientes a través de un formulario web.
 *
 * @package Componente\Tratamiento\Archivo
 */
class MoverArchivo implements ITratable
{

    /**
     * Constructor
     *
     * @param string &$nombre Nombre completo del archivo (referencia)
     * @param string &$ruta   Ruta local del archivo a mover (referencia)
     * @param string $carpeta Ruta de la carpeta donde se moverá el archivo
     */
    public function __construct(private string &$nombre, private string &$ruta, private string $carpeta)
    {
    }

    /**
     * Mueve el archivo y le proporciona un nombre único y aleatorio
     *
     * @see MoverArchivo::nombreAleatorio()
     *
     * @throws RuntimeException si no se pudo mover el archivo
     */
    public function tratar()
    {
        $extension    = pathinfo($this->nombre, PATHINFO_EXTENSION);
        $this->nombre = $this->nombreAleatorio() . ".{$extension}";
        $rutaDestino  = $this->carpeta . $this->nombre;

        if( !$this->moverArchivo($this->ruta, $rutaDestino) ) {
            throw new RuntimeException("No se pudo mover el archivo '{$this->ruta}' a la carpeta '{$this->carpeta}'");
        }

        $this->ruta = $rutaDestino;
    }

    /**
     * Mueve el archivo de ubicación
     *
     * @param string $rutaOrigen
     * @param string $rutaDestino
     *
     * @return bool
     */
    public function moverArchivo(string $rutaOrigen, string $rutaDestino): bool
    {
        return move_uploaded_file($rutaOrigen, $rutaDestino);
    }

    /**
     * Obtiene un nombre aleatorio y único
     *
     * @return string
     */
    public function nombreAleatorio(): string
    {
        return uniqid() . '_' . bin2hex(random_bytes(16));
    }

}
