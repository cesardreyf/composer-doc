<?php

namespace Componente\Tratamiento\Archivo\Imagen;

use Contrato\Tratamiento\ITratable;
use Gmagick;

/**
 * Componente que limpia los metadatos de imágenes
 *
 * @package Componente\Tratamiento\Archivo\Imagen
 */
class LimpiarMetadatos implements ITratable
{

    /**
     * Constructor
     *
     * @param string &$ruta Ruta del archivo
     */
    public function __construct(private string &$ruta)
    {
    }

    /**
     * Limpia los metadatos de la imagen
     *
     * Remueve los datos exif que existan en la imagen.
     */
    public function tratar()
    {
        $imagen = new Gmagick();
        $imagen->readImage($this->ruta);
        $imagen->stripImage();
        $imagen->profileImage('*', '');
        $imagen->writeImage($this->ruta);
        $imagen->destroy();
    }

}
