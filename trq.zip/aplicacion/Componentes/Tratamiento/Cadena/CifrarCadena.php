<?php

namespace Componente\Tratamiento\Cadena;

use Componente\Seguridad\Clave;
use Contrato\Tratamiento\ITratable;

/**
 * Cifra la cadena
 *
 * @package Componente\Tratamiento\Cadena
 */
class CifrarCadena implements ITratable
{

    /**
     * Constructor
     *
     * @param string &$cadena Referencia a la cadena a aplicar el tratamiento
     */
    public function __construct(public string &$cadena)
    {
    }

    /**
     * Cifra la cadena
     */
    public function tratar()
    {
        $this->cadena = Clave::cifrar($this->cadena);
    }

}
