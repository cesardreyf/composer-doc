<?php

namespace Componente\Tratamiento\Cadena;

use Contrato\Tratamiento\ITratable;

/**
 * Componente que convierte los caracteres de una cadena a minúscula
 *
 * @package Componente\Tratamiento\Cadena
 */
class ConvertirTodoEnMinuscula implements ITratable
{

    /**
     * Constructor
     *
     * @param string &$cadena Cadena a aplicar el tratamiento
     */
    public function __construct(public string &$cadena)
    {
    }

    /**
     * Convierte el contenido de la cadena en minúscula
     */
    public function tratar()
    {
        $this->cadena = mb_strtolower($this->cadena);
    }

}
