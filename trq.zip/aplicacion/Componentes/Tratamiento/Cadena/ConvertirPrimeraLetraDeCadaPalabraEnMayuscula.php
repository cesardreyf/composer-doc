<?php

namespace Componente\Tratamiento\Cadena;

use Contrato\Tratamiento\ITratable;

/**
 * Convierte las primeras letras de cada palabra en mayúscula
 *
 * @package Componente\Tratamiento\Cadena
 */
class ConvertirPrimeraLetraDeCadaPalabraEnMayuscula implements ITratable
{

    /**
     * Constructor
     *
     * @param string &$cadena Referencia a la cadena a aplicar el tratamiento
     */
    public function __construct(public string &$cadena)
    {
    }

    /**
     * Convierte la primera letra de cada palabra de la cadena en mayúscula
     */
    public function tratar()
    {
        $this->cadena = mb_convert_case($this->cadena, MB_CASE_TITLE);
    }

}
