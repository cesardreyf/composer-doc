<?php

namespace Componente;

/**
 * Componente identificador que implementa la interfaz Contrato\Componente\IId
 *
 * @package Componente
 */
class IdentificadorEditable extends Identificador
{

    /**
     * Edita el id
     *
     * @param int $id
     */
    public function editarId(int $id)
    {
        $this->id = $id;
    }

}
