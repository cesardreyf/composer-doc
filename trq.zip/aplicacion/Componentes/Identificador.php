<?php

namespace Componente;

use Contrato\Componente\IComponente;
use Contrato\Componente\IId;

/**
 * Componente identificador que implementa la interfaz Contrato\Componente\IId
 *
 * @package Componente
 */
class Identificador implements IId, IComponente
{

    /**
     * Constructor
     *
     * @param int $id Identificador numérico
     */
    public function __construct(protected int $id)
    {
    }

    /**
     * Obtiene una instancia de la clase con los valores de otra instancia
     *
     * @param static $identificador
     */
    public static function desde(self $identificador)
    {
        return new static($identificador->id());
    }

    /**
     * Obtiene el ID
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

}
