<?php

namespace Componente\Seguridad;

/**
 * Componente de cifrado y validación de claves de acceso
 *
 * @package Componente\Seguridad
 */
class Clave
{

    /**
     * Cifra la clave y obtiene un hash
     *
     * @param string $clave Clave a cifrar
     *
     * @return string
     */
    public static function cifrar(string $clave): string
    {
        return password_hash($clave, PASSWORD_DEFAULT);
    }

    /**
     * Valida que la clave coincida con el hash
     *
     * @param string $clave Clave a validar
     * @param string $hash  Hash de la clave
     *
     * @return bool Devuelve el estado de la validación
     */
    public static function validar(string $clave, string $hash): bool
    {
        return password_verify($clave, $hash);
    }

}
