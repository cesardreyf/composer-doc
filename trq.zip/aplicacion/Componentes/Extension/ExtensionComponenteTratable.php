<?php

namespace Componente\Extension;

use Contrato\Tratamiento\ITratable;

/**
 * Trait compatible con el contrato ITratable
 *
 * @package Componente\Extension
 */
trait ExtensionComponenteTratable
{

    /**
     * @var ITratable[]
     */
    protected array $tratamientos = [];

    /**
     * Aplica un tratamiento a los datos del componente
     */
    public function tratar()
    {
        array_walk($this->tratamientos, function(ITratable $componente) {
            $componente->tratar();
        });
    }

    /**
     * Obtiene la lista de componentes almacenados
     *
     * @return ITratable[]
     */
    public function obtenerListaDeComponentesTratables(): array
    {
        return $this->tratamientos;
    }

}
