<?php

namespace Componente\Extension;

/**
 * Trait compatible con el contrato Contrato\Componente\IId
 *
 * @package Componente\Extension
 */
trait ExtensionComponenteId
{

    /**
     * @var int Id numérico
     */
    protected int $id = 0;

    /**
     * Obtiene el ID
     *
     * @return int
     */
    public function id(): int
    {
        return $this->id;
    }

}
