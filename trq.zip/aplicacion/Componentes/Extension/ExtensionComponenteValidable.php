<?php

namespace Componente\Extension;

use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;

/**
 * Trait compatible con el contrato IValidable
 *
 * Requiere la declaración de la variable $identificacion con el nombre de la
 * propiedad.
 *
 * @package Componente\Extension
 */
trait ExtensionComponenteValidable
{

    /**
     * @var IComponenteValidable[]
     */
    protected array $validaciones = [];

    /**
     * Valida los datos del componente
     *
     * @param IRegistro $errores Registro donde se almacenarán los errores (si los hay)
     *
     * @return bool Devuelve el estado de la validación
     */
    public function validar(IRegistro $errores): bool
    {
        $valido = fn(IComponenteValidable $componente) => $componente->validar($errores);
        foreach( $this->validaciones as $componente ) {
            if( !$valido($componente) ) {
                return false;
            }
        }
        return true;
    }

    /**
     * Obtiene la lista de componentes almacenados
     *
     * @return IValidable[]
     */
    public function obtenerListaDeComponentesValidables(): array
    {
        return $this->validaciones;
    }

    /**
     * Obtiene el nombre del componente
     *
     * @return string
     */
    public function identificacion(): string
    {
        return $this->identificacion;
    }

}
