<?php

namespace Componente\Extension;

use Contrato\Componente\IComponente;

/**
 * Trait compatible con el contrato Contrato\Componente\IEntidad
 *
 * @package Componente\Extension
 */
trait ExtensionContenedorDeComponentes
{

    /**
     * @var IComponente[] Almacena los componentes de la entidad
     */
    protected array $listaDeComponentes = [];

    /**
     * Agrega un nuevo componente al contenedor
     *
     * @param IComponente $componente Instancia del componente
     * @param IComponente ...$componentes
     */
    protected function agregarComponente(IComponente $componente, IComponente ...$componentes)
    {
        array_unshift($componentes, $componente);
        foreach( $componentes as $componente ) {
            $this->listaDeComponentes[] = $componente;
        }
    }

    /**
     * Obtiene la lista de componentes
     *
     * @return IComponente[]
     */
    public function componentes(): array
    {
        return $this->listaDeComponentes;
    }

}
