<?php

namespace Componente\Extension;

/**
 * Trait que permite crear instancias a través de un mediador
 *
 * @package Componente\Extension
 */
trait ExtensionComponenteInstanciador
{

    /**
     * Crea una instancia de la clase indicada y le pasa los argumentos al constructor
     *
     * @param string $clase Nombre completo de la clase a instanciar
     * @param mixed ...$argumentos Argumentos a ser pasados al constructor
     *
     * @return object Instancia de la clase
     */
    protected function instanciar(string $clase, mixed ...$argumentos): object
    {
        return new $clase(...$argumentos);
    }

}
