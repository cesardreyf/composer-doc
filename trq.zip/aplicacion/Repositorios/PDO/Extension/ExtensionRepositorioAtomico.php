<?php

namespace Repositorio\PDO\Extension;

/**
 * Trait compatible con el contrato Contrato\Repositorio\IRepositorioAtomico
 *
 * De momento no soporta múltiples transacciones (pronto...)
 *
 * NOTA: Requiere de una propiedad $this->pdo.
 *
 * @package Repositorio\PDO\Extension
 */
trait ExtensionRepositorioAtomico
{

    /**
     * Inicializa la transacción
     */
    public function iniciarTransaccion()
    {
        $this->pdo->beginTransaction();
    }

    /**
     * Finaliza la transacción
     */
    public function finalizarTransaccion()
    {
        $this->pdo->commit();
    }

    /**
     * Revierte la transacción
     */
    public function revertirTransaccion()
    {
        $this->pdo->rollBack();
    }

}
