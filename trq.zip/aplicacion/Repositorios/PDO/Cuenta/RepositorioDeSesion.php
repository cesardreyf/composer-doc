<?php

namespace Repositorio\PDO\Cuenta;

use Contrato\Componente\IId;
use Cuenta\Modulo\Sesion\Interfaz\IRepositorioSesion;
use PDO;
use Repositorio\PDO\Abstraccion\RepositorioBase;
use Componente\Identificador;

class RepositorioDeSesion extends RepositorioBase implements IRepositorioSesion
{

    public function hashExiste(string $hash): bool
    {
        $stmt = $this->pdo->prepare('
            SELECT COUNT(*)
            FROM sesiones
            WHERE hash = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $hash, PDO::PARAM_STR);
        return $stmt->execute() && $stmt->fetchColumn() > 0;
    }

    public function eliminarHash(string $hash)
    {
        $stmt = $this->pdo->prepare('
            DELETE FROM sesiones
            WHERE hash = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $hash, PDO::PARAM_STR);
        $stmt->execute();
    }

    public function persistirHash(string $hash, IId $id): bool
    {
        $stmt = $this->pdo->prepare('
            INSERT INTO sesiones (hash, cuenta_id)
            VALUE (?, ?)
        ');

        $stmt->bindValue(1, $hash, PDO::PARAM_STR);
        $stmt->bindValue(2, $id->id(), PDO::PARAM_INT);
        return $stmt->execute() && $stmt->rowCount() > 0;
    }

    public function obtenerCuentaIdSegunHash(string $hash): IId
    {
        $stmt = $this->pdo->prepare('
            SELECT cuenta_id
            FROM sesiones
            WHERE hash = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $hash, PDO::PARAM_STR);
        $stmt->setFetchMode(PDO::FETCH_NUM);
        
        if( !$stmt->execute() || $stmt->rowCount() < 1 ) {
            throw new ExcepcionSesionInexistente($hash);
        }

        return new Identificador($stmt->fetchColumn());
    }

}
