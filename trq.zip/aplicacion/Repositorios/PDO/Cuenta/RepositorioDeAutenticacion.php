<?php

namespace Repositorio\PDO\Cuenta;

use Cuenta\Interfaz\ICorreo;
use Cuenta\Modulo\Autenticacion\Interfaz\IRepositorioAutenticacion;
use PDO;
use Repositorio\PDO\Abstraccion\RepositorioBase;

/**
 * Repositorio PDO fuertemente acoplado al módulo de autenticación
 *
 * @package Repositorio\PDO\Cuenta
 */
class RepositorioDeAutenticacion extends RepositorioBase implements IRepositorioAutenticacion
{

    /**
     * @var string Almacena temporalmente el correo
     */
    private string $correo = '';

    /**
     * @var string Almacena temporalmente la clave
     */
    private ?string $clave = null;

    /**
     * @var string Almacena temporalmente el ID de la cuenta
     */
    private int $id = 0;

    /**
     * Verifica si el correo existe en la base de datos
     *
     * @param ICorreo $correo
     *
     * @return bool
     */
    public function correoExiste(ICorreo $correo): bool
    {
        if( $this->correo === $correo->valor() ) {
            return true;
        }

        return $this->actualizarDatosDeLaCuentaSegunElCorreoElectronico($correo->valor());
    }

    /**
     * Obtiene el hash de la cuenta según el correo electrónico
     *
     * @param ICorreo $correo
     *
     * @return string
     *
     * @throws ExcepcionCorreoInexistente si el correo no existe en BD
     */
    public function obtenerClaveSegunCorreo(ICorreo $correo): string
    {
        if( $this->clave && $this->correo === $correo->valor() ) {
            return $this->clave;
        }

        if( $this->actualizarDatosDeLaCuentaSegunElCorreoElectronico($correo->valor()) == false ) {
            throw new ExcepcionCorreoInexistente($correo->valor());
        }

        return $this->clave;
    }

    /**
     * Obtiene el ID de la cuenta según el correo
     *
     * @param ICorreo $correo
     *
     * @return int
     *
     * @throws ExcepcionCorreoInexistente si el correo no existe en base de datos
     */
    public function obtenerIdSegunCorreo(ICorreo $correo): int
    {
        if( $this->correo === $correo->valor() ) {
            return $this->id;
        }

        if( $this->actualizarDatosDeLaCuentaSegunElCorreoElectronico($correo->valor()) == false ) {
            throw new ExcepcionCorreoInexistente($correo->valor());
        }

        return $this->id;
    }

    /**
     * Obtiene el hash según el correo de la cuenta
     *
     * @param string $correo
     *
     * @return string Hash de la cuenta o una cadena vacía si no hubo coincidencia
     */
    private function actualizarDatosDeLaCuentaSegunElCorreoElectronico(string $correo): bool
    {
        $stmt = $this->pdo->prepare('
            SELECT id, clave
            FROM cuentas
            WHERE correo = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $correo, PDO::PARAM_STR);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

        if( !$stmt->execute() || $stmt->rowCount() < 1 ) {
            return false;
        }

        $datos = $stmt->fetch();
        $this->correo = $correo;
        $this->id = $datos['id'];
        $this->clave = $datos['clave'];
        return true;
    }

}
