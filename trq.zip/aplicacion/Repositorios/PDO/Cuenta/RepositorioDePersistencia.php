<?php

namespace Repositorio\PDO\Cuenta;

use Cuenta\Interfaz\IClave;
use Cuenta\Interfaz\ICorreo;
use Cuenta\Interfaz\IUsuario;
use Cuenta\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;
use PDO;
use Repositorio\PDO\Abstraccion\RepositorioBase;

/**
 * Repostorio PDO de persistencia de cuentas
 *
 * @package Repositorio\PDO\Cuenta
 */
class RepositorioDePersistencia extends RepositorioBase implements IRepositorioPersistencia
{

    /**
     * Verifica si el correo existe en la base de datos
     *
     * @param string $correo Correo a validar
     *
     * @return bool Devuelve el estado de la validación
     */
    public function persistirCuenta(IUsuario $usuario, ICorreo $correo, IClave $clave): bool
    {
        $stmt = $this->pdo->prepare('
            INSERT INTO cuentas (usuario, correo, clave)
            VALUE (?, ?, ?)
        ');

        $stmt->bindValue(1, $usuario->valor(), PDO::PARAM_STR);
        $stmt->bindValue(2, $correo->valor(), PDO::PARAM_STR);
        $stmt->bindValue(3, $clave->valor(), PDO::PARAM_STR);

        return $stmt->execute() && $stmt->rowCount();
    }

    /**
     * Persiste los datos de la cuenta en la base de datos
     *
     * @param IUsuario $usuario Datos del usuario
     * @param ICorreo  $correo  Datos del correo
     * @param IClave   $clave   Datos de la clave
     *
     * @return bool Devuelve **true** si se persistió correctamente o **false** de lo contrario
     */
    public function correoExiste(string $correo): bool
    {
        $stmt = $this->pdo->prepare('
            SELECT COUNT(*)
            FROM cuentas
            WHERE correo = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $correo, PDO::PARAM_STR);
        return $stmt->execute() && $stmt->fetchColumn() > 0;
    }

}
