<?php

namespace Repositorio\PDO\Cuenta;

use Cuenta\Modulo\Autenticacion\Interfaz\IRepositorioAutenticacion;
use Cuenta\Modulo\Obtencion\Interfaz\IRepositorioObtencion;
use Cuenta\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;
use Cuenta\Modulo\Sesion\Interfaz\IRepositorioSesion;
use Gestor\Cuenta\Interfaz\IRepositorioCuenta;
use Repositorio\PDO\Abstraccion\RepositorioBase;

/**
 * Repositorio contenedor de los repositorios relacionados con el modelo Cuenta
 *
 * @package Repositorio\PDO\Cuenta
 */
class RepositorioCuenta extends RepositorioBase implements IRepositorioCuenta
{

    private IRepositorioPersistencia $rPersistencia;

    private IRepositorioAutenticacion $rAutenticacion;

    private IRepositorioSesion $rSesion;

    private IRepositorioObtencion $rObtencion;

    /**
     * Obtiene el repositorio de persistencia
     *
     * @return IRepositorioPersistencia
     */
    public function persistencia(): IRepositorioPersistencia
    {
        return $this->rPersistencia ?? $this->rPersistencia = new RepositorioDePersistencia($this->pdo);
    }

    /**
     * Obtiene el repositorio de autenticación
     *
     * @return IRepositorioAutenticacion
     */
    public function autenticacion(): IRepositorioAutenticacion
    {
        return $this->rAutenticacion ?? $this->rAutenticacion = new RepositorioDeAutenticacion($this->pdo);
    }

    /**
     * Obtiene el repositorio de sesiones
     *
     * @return IRepositorioSesion
     */
    public function sesion(): IRepositorioSesion
    {
        return $this->rSesion ?? $this->rSesion = new RepositorioDeSesion($this->pdo);
    }

    /**
     * Obtiene el repositorio de obtención de datos de cuentas
     *
     * @return IRepositorioObtencion
     */
    public function obtencion(): IRepositorioObtencion
    {
        return $this->rObtencion ?? $this->rObtencion = new RepositorioDeObtencion($this->pdo);
    }

}
