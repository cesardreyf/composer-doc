<?php

namespace Repositorio\PDO\Cuenta;

use Contrato\Componente\IId;
use Cuenta\Modulo\Obtencion\Interfaz\IRepositorioObtencion;
use PDO;
use Repositorio\PDO\Abstraccion\RepositorioBase;

/**
 * Repositorio PDO de obtención de propiedades de una cuenta
 *
 * @package Repositorio\PDO\Cuenta
 */
class RepositorioDeObtencion extends RepositorioBase implements IRepositorioObtencion
{

    private ?IId $id = null;

    private string $usuario = '';

    private string $correo = '';

    public function existe(IId $cuenta): bool
    {
        return $this->actualizarDatosSegunElId($cuenta);
    }

    public function obtenerUsuarioSegunId(IId $cuenta): string
    {
        if( $this->id === $cuenta ) {
            return $this->usuario;
        }

        if( !$this->existe($cuenta) ) {
            throw new ExcepcionCuentaInexistente($cuenta);
        }

        return $this->usuario;
    }

    public function obtenerCorreoSegunId(IId $cuenta): string
    {
        if( $this->id === $cuenta ) {
            return $this->correo;
        }

        if( !$this->existe($cuenta) ) {
            throw new ExcepcionCuentaInexistente($cuenta);
        }

        return $this->correo;
    }

    private function actualizarDatosSegunElId(IId $cuenta): bool
    {
        $stmt = $this->pdo->prepare('
            SELECT usuario, correo
            FROM cuentas
            WHERE id = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $cuenta->id(), PDO::PARAM_INT);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

        if( $stmt->execute() == false || $stmt->rowCount() < 1 ) {
            return false;
        }

        $datos = $stmt->fetch();
        $this->usuario = $datos['usuario'];
        $this->correo = $datos['correo'];
        $this->id = $cuenta;
        return true;
    }

}
