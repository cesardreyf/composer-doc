<?php

namespace Repositorio\PDO\Excepcion;

use Contrato\Excepcion\IExcepcionPadre;
use Exception;

/**
 * Excepción del que extienden todas las excepciones de los repositorios PDO
 *
 * @package Repositorio\PDO\Excepcion
 */
class Excepcion extends Exception implements IExcepcionPadre
{
}
