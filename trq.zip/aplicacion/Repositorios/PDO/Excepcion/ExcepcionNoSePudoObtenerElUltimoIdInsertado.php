<?php

namespace Repositorio\PDO\Excepcion;

/**
 * Excepción lanzado cuando no se puede obtener el último id insertado
 *
 * @package Repositorio\PDO\Excepcion
 */
class ExcepcionNoSePudoObtenerElUltimoIdInsertado extends Excepcion
{
}
