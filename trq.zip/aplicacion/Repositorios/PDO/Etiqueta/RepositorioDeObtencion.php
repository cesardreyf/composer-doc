<?php

namespace Repositorio\PDO\Etiqueta;

use Etiqueta\Contenedor\Etiquetas;
use Etiqueta\Entidad\Etiqueta;
use Etiqueta\Interfaz\IEtiqueta;
use Etiqueta\Interfaz\IEtiquetas;
use Etiqueta\Modulo\Obtencion\Interfaz\IRepositorioObtencion;
use PDO;
use Repositorio\PDO\Abstraccion\RepositorioBase;
use Repositorio\PDO\Excepcion\Excepcion;

class RepositorioDeObtencion extends RepositorioBase implements IRepositorioObtencion
{

    public function etiquetaExiste(int $id): bool
    {
        $stmt = $this->pdo->prepare('
            SELECT COUNT(*)
            FROM etiquetas
            WHERE id = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $id, PDO::PARAM_INT);
        return $stmt->execute() && $stmt->fetchColumn() > 0;
    }

    public function obtenerEtiquetaSegunId(int $id): IEtiqueta
    {
        $stmt = $this->pdo->prepare('
            SELECT nombre
            FROM etiquetas
            WHERE id = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $id, PDO::PARAM_INT);
        if( !$stmt->execute() || $stmt->rowCount() < 1 ) {
            throw new Excepcion("No existe ninguna etiqueta con el id {$id}");
        }

        return new Etiqueta($id, $stmt->fetch(PDO::FETCH_COLUMN));
    }

    public function obtenerEtiquetasSegunIds(int $id, int ...$ids): IEtiquetas
    {
        array_unshift($ids, $id);
        $ids = implode(', ', $ids);

        $stmt = $this->pdo->prepare("
            SELECT id, nombre
            FROM etiquetas
            WHERE id IN ({$ids})
        ");

        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $etiquetas = new Etiquetas();

        while( $etiqueta = $stmt->fetch() ) {
            $etiquetas->agregar(
                new Etiqueta(
                    (int)$etiqueta['id'],
                    $etiqueta['nombre']
                )
            );
        }

        return $etiquetas;
    }

}
