<?php

namespace Repositorio\PDO\Publicacion;

use PDO;
use Publicacion\Interfaz\IPublicacion;
use Publicacion\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;
use Repositorio\PDO\Abstraccion\RepositorioBase;

class RepositorioDePersistencia extends RepositorioBase implements IRepositorioPersistencia
{

    public function persistirPublicacion(IPublicacion $publicacion): bool
    {
        $stmt = $this->pdo->prepare('
            INSERT INTO publicaciones (titulo, descripcion, autor, creacion)
            VALUE (:titulo, :descripcion, :autor, CURRENT_TIMESTAMP())
        ');

        $stmt->bindValue(':titulo', $publicacion->titulo(), PDO::PARAM_STR);
        $stmt->bindValue(':autor', $publicacion->autor()->id(), PDO::PARAM_INT);
        $stmt->bindValue(':descripcion', $publicacion->descripcion(), PDO::PARAM_STR);
        return $stmt->execute() && $stmt->rowCount() > 0;
    }

}
