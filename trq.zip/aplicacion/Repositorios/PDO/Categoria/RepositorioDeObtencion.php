<?php

namespace Repositorio\PDO\Categoria;

use Categoria\Contenedor\Categorias;
use Categoria\Entidad\Categoria;
use Categoria\Interfaz\ICategoria;
use Categoria\Interfaz\ILista;
use Categoria\Modulo\Obtencion\Interfaz\IRepositorioObtencion;
use PDO;
use Repositorio\PDO\Abstraccion\RepositorioBase;
use Repositorio\PDO\Excepcion\Excepcion;

class RepositorioDeObtencion extends RepositorioBase implements IRepositorioObtencion
{

    public function categoriaExiste(string $alias): bool
    {
        $stmt = $this->pdo->prepare('
            SELECT COUNT(*)
            FROM categorias
            WHERE alias = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $alias, PDO::PARAM_STR);
        return $stmt->execute() && $stmt->fetchColumn() > 0;
    }

    public function obtenerTodos(): ILista
    {
        $stmt = $this->pdo->prepare('
            SELECT id, alias, nombre
            FROM categorias
        ');

        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        $contenedor = new Categorias();
        while( $categoria = $stmt->fetch() ) {
            $contenedor->agregar(
                $this->obtenerCategoriaDesdeArray($categoria)
            );
        }

        return $contenedor;
    }

    public function obtenerCategoriaPorAlias(string $alias): ICategoria
    {
        $stmt = $this->pdo->prepare('
            SELECT id, alias, nombre
            FROM categorias
            WHERE alias = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $alias, PDO::PARAM_STR);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

        if( !$stmt->execute() || $stmt->rowCount() < 1 ) {
            throw new Excepcion("No existe ninguna categoría con el alias '{$alias}'");
        }

        return $this->obtenerCategoriaDesdeArray($stmt->fetch());
    }

    protected function obtenerCategoriaDesdeArray(array $categoria): ICategoria
    {
        return new Categoria(
            $categoria['id'],
            $categoria['alias'],
            $categoria['nombre']
        );
    }

}
