<?php

namespace Repositorio\PDO\Abstraccion;

use Contrato\Repositorio\IRepositorioAtomico;
use Contrato\Repositorio\IRepositorioBase;
use PDO;
use Repositorio\PDO\Excepcion\ExcepcionNoSePudoObtenerElUltimoIdInsertado;
use Repositorio\PDO\Extension\ExtensionRepositorioAtomico;

abstract class RepositorioBase implements IRepositorioBase, IRepositorioAtomico
{
    use ExtensionRepositorioAtomico;

    /**
     * Constructor
     *
     * @param PDO $pdo
     */
    public function __construct(protected PDO $pdo)
    {
    }

    /**
     * Obtiene el último ID insertado en base de datos
     *
     * @return int
     */
    public function ultimoIdInsertado(): int
    {
        $ultimoIdInsertado = $this->pdo->lastInsertId();
        if( $ultimoIdInsertado !== false ) {
            return (int)$ultimoIdInsertado;
        }
        throw new ExcepcionNoSePudoObtenerElUltimoIdInsertado();
    }

}
