<?php

namespace Repositorio\PDO\Imagen;

use Gestor\Imagen\Interfaz\IRepositorioImagen;
use Imagen\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;
use Repositorio\PDO\Abstraccion\RepositorioBase;

/**
 * Repositorio PDO de imágenes
 *
 * @package Repositorio\PDO\Imagen
 */
class RepositorioImagen extends RepositorioBase implements IRepositorioImagen
{

    private IRepositorioPersistencia $persistencia;

    /**
     * Obtiene el repositorio PDO de persistencia de imágenes
     *
     * @return IRepositorioPersistencia
     */
    public function persistencia(): IRepositorioPersistencia
    {
        return $this->persistencia ?? $this->persistencia = new RepositorioDePersistencia($this->pdo);
    }

}
