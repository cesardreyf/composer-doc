<?php

namespace Repositorio\PDO\Imagen;

use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;
use Imagen\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;
use Repositorio\PDO\Abstraccion\RepositorioBase;
use PDO;

/**
 * Repositorio PDO de persistencia de imágenes en base de datos
 *
 * @package Repositorio\PDO\Imagen
 */
class RepositorioDePersistencia extends RepositorioBase implements IRepositorioPersistencia
{

    /**
     * Guarda los datos de la imagen en base de datos
     *
     * @param IImagen $imagen
     *
     * @return bool Devuelve el estado de la persistencia
     */
    public function persistirImagen(IImagen $imagen): bool
    {
        $stmt = $this->pdo->prepare('
            INSERT INTO imagenes (nombre)
            VALUE (?)
        ');

        $stmt->bindValue(1, $imagen->nombre(), PDO::PARAM_STR);
        return $stmt->execute() && $stmt->rowCount() > 0;
    }

    /**
     * Guarda los datos de las imagenes en base de datos
     *
     * @param IImagenes $imagenes
     *
     * @return bool Devuelve el estado de la persistencia
     */
    public function persistirImagenes(IImagenes $imagenes): bool
    {
        $listaDeImagenes = $imagenes->lista();

        if( empty($listaDeImagenes) ) {
            return true;
        }

        $listaDeNombres = [];
        foreach( $listaDeImagenes as $imagen ) {
            $listaDeNombres[] = $imagen->nombre();
        }

        $signos = implode(', ', array_fill(0, count($listaDeNombres), '(?)'));
        $stmt = $this->pdo->prepare("
            INSERT INTO imagenes (nombre)
            VALUES {$signos}
        ");

        foreach( $listaDeNombres as $i => $nombre ) {
            $stmt->bindValue($i + 1, $nombre, PDO::PARAM_STR);
        }

        return $stmt->execute() && $stmt->rowCount() > 0;
    }

}
