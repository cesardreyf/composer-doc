<?php

namespace Repositorio\PDO\Imagen;

use Imagen\Contenedor\Imagenes;
use Imagen\Entidad\Imagen;
use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;
use Imagen\Modulo\Obtencion\Interfaz\IRepositorioObtencion;
use PDO;
use Repositorio\PDO\Abstraccion\RepositorioBase;
use Repositorio\PDO\Excepcion\Excepcion;

class RepositorioDeObtencion extends RepositorioBase implements IRepositorioObtencion
{

    public function imagenExisteSegunId(int $id): bool
    {
        $stmt = $this->pdo->prepare('
            SELECT COUNT(*)
            FROM imagenes
            WHERE id = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $id, PDO::PARAM_INT);
        return $stmt->execute() && $stmt->fetchColumn > 0;
    }

    public function consultarExistenciaDeImagenesSegunId(int $id, int ...$masIds): array
    {
        $ids = array_merge([$id], $masIds);
        $idsString = implode(', ', $ids);

        $stmt = $this->pdo->prepare("
            SELECT id
            FROM imagenes
            WHERE id IN ({$idsString})
        ");

        $stmt->setFetchMode(PDO::FETCH_COLUMN, 0);
        $stmt->execute();

        $idsObtenidos = $stmt->fetchAll();
        return array_diff($ids, $idsObtenidos);
    }

    public function obtenerImagenSegunId(int $id): IImagen
    {
        $stmt = $this->pdo->prepare('
            SELECT nombre
            FROM imagenes
            WHERE id = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $id, PDO::PARAM_INT);
        $stmt->setFetchMode(PDO::FETCH_COLUMN, 0);
        $stmt->execute();

        if( $stmt->rowCount() < 1 ) {
            throw new Excepcion("No existe ningún registro con el id {$id}");
        }

        return new Imagen($id, $stmt->fetch());
    }

    public function obtenerImagenesSegunId(int $id, int ...$masIds): IImagenes
    {
        $ids = array_merge([$id], $masIds);
        $idsString = implode(', ', $ids);

        $stmt = $this->pdo->prepare("
            SELECT id, nombre
            FROM imagenes
            WHERE id IN ({$idsString})
        ");

        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        $imagenes = new Imagenes();

        while( $imagen = $stmt->fetch() ) {
            $imagenes->agregar(
                new Imagen($imagen['id'], $imagen['nombre'])
            );
        }

        return $imagenes;
    }

}
