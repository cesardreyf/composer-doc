<?php

namespace Repositorio\PDO\Locacion;

use Locacion\Contenedor\Locaciones;
use Locacion\Entidad\Locacion;
use Locacion\Interfaz\ILocacion;
use Locacion\Interfaz\ILocaciones;
use Locacion\Modulo\Obtencion\Interfaz\IRepositorioObtencion;
use PDO;
use Repositorio\PDO\Abstraccion\RepositorioBase;
use Repositorio\PDO\Excepcion\Excepcion;

class RepositorioDeObtencion extends RepositorioBase implements IRepositorioObtencion
{

    public function locacionExiste(int $id): bool
    {
        $stmt = $this->pdo->prepare('
            SELECT COUNT(*)
            FROM locaciones
            WHERE id = ?
            LIMIT 1
        ');

        $stmt->bindValue(1, $id, PDO::PARAM_INT);
        return $stmt->execute() && $stmt->fetchColumn() > 0;
    }

    /**
     * Obtiene una locación junto a las locaciones padres que pueda tener
     *
     * @param int $id Id de la locación a obtener
     *
     * @return ILocacion
     *
     * @throws Excepcion si no existe ninguna locación con el ID indicado
     */
    public function obtenerLocacionCompletaPorId(int $id): ILocacion
    {
        $stmt = $this->pdo->prepare('
            WITH RECURSIVE LocacionesCTE AS (
                SELECT id, nombre, padre, 1 AS nivel
                FROM locaciones
                WHERE id = ?
                UNION ALL
                SELECT l.id, l.nombre, l.padre, cte.nivel + 1
                FROM locaciones l
                INNER JOIN LocacionesCTE cte ON l.id = cte.padre
            )
            SELECT DISTINCT id, nombre, padre
            FROM LocacionesCTE
            ORDER BY nivel DESC
        ');

        $stmt->bindValue(1, $id, PDO::PARAM_INT);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

        if( !$stmt->execute() || $stmt->rowCount() < 1 ) {
            throw new Excepcion("No existe ninguna locación con el id {$id}");
        }

        $locacion = null;
        $locacionPadre = null;

        while( $datos = $stmt->fetch() ) {
            $locacion = new Locacion((int)$datos['id'], $datos['nombre'], $locacionPadre);
            $locacionPadre = $locacion;
        }

        return $locacion;
    }

    /**
     * Obtiene una lista de locaciones según el ID de la locación padre
     *
     * Devuelve un contenedor con todas las locaciones cuyo padre coincida con
     * el ID de la instancia de la locación pasada por argumento. Si se pasa un
     * valor **null** se obtendrán todas las locaciones con el padre 0.
     *
     * @param ?ILocacion $padre Instancia de la locación padre o null
     *
     * @return ILocaciones
     */
    public function obtenerLocacionesSegunPadre(?ILocacion $padre): ILocaciones
    {
        $idDeLaLocacionPadre = $padre?->id() ?? 0;

        $stmt = $this->pdo->prepare('
            SELECT id, nombre
            FROM locaciones
            WHERE padre = ?
        ');

        $stmt->bindValue(1, $idDeLaLocacionPadre, PDO::PARAM_INT);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

        if( !$stmt->execute() || $stmt->rowCount() < 1 ) {
            throw new Excepcion("No existe ninguna locación con el id {$idDeLaLocacionPadre}");
        }

        $contenedor = new Locaciones();
        while( $locacion = $stmt->fetch() ) {
            $contenedor->agregar(
                new Locacion(
                    (int)$locacion['id'],
                    $locacion['nombre'],
                    $padre
                )
            );
        }

        return $contenedor;
    }

    /**
     * Obtiene una lista de locaciones según el conjunto de ID solicitados
     *
     * @param int $id
     * @param int ...$ids
     *
     * @return ILocaciones
     */
    public function obtenerLocacionesSegunIds(int $id, int ...$ids): ILocaciones
    {
        array_unshift($ids, $id);
        $identificadores = implode(', ', $ids);

        $stmt = $this->pdo->prepare("
            WITH RECURSIVE LocacionesCTE AS (
                SELECT id, nombre, padre
                FROM locaciones
                WHERE id IN ({$identificadores})
                UNION ALL
                SELECT l.id, l.nombre, l.padre
                FROM locaciones l
                INNER JOIN LocacionesCTE cte ON l.id = cte.padre
            )
            SELECT DISTINCT id, nombre, padre
            FROM LocacionesCTE
        ");

        if( !$stmt->execute() ) {
            throw new Excepcion('Ocurrió un error durante la ejecución de la consulta SQL');
        }

        $cache = [];
        $locaciones = new Locaciones();
        $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach( $resultado as $locacion ) {
            $cache[$locacion['id']] = $locacion;
        }

        if( !empty($cache) ) {
            foreach( $ids as $idSolicitado ) {
                $locaciones->agregar($this->crearLocacionRecursivamente($idSolicitado, $cache));
            }
        }

        return $locaciones;
    }

    protected function crearLocacionRecursivamente(int $id, array &$datos): ?ILocacion
    {
        if( !isset($datos[$id]) ) {
            return null;
        }

        if( $datos[$id] instanceof Locacion ) {
            return $datos[$id];
        }

        $idPadre = $datos[$id]['padre'];
        $padre = $this->crearLocacionRecursivamente($idPadre, $datos);
        return $datos[$id] = new Locacion($datos[$id]['id'], $datos[$id]['nombre'], $padre);
    }

}
