<?php

    require '../aplicacion/iniciar.php';
