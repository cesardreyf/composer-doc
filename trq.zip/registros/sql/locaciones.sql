# Placeholder...

USE truequia;

# Países
INSERT IGNORE INTO locaciones (nombre, padre) VALUES
    ('Argentina', 0);

SELECT id INTO @pais_ar FROM locaciones WHERE nombre = 'Argentina' AND padre = 0;

# Provincias
INSERT IGNORE INTO locaciones (nombre, padre) VALUES
    ('Ciudad Autónoma de Buenos Aires (CABA)', @pais_ar),
    ('Buenos Aires', @pais_ar),
    ('Catamarca', @pais_ar),
    ('Chaco', @pais_ar),
    ('Chubut', @pais_ar),
    ('Córdoba', @pais_ar),
    ('Corrientes', @pais_ar),
    ('Entre Ríos', @pais_ar),
    ('Formosa', @pais_ar),
    ('Jujuy', @pais_ar),
    ('La Pampa', @pais_ar),
    ('La Rioja', @pais_ar),
    ('Mendoza', @pais_ar),
    ('Misiones', @pais_ar),
    ('Neuquén', @pais_ar),
    ('Río Negro', @pais_ar),
    ('Salta', @pais_ar),
    ('San Juan', @pais_ar),
    ('San Luis', @pais_ar),
    ('Santa Cruz', @pais_ar),
    ('Santa Fe', @pais_ar),
    ('Santiago del Estero', @pais_ar),
    ('Tierra del Fuego', @pais_ar),
    ('Tucumán', @pais_ar);

# Barrios de la Ciudad Autónoma de Buenos Aires
SELECT id INTO @caba FROM locaciones WHERE nombre = 'Ciudad Autónoma de Buenos Aires (CABA)' AND padre = @pais_ar;
INSERT IGNORE INTO locaciones (nombre, padre) VALUES
    ('Palermo', @caba),
    ('Recoleta', @caba),
    ('San Telmo', @caba),
    ('La Boca', @caba),
    ('Belgrano', @caba),
    ('Caballito', @caba),
    ('Balvanera', @caba),
    ('Almagro', @caba),
    ('Villa Crespo', @caba),
    ('Nuñez', @caba),
    ('Colegiales', @caba),
    ('Villa Urquiza', @caba),
    ('San Cristóbal', @caba),
    ('Boedo', @caba),
    ('Monserrat', @caba),
    ('Villa Lugano', @caba),
    ('Mataderos', @caba),
    ('Flores', @caba),
    ('Villa Devoto', @caba),
    ('Villa del Parque', @caba),
    ('Barracas', @caba),
    ('Villa Luro', @caba),
    ('Saavedra', @caba),
    ('Parque Chacabuco', @caba),
    ('Floresta', @caba),
    ('Villa Pueyrredón', @caba),
    ('Villa Santa Rita', @caba),
    ('Villa Riachuelo', @caba),
    ('Villa Soldati', @caba);
