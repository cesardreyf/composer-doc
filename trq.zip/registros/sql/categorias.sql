# Agrega las categorías

USE truequia;

INSERT IGNORE INTO categorias (alias, nombre) VALUES
    ('autos', 'Autos'),
    ('ropas', 'Indumentaria'),
    ('motos', 'Motos'),
    ('casas', 'Inmuebles'),
    ('muebles', 'Muebles'),
    ('otros', 'Otros');
