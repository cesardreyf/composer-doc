# Algunas etiquetas

INSERT IGNORE INTO etiquetas (nombre) VALUES
    ('Nuevo'),
    ('Usado'),
    ('Buen estado'),
    ('No sirve'),
    ('Roto'),
    ('VTV Vigente'),
    ('Dado de baja'),
    ('Sin uso'),
    ('Poco uso'),
    ('0Km'),
    ('Sin papeles');
