# Margof
Framework base para aplicaciones web que empleen la librería Gof.

## Errores y Excepciones

Hay que dar permisos a los archivos `registros/*.log`. Agregarlos al grupo www-data y darles permisos de escritura.
