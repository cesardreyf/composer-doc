<?php

declare(strict_types=1);

namespace Test\Gestor\Registro;

use Contrato\Registro\IRegistro;
use Gestor\Registro\GestorDeRegistro;
use Gof\Gestor\Registro\Mensajes\RegistroDeMensajes;
use PHPUnit\Framework\TestCase;

class GestorDeRegistroTest extends TestCase
{

    public function testImplementarContrato(): void
    {
        $this->assertInstanceOf(IRegistro::class, new GestorDeRegistro());
    }

    public function testExtenderDelGestorDeRegistroDeMensajesDeGof(): void
    {
        $this->assertInstanceOf(RegistroDeMensajes::class, new GestorDeRegistro());
    }

}
