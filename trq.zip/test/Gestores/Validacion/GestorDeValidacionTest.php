<?php

declare(strict_types=1);

namespace Test\Gestor\Validacion;

use Contrato\Componente\IComponente;
use Contrato\Componente\IEntidad;
use Contrato\Componente\IListaDeComponentes;
use Contrato\Registro\IRegistro;
use Contrato\Validacion\IValidable;
use Contrato\Validacion\IValidador;
use Gestor\Validacion\GestorDeValidacion;
use PHPUnit\Framework\TestCase;

class GestorDeValidacionTest extends TestCase
{

    public function setUp(): void
    {
        $this->registro = $this->createMock(IRegistro::class);
        $this->validador = new GestorDeValidacion($this->registro);
    }

    public function testImplementarElContrato(): void
    {
        $this->assertInstanceOf(IValidador::class, $this->validador);
    }

    /**
     * @dataProvider dataEstadosDeValidacion
     */
    public function testValidarComponenteDevuelveElValorDeLaValidacion(bool $valorEsperado): void
    {
        $componente = $this->createMock(IValidable::class);
        $componente
            ->expects($this->once())
            ->method('validar')
            ->with($this->registro)
            ->willReturn($valorEsperado);
        $this->assertSame($valorEsperado, $this->validador->validarComponente($componente));
    }

    public function dataEstadosDeValidacion(): array
    {
        return [[true], [false]];
    }

    public function testValidarComponentesDevuelveTrueSoloSiTodosSusComponentesSonValidos(): void
    {
        for($i = 0, $j = 3; $i < $j; $i++) {
            $componentes[$i] = $this->createMock(IValidable::class);
            $componentes[$i]
                ->method('validar')
                ->willReturn(true);
        }
        $this->registro
            ->expects($this->any())
            ->method('crearSubregistro')
            ->willReturn($this->createMock(IRegistro::class));
        $this->assertTrue($this->validador->validarComponentes(...$componentes));
    }

    public function testValidarComponentesSegregaLosMensajesDeErrorPorIdentificacion(): void
    {
        $j = 3;
        $identificadores = ['componente1', 'componente2', 'componente3'];
        for($i = 0; $i < $j; $i++) {
            $componentes[$i] = $this->createMock(IValidable::class);
            $componentes[$i]
                ->method('validar')
                ->willReturn(false);
            $componentes[$i]
                ->method('identificacion')
                ->willReturn($identificadores[$i]);
            $argumentosParaCrearElSubregistro[$i] = [$identificadores[$i]];
        }
        $this->registro
            ->expects($this->any())
            ->method('crearSubregistro')
            ->withConsecutive(...$argumentosParaCrearElSubregistro)
            ->willReturn($this->createMock(IRegistro::class));
        $this->registro
            ->method('hay')
            ->willReturn(true);
        $this->registro
            ->expects($this->once())
            ->method('guardar');
        $this->assertFalse($this->validador->validarComponentes(...$componentes));
    }

    public function testValidarComponentesDevuelveFalseSiUnaDeLasValidacionesFalla(): void
    {
        $j = 3;
        $elQueFalla = rand(0, $j - 1);
        for($i = 0; $i < $j; $i++) {
            $componentes[$i] = $this->createMock(IValidable::class);
            $componentes[$i]
                ->method('validar')
                ->willReturn($i == $elQueFalla ? false : true);
        }
        $this->registro
            ->expects($this->any())
            ->method('crearSubregistro')
            ->willReturn($this->createMock(IRegistro::class));
        $this->assertFalse($this->validador->validarComponentes(...$componentes));
    }

    public function testValidarEntidadDevuelveTrueSiNoTieneComponentes(): void
    {
        $entidad = $this->createMock(IEntidad::class);
        $entidad
            ->method('componentes')
            ->willReturn([]);
        $this->assertTrue($this->validador->validarEntidad($entidad));
    }

    public function testValidarEntidadObtieneLosComponentesValidablesDeLaEntidadYLlamaAlMetodoValidarComponentes(): void
    {
        $listaDeComponentesValidables = [
            $this->createMock(IValidable::class),
            $this->createMock(IValidable::class),
        ];
        $listaDeComponentes = array_merge($listaDeComponentesValidables, [
            $this->createMock(IComponente::class),
        ]);
        $entidad = $this->createMock(IEntidad::class);
        $entidad
            ->method('componentes')
            ->willReturn($listaDeComponentes);
        $validador = $this->getMockBuilder(GestorDeValidacion::class)
            ->disableOriginalConstructor()
            ->setMethodsExcept(['validarEntidad'])
            ->getMock();
        $validador
            ->expects($this->once())
            ->method('validarComponentes')
            ->with(...$listaDeComponentesValidables);
        $validador->validarEntidad($entidad);
    }

}
