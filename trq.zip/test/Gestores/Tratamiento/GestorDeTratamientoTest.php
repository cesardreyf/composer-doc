<?php

declare(strict_types=1);

namespace Test\Gestor\Tratamiento;

use Contrato\Componente\IComponente;
use Contrato\Componente\IEntidad;
use Contrato\Tratamiento\ITratable;
use Contrato\Tratamiento\ITratador;
use Gestor\Tratamiento\GestorDeTratamiento;
use PHPUnit\Framework\TestCase;

class GestorDeTratamientoTest extends TestCase
{

    public function testImplementarElContrato(): void
    {
        $this->assertInstanceOf(ITratador::class, new GestorDeTratamiento());
    }

    public function testAplicarTratamientoAlComponente(): void
    {
        $componente = $this->createMock(ITratable::class);
        $componente
            ->expects($this->once())
            ->method('tratar');
        $gestor = new GestorDeTratamiento();
        $gestor->tratarComponente($componente);
    }

    public function testAplicarTratamientoALosComponentes(): void
    {
        for($i = 0, $j = 3; $i < $j; $i++) {
            $componentes[$i] = $this->createMock(ITratable::class);
            $componentes[$i]
                ->expects($this->once())
                ->method('tratar');
        }
        $gestor = new GestorDeTratamiento();
        $gestor->tratarComponentes(...$componentes);
    }

    public function testValidarEntidadObtieneLosComponentesTratablesYLesAplicaElTratamiento(): void
    {
        $componentesTratables = [
            $this->createMock(ITratable::class),
            $this->createMock(ITratable::class),
            $this->createMock(ITratable::class),
        ];
        $listaDeComponentes = array_merge($componentesTratables, [
            $this->createMock(IComponente::class),
            $this->createMock(IComponente::class),
        ]);
        $entidad = $this->createMock(IEntidad::class);
        $entidad
            ->method('componentes')
            ->willReturn($listaDeComponentes);
        $gestor = $this->getMockBuilder(GestorDeTratamiento::class)
            ->setMethodsExcept(['tratarEntidad'])
            ->disableOriginalConstructor()
            ->getMock();
        $gestor
            ->expects($this->exactly(count($componentesTratables)))
            ->method('tratarComponente')
            ->withConsecutive(...array_map(function($componente) {
                return [$componente];
            }, $componentesTratables));
        $gestor->tratarEntidad($entidad);
    }

}
