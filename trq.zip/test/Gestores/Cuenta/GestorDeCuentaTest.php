<?php

declare(strict_types=1);

namespace Test\Gestor\Cuenta;

use Contrato\Registro\IRegistro;
use Contrato\Tratamiento\ITratador;
use Contrato\Validacion\IValidador;
use Cuenta\Modulo\Persistencia\Interfaz\ICuenta;
use Gestor\Cuenta\Comando\ComandoCrearCuenta;
use Gestor\Cuenta\GestorDeCuenta;
use Gestor\Cuenta\Interfaz\IRepositorioCuenta;
use PHPUnit\Framework\TestCase;

class GestorDeCuentaTest extends TestCase
{

    public $registro;
    public $repositorio;
    public $gestorDeValidacion;
    public $gestorDeTratamiento;
    public $gestorDeCuenta;

    public function setUp(): void
    {
        $this->registro = $this->createMock(IRegistro::class);
        $this->repositorio = $this->createMock(IRepositorioCuenta::class);
        $this->gestorDeValidacion = $this->createMock(IValidador::class);
        $this->gestorDeTratamiento = $this->createMock(ITratador::class);
        $this->gestorDeCuenta = $this->getMockBuilder(GestorDeCuenta::class)
            ->setConstructorArgs([$this->registro, $this->gestorDeValidacion, $this->gestorDeTratamiento, $this->repositorio])
            ->onlyMethods(['instanciar'])
            ->getMock();
    }

    public function testComandoCrearCuenta(): void
    {
        $clave = 'clave';
        $correo = 'correo';
        $usuario = 'usuario';
        $cuenta = $this->createMock(ICuenta::class);
        $comando = $this->createMock(ComandoCrearCuenta::class);
        $comando
            ->expects($this->once())
            ->method('obtenerCuenta')
            ->willReturn($cuenta);
        $this->gestorDeCuenta
            ->expects($this->once())
            ->method('instanciar')
            ->with(
                ComandoCrearCuenta::class,
                $usuario,
                $correo,
                $clave,
                $this->gestorDeValidacion,
                $this->gestorDeTratamiento,
                $this->repositorio
            )
            ->willReturn($comando);
        $this->assertSame($cuenta, $this->gestorDeCuenta->crearCuenta($usuario, $correo, $clave));
    }

}
