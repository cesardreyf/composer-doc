<?php

declare(strict_types=1);

namespace Test\Publicacion\Modulo\Persistencia\Entidad;

use Contrato\Componente\IEntidad;
use Contrato\Componente\IId;
use PHPUnit\Framework\TestCase;
use Publicacion\Interfaz\IPublicacion;
use Publicacion\Modulo\Persistencia\Entidad\PublicacionPersistible;
use Publicacion\Modulo\Persistencia\Propiedad\Descripcion;
use Publicacion\Modulo\Persistencia\Propiedad\Titulo;
use DateTime;

class PublicacionPersistibleTest extends TestCase
{

    private IId $identificador;
    private IId $autor;
    private Titulo $titulo;
    private Descripcion $descripcion;
    private DateTime $creacion;
    private IPublicacion $publicacion;

    public function setUp(): void
    {
        $this->identificador = $this->createMock(IId::class);
        $this->autor = $this->createMock(IId::class);
        $this->titulo = $this->createMock(Titulo::class);
        $this->descripcion = $this->createMock(Descripcion::class);
        $this->creacion = $this->createMock(DateTime::class);
        $this->publicacion = new PublicacionPersistible(
            $this->identificador,
            $this->autor,
            $this->titulo,
            $this->descripcion,
            $this->creacion
        );
    }

    public function testEsUnaEntidad(): void
    {
        $this->assertInstanceOf(IEntidad::class, $this->publicacion);
    }

    public function testImplementarInterfazDeLaPublicacion(): void
    {
        $this->assertInstanceOf(IPublicacion::class, $this->publicacion);
    }

    public function testComponentes(): void
    {
        $listaDeComponentes = $this->publicacion->componentes();
        $this->assertNotEmpty($listaDeComponentes);

        $componentesEsperados = [
            $this->titulo,
            $this->descripcion
        ];

        foreach( $componentesEsperados as $componente ) {
            $this->assertContains($componente, $listaDeComponentes);
        }
    }

    public function testObtenerTituloObtieneElValorDeLaPropiedadTitulo(): void
    {
        $titulo = 'abcdefghijklmnñopqrstuvwxyz';
        $this->titulo
            ->method('valor')
            ->willReturn($titulo);
        $this->assertSame($titulo, $this->publicacion->titulo());
    }

    public function testObtenerDescripcionObtieneElValorDeLaPropiedadDescipcion(): void
    {
        $descripcion = 'abcdefghijklmnñopqrstuvwxyzáéíóú';
        $this->descripcion
            ->method('valor')
            ->willReturn($descripcion);
        $this->assertSame($descripcion, $this->publicacion->descripcion());
    }

}
