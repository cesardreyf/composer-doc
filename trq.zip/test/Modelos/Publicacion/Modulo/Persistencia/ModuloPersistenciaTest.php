<?php

declare(strict_types=1);

namespace Test\Publicacion\Modulo\Persistencia;

use Componente\Identificador;
use DateTime;
use PHPUnit\Framework\TestCase;
use Publicacion\Entidad\Publicacion;
use Publicacion\Interfaz\IPublicacion;
use Publicacion\Modulo\Persistencia\Excepcion\ExcepcionErrorAlPersistir;
use Publicacion\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;
use Publicacion\Modulo\Persistencia\ModuloPersistencia;

class ModuloPersistenciaTest extends TestCase
{

    private IPublicacion $publicacion;
    private IRepositorioPersistencia $repositorio;

    public function setUp(): void
    {
        $this->repositorio = $this->createMock(IRepositorioPersistencia::class);
        $this->publicacion = new Publicacion(256, new Identificador(128), 'titulo', 'descripcion', new DateTime());
    }

    public function testPersistirUnaPublicacionDevuelveTrueSiElRepositorioLoAlmacenaCorrectamente(): void
    {
        $modulo = new ModuloPersistencia($this->repositorio);
        $this->repositorio
            ->expects($this->once())
            ->method('persistirPublicacion')
            ->with($this->publicacion)
            ->willReturn(true);
        $modulo->persistir($this->publicacion);
    }

    public function testLanzarExcepcionSiElRepositorioNoPuedeGuardarLaPublicacion(): void
    {
        $modulo = new ModuloPersistencia($this->repositorio);
        $this->repositorio
            ->expects($this->once())
            ->method('persistirPublicacion')
            ->with($this->publicacion)
            ->willReturn(false);
        $this->expectException(ExcepcionErrorAlPersistir::class);
        $modulo->persistir($this->publicacion);
    }

}
