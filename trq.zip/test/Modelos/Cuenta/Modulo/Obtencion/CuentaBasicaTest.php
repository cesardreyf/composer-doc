<?php

namespace Test\Cuenta\Modulo\Obtencion;

use Contrato\Componente\IId;
use Cuenta\Modulo\Obtencion\CuentaBasica;
use Cuenta\Modulo\Obtencion\Excepcion\ExcepcionCuentaInexistente;
use Cuenta\Modulo\Obtencion\Interfaz\IRepositorioObtencion;
use PHPUnit\Framework\TestCase;

class CuentaBasicaTest extends TestCase
{

    private $id;
    private $repositorio;

    protected function setUp(): void
    {
        $this->id = $this->createMock(IId::class);
        $this->repositorio = $this->createMock(IRepositorioObtencion::class);
    }

    public function testCuentaBasicaExiste()
    {
        $usuarioExistente = 'UsuarioPrueba';
        $correoExistente = 'correo@prueba.com';

        $this->repositorio->method('existe')->willReturn(true);
        $this->repositorio->method('obtenerUsuarioSegunId')->willReturn($usuarioExistente);
        $this->repositorio->method('obtenerCorreoSegunId')->willReturn($correoExistente);

        $cuentaBasica = new CuentaBasica($this->id, $this->repositorio);

        $this->assertInstanceOf(CuentaBasica::class, $cuentaBasica);
        $this->assertEquals($usuarioExistente, $cuentaBasica->usuario());
        $this->assertEquals($correoExistente, $cuentaBasica->correo());
    }

    public function testCuentaBasicaNoExiste()
    {
        $this->expectException(ExcepcionCuentaInexistente::class);
        $this->repositorio->method('existe')->willReturn(false);

        new CuentaBasica($this->id, $this->repositorio);
    }

}
