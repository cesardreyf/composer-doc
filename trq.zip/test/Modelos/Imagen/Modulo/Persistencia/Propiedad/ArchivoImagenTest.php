<?php

declare(strict_types=1);

namespace Test\Imagen\Modulo\Persistencia\Propiedad;

use Contrato\Componente\IComponente;
use Contrato\Tratamiento\ITratable;
use Contrato\Validacion\IValidable;
use Gof\Interfaz\Archivos\Carpeta;
use Imagen\Modulo\Persistencia\Propiedad\ArchivoImagen;
use PHPUnit\Framework\TestCase;

class ArchivoImagenTest extends TestCase
{

    private Carpeta $carpeta;

    public function setUp(): void
    {
        $this->carpeta = $this->createMock(Carpeta::class);
        $this->carpeta
            ->method('ruta')
            ->willReturn(__DIR__);
    }

    /**
     * @dataProvider dataEjemploDeFile
     */
    public function testEsUnComponente(array $file): void
    {
        $this->assertInstanceOf(IComponente::class, new ArchivoImagen($file, $this->carpeta));
    }

    /**
     * @dataProvider dataEjemploDeFile
     */
    public function testEsUnComponenteValidable(array $file): void
    {
        $this->assertInstanceOf(IValidable::class, new ArchivoImagen($file, $this->carpeta));
    }

    /**
     * @dataProvider dataEjemploDeFile
     */
    public function testEsUnComponenteTratable(array $file): void
    {
        $this->assertInstanceOf(ITratable::class, new ArchivoImagen($file, $this->carpeta));
    }

    /**
     * @dataProvider dataEjemploDeFile
     */
    public function testIdentificacionMutable(array $file): void
    {
        $archivo = new ArchivoImagen($file, $this->carpeta);
        $this->assertSame($archivo->identificacion, $archivo->identificacion());

        $archivo->identificacion = 'otro_nombre_cualquiera';
        $this->assertSame($archivo->identificacion, $archivo->identificacion());
    }

    /**
     * @dataProvider dataEjemploDeFile
     */
    public function testObtenerNombreDelFile(array $file): void
    {
        $archivo = new ArchivoImagen($file, $this->carpeta);
        $this->assertSame($file['name'], $archivo->nombre());
    }

    /**
     * @dataProvider dataEjemploDeFile
     */
    public function testObtenerRutaDelFile(array $file): void
    {
        $archivo = new ArchivoImagen($file, $this->carpeta);
        $this->assertSame($file['tmp_name'], $archivo->ruta());
    }

    // public function testComponentesValidables(array $file): void
    // {
    //     $archivo = new ArchivoImagen($file, $this->carpeta);
    //     print_r(get_class_methods($archivo));
    //     $this->assertNotEmpty($archivo->obtenerComponentes());
    // }

    public function dataEjemploDeFile(): array
    {
        return [[
            [
                'name' => 'ejemplo.png',
                'tmp_name' => __FILE__,
                'type' => 'image/png',
                'size' => 1024,
                'error' => 0,
            ]
        ]];
    }

}
