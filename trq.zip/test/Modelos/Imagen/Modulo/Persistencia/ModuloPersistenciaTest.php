<?php

declare(strict_types=1);

namespace Test\Imagen\Modulo\Persistencia;

use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;
use Imagen\Modulo\Persistencia\Excepcion\ExcepcionImagenesNoPersistidos;
use Imagen\Modulo\Persistencia\Excepcion\ExcepcionImagenNoPersistido;
use Imagen\Modulo\Persistencia\Interfaz\IRepositorioPersistencia;
use Imagen\Modulo\Persistencia\ModuloPersistencia;
use PHPUnit\Framework\TestCase;

class ModuloPersistenciaTest extends TestCase
{

    private ModuloPersistencia $modulo;
    private IRepositorioPersistencia $repositorio;

    public function setUp(): void
    {
        $this->imagen = $this->createMock(IImagen::class);
        $this->imagenes = $this->createMock(IImagenes::class);
        $this->repositorio = $this->createMock(IRepositorioPersistencia::class);
        $this->modulo = new ModuloPersistencia($this->repositorio);
    }

    public function testPersistirImagenNoDevuelveNingunValorSiSePersisteCorrectamente(): void
    {
        $this->repositorio
            ->expects($this->once())
            ->method('persistirImagen')
            ->willReturn(true);
        $this->assertNull($this->modulo->persistirImagen($this->imagen));
    }

    public function testPersistirImagenLanzaUnaExcepcionSiElRepositorioDevuelveFalse(): void
    {
        $this->repositorio
            ->expects($this->once())
            ->method('persistirImagen')
            ->willReturn(false);
        $this->expectException(ExcepcionImagenNoPersistido::class);
        $this->modulo->persistirImagen($this->imagen);
    }

    public function testPersistirImagenesNoDevuelveNingunValorSiSePersistenCorrectamente(): void
    {
        $this->repositorio
            ->expects($this->once())
            ->method('persistirImagenes')
            ->willReturn(true);
        $this->modulo->persistirImagenes($this->imagenes);
    }

    public function testPersistirImagenesLanzaUnaExcepcionSiElRepositorioDevuelveFalse(): void
    {
        $this->repositorio
            ->expects($this->once())
            ->method('persistirImagenes')
            ->willReturn(false);
        $this->expectException(ExcepcionImagenesNoPersistidos::class);
        $this->modulo->persistirImagenes($this->imagenes);
    }

}
