<?php

declare(strict_types=1);

namespace Test\Imagen\Modulo\Persistencia\Entidad;

use Imagen\Interfaz\IImagen;
use Imagen\Modulo\Persistencia\Entidad\ImagenPersistible;
use Imagen\Modulo\Persistencia\Propiedad\ArchivoImagen;
use PHPUnit\Framework\TestCase;
use Contrato\Componente\IEntidad;

class ImagenPersistibleTest extends TestCase
{

    private int $id;
    private ArchivoImagen $archivo;
    private ImagenPersistible $imagen;

    public function setUp(): void
    {
        $this->id = 0;
        $this->archivo = $this->createMock(ArchivoImagen::class);
        $this->imagen = new ImagenPersistible($this->id, $this->archivo);
    }

    public function testImplementaLaInterfaz(): void
    {
        $this->assertInstanceOf(IImagen::class, $this->imagen);
    }

    public function testEsUnaEntidad(): void
    {
        $this->assertInstanceOf(IEntidad::class, $this->imagen);
    }

    public function testAlmacerArchivoImagenComoComponenteDeLaEntidad(): void
    {
        $this->assertContains($this->archivo, $this->imagen->componentes());
    }

    public function testIdMutable(): void
    {
        $nuevoId = $this->id + rand();
        $this->assertSame($this->id, $this->imagen->id());
        $this->imagen->editarId($nuevoId);
        $this->assertSame($nuevoId, $this->imagen->id());
    }

    public function testFuncionNombreDevuelveElNombreDelArchivo(): void
    {
        $nombre = 'imagen.png';
        $this->archivo
            ->method('nombre')
            ->willReturn($nombre);
        $this->assertSame($nombre, $this->imagen->nombre());
    }

}
