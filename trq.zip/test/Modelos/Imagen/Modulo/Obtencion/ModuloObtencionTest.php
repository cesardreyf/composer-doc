<?php

declare(strict_types=1);

namespace Test\Imagen\Modulo\Obtencion;

use Imagen\Excepcion\ExcepcionImagenInexistente;
use Imagen\Interfaz\IImagen;
use Imagen\Interfaz\IImagenes;
use Imagen\Modulo\Obtencion\Interfaz\IRepositorioObtencion;
use Imagen\Modulo\Obtencion\ModuloObtencion;
use PHPUnit\Framework\TestCase;

class ModuloObtencionTest extends TestCase
{

    public IRepositorioObtencion $repositorio;

    public function setUp(): void
    {
        $this->repositorio = $this->createMock(IRepositorioObtencion::class);
    }

    public function testObtenerImagenSegunId(): void
    {
        $id = 666;
        $imagen = $this->createMock(IImagen::class);
        $modulo = new ModuloObtencion($this->repositorio);
        $this->repositorio
            ->method('imagenExisteSegunId')
            ->with($id)
            ->willReturn(true);
        $this->repositorio
            ->method('obtenerImagenSegunId')
            ->with($id)
            ->willReturn($imagen);
        $this->assertSame($imagen, $modulo->obtenerImagenSegunId($id));
    }

    public function testLanzarExcepcionAlObtenerUnaImagenInexistenteEnRepositorio(): void
    {
        $idInexistente = 0;
        $modulo = new ModuloObtencion($this->repositorio);
        $this->repositorio
            ->method('imagenExisteSegunId')
            ->with($idInexistente)
            ->willReturn(false);
        $this->expectException(ExcepcionImagenInexistente::class);
        $modulo->obtenerImagenSegunId($idInexistente);
    }

    public function testObtenerImagenesSegunIds(): void
    {
        $ids = [1, 2, 3];
        $imagenes = $this->createMock(IImagenes::class);
        $modulo = new ModuloObtencion($this->repositorio);
        $this->repositorio
            ->method('consultarExistenciaDeImagenesSegunId')
            ->with(...$ids)
            ->willReturn([]);
        $this->repositorio
            ->method('obtenerImagenesSegunId')
            ->with(...$ids)
            ->willReturn($imagenes);
        $this->assertSame($imagenes, $modulo->obtenerImagenesSegunId(...$ids));
    }

    public function testLanzarExcepcionAlObtenerImagenesInexistentes(): void
    {
        $ids = [1, 2, 3, 4, 5];
        $idsInexistentes = [4, 5];
        $modulo = new ModuloObtencion($this->repositorio);
        $this->repositorio
            ->method('consultarExistenciaDeImagenesSegunId')
            ->with(...$ids)
            ->willReturn($idsInexistentes);
        $this->expectException(ExcepcionImagenInexistente::class);
        $modulo->obtenerImagenesSegunId(...$ids);
    }

}
