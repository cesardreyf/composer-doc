<?php

declare(strict_types=1);

namespace Test\Componente\Seguridad;

use Componente\Seguridad\Clave;
use PHPUnit\Framework\TestCase;

class ClaveTest extends TestCase
{

    public function testCifrarGeneraUnHashDiferenteALaClave(): void
    {
        $clave = 'contraseña123';
        $hash = Clave::cifrar($clave);
        $this->assertNotSame($clave, $hash);
    }

    public function testCifrarDevuelveUnHashDiferenteEnCadaNuevoCifradoAunqueLaClaveSeaIgual(): void
    {
        $hashes = [];
        $clave = 'la.misma.de.siempre';
        for($i = 0, $j = 3; $i < 3; $i++) {
            $hash = Clave::cifrar($clave);
            $this->assertNotContains($hash, $hashes);
            $hashes[] = $hash;
        }
    }

    public function testValidarClaveDevuelveTrueSiLaClaveEsLaMismaConLaCualSeGeneroElHash(): void
    {
        $clave = 'messi.chiquito';
        $hash = Clave::cifrar($clave);
        $this->assertTrue(Clave::validar($clave, $hash));
    }

}
