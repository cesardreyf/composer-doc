<?php

declare(strict_types=1);

namespace Test\Componente\Tratamiento\Archivo\Imagen;

use Componente\Tratamiento\Archivo\Imagen\LimpiarMetadatos;
use PHPUnit\Framework\TestCase;
use RuntimeException;

class LimpiarMetadatosTest extends TestCase
{

    public function testHacerAlgunTest(): void
    {
        $rutaDeLaImagen = 'ejemplo.png';
        $componente = new LimpiarMetadatos($rutaDeLaImagen);
        $this->assertTrue(true);
    }

}
