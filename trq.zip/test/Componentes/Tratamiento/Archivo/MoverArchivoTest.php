<?php

declare(strict_types=1);

namespace Test\Componente\Tratamiento\Archivo;

use Componente\Tratamiento\Archivo\MoverArchivo;
use PHPUnit\Framework\TestCase;
use RuntimeException;

class MoverArchivoTest extends TestCase
{

    public function testLanzarExcepcionSiSeIntentaMoverUnArchivoNoSubido(): void
    {
        $carpetaDestino = __DIR__;
        $rutaDelArchivo = __FILE__;
        $nombreDelArchivo = pathinfo($rutaDelArchivo, PATHINFO_FILENAME);
        $componente = new MoverArchivo($nombreDelArchivo, $rutaDelArchivo, $carpetaDestino);
        $this->expectException(RuntimeException::class);
        $componente->tratar();
    }

}
