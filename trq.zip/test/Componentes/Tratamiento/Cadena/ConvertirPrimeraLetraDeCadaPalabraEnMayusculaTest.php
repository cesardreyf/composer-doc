<?php

declare(strict_types=1);

namespace Test\Componente\Tratamiento\Cadena;

use Componente\Tratamiento\Cadena\ConvertirPrimeraLetraDeCadaPalabraEnMayuscula;
use PHPUnit\Framework\TestCase;

class ConvertirPrimeraLetraDeCadaPalabraEnMayusculaTest extends TestCase
{

    /**
     * @dataProvider dataCadenasTratablesYSusResultadosEsperados
     */
    public function testAplicaElTratamientoEsperadoALaCadenaPorReferencia(string $cadena, string $resultado): void
    {
        $tratamiento = new ConvertirPrimeraLetraDeCadaPalabraEnMayuscula($cadena);
        $tratamiento->tratar();
        $this->assertSame($resultado, $cadena);
    }

    public function dataCadenasTratablesYSusResultadosEsperados(): array
    {
        return [
            ['algo bobo como dado este fofo', 'Algo Bobo Como Dado Este Fofo'],
            ['  con espacios a los laos   ', '  Con Espacios A Los Laos   '],
            ['índice ñoño', 'Índice Ñoño'],
        ];
    }

}
