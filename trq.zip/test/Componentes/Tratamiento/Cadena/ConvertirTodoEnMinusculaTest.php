<?php

declare(strict_types=1);

namespace Test\Componente\Tratamiento\Cadena;

use Componente\Tratamiento\Cadena\ConvertirTodoEnMinuscula;
use PHPUnit\Framework\TestCase;

class ConvertirTodoEnMinusculaTest extends TestCase
{

    /**
     * @dataProvider dataCadenasTratablesYSusResultadosEsperados
     */
    public function testAplicaElTratamientoEsperadoALaCadenaPorReferencia(string $cadena, string $resultado): void
    {
        $tratamiento = new ConvertirTodoEnMinuscula($cadena);
        $tratamiento->tratar();
        $this->assertSame($resultado, $cadena);
    }

    public function dataCadenasTratablesYSusResultadosEsperados(): array
    {
        return [
            ['ABCDEFGHIJKLMNÑOPQRSTUVWXYZ', 'abcdefghijklmnñopqrstuvwxyz'],
            ['ÁÉÍÓÚÜ', 'áéíóúü'],
            ['MeZcLaDo', 'mezclado'],
        ];
    }

}
