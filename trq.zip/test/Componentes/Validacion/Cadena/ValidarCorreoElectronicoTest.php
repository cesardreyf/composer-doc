<?php

declare(strict_types=1);

namespace Test\Componente\Validacion\Cadena;

use Componente\Validacion\Cadena\ValidarCorreoElectronico;
use PHPUnit\Framework\TestCase;
use Contrato\Registro\IRegistro;
use Contrato\Componente\IComponenteValidable;

class ValidarCorreoElectronicoTest extends TestCase
{
    public IRegistro $registro;

    public function setUp(): void
    {
        $this->registro = $this->createMock(IRegistro::class);
    }

    public function testImplementarContratoIComponenteValidable(): void
    {
        $this->assertInstanceOf(IComponenteValidable::class, new ValidarCorreoElectronico(''));
    }

    /**
     * @dataProvider dataCorreosValidos
     */
    public function testValidarCorreosElectronicosValidosDevuelveTrue(string $correo): void
    {
        $this->registro
            ->expects($this->never())
            ->method('agregarMensaje');
        $this->registro
            ->expects($this->never())
            ->method('preparar');
        $validacion = new ValidarCorreoElectronico($correo);
        $this->assertTrue($validacion->validar($this->registro));
    }

    public function dataCorreosValidos(): array
    {
        return [
            ['un@correo.com'],
        ];
    }

    /**
     * @dataProvider dataCorreosInvalidos
     */
    public function testValidarCorreosElectronicosInvalidosDevuelveFalseYRegistraUnMensajeDeError(string $correo): void
    {
        $this->registro
            ->expects($this->once())
            ->method('agregarMensaje')
            ->with(ValidarCorreoElectronico::ERROR_MENSAJE);
        $validacion = new ValidarCorreoElectronico($correo);
        $this->assertFalse($validacion->validar($this->registro));
    }

    public function dataCorreosInvalidos(): array
    {
        return [
            ['un.correo-invalido,com'],
            ['correo@ñoño.com'],
        ];
    }

}
