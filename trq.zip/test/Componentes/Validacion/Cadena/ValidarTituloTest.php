<?php

declare(strict_types=1);

namespace Test\Componente\Validacion\Cadena;

use Componente\Validacion\Cadena\ValidarTitulo;
use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;
use PHPUnit\Framework\TestCase;

class ValidarTituloTest extends TestCase
{

    public IRegistro $registro;

    public function setUp(): void
    {
        $this->registro = $this->createMock(IRegistro::class);
    }

    /**
     * @dataProvider dataCadenasValidas
     */
    public function testValidarCadenaValidaDevuelveTrue(string $cadena): void
    {
        $componente = new ValidarTitulo($cadena);
        $this->registro
            ->expects($this->never())
            ->method('agregarMensaje');
        $this->registro
            ->expects($this->never())
            ->method('preparar');
        $this->assertTrue($componente->validar($this->registro));
    }

    public function dataCadenasValidas(): array
    {
        return [
            ['abcdefghijklmnñopqrstuvwxyz0123456789áéíóúü¿?¡!.,\'"/°$%&() '],
            ['ABCDEFGHIJKLMNÑOPQRSTUVWXYZ0123456789ÁÉÍÓÚÜ¿?¡!.,\'"/°$%&() '],
        ];
    }

    /**
     * @dataProvider dataCadenasInvalidas
     */
    public function testValidarCadenaInvalidaDevuelveFalseYRegistraUnMensajeDeError(string $cadena): void
    {
        $componente = new ValidarTitulo($cadena);
        $this->registro
            ->expects($this->once())
            ->method('agregarMensaje')
            ->with(ValidarTitulo::ERROR_MENSAJE);
        $this->assertFalse($componente->validar($this->registro));
    }

    public function dataCadenasInvalidas(): array
    {
        return [
            [''],
            // mas
        ];
    }

}
