<?php

declare(strict_types=1);

namespace Test\Componente\Validacion\Cadena;

use Componente\Validacion\Cadena\ValidarQueContieneAlMenosUnCaracterEnMayuscula;
use Contrato\Registro\IRegistro;
use PHPUnit\Framework\TestCase;

class ValidarQueContieneAlMenosUnCaracterEnMayusculaTest extends TestCase
{
    public IRegistro $registro;

    public function setUp(): void
    {
        $this->registro = $this->createMock(IRegistro::class);
    }

    /**
     * @dataProvider dataCadenasQueSiContienenAlMenosUnCaracterEnMayuscula
     */
    public function testValidarDevuelveTrue(string $cadena): void
    {
        $this->registro
            ->expects($this->never())
            ->method('agregarMensaje');
        $this->registro
            ->expects($this->never())
            ->method('preparar');
        $validacion = new ValidarQueContieneAlMenosUnCaracterEnMayuscula($cadena);
        $this->assertTrue($validacion->validar($this->registro));
    }

    public function dataCadenasQueSiContienenAlMenosUnCaracterEnMayuscula(): array
    {
        return [
            ['letrA'],
            ['mayÚscula'],
        ];
    }

    /**
     * @dataProvider dataCadenasQueNoContienenAlMenosUnCaracterEnMayuscula
     */
    public function testValidarDevuelveFalse(string $cadena): void
    {
        $this->registro
            ->expects($this->once())
            ->method('agregarMensaje')
            ->with(ValidarQueContieneAlMenosUnCaracterEnMayuscula::ERROR_MENSAJE);
        $validacion = new ValidarQueContieneAlMenosUnCaracterEnMayuscula($cadena);
        $this->assertFalse($validacion->validar($this->registro));
    }

    public function dataCadenasQueNoContienenAlMenosUnCaracterEnMayuscula(): array
    {
        return [
            ['minuscula'],
            ['123'],
            ['!"#$'],
        ];
    }

}
