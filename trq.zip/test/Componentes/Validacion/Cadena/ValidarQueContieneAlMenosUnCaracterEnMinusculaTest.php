<?php

declare(strict_types=1);

namespace Test\Componente\Validacion\Cadena;

use Componente\Validacion\Cadena\ValidarQueContieneAlMenosUnCaracterEnMinuscula;
use Contrato\Registro\IRegistro;
use PHPUnit\Framework\TestCase;

class ValidarQueContieneAlMenosUnCaracterEnMinusculaTest extends TestCase
{
    public IRegistro $registro;

    public function setUp(): void
    {
        $this->registro = $this->createMock(IRegistro::class);
    }

    /**
     * @dataProvider dataCadenasQueSiContienenAlMenosUnCaracterEnMinuscula
     */
    public function testValidarDevuelveTrue(string $cadena): void
    {
        $this->registro
            ->expects($this->never())
            ->method('agregarMensaje');
        $this->registro
            ->expects($this->never())
            ->method('preparar');
        $validacion = new ValidarQueContieneAlMenosUnCaracterEnMinuscula($cadena);
        $this->assertTrue($validacion->validar($this->registro));
    }

    public function dataCadenasQueSiContienenAlMenosUnCaracterEnMinuscula(): array
    {
        return [
            ['aLFONSO'],
            ['áNGEL'],
        ];
    }

    /**
     * @dataProvider dataCadenasQueNoContienenAlMenosUnCaracterEnMinuscula
     */
    public function testValidarDevuelveFalse(string $cadena): void
    {
        $this->registro
            ->expects($this->once())
            ->method('agregarMensaje')
            ->with(ValidarQueContieneAlMenosUnCaracterEnMinuscula::ERROR_MENSAJE);
        $validacion = new ValidarQueContieneAlMenosUnCaracterEnMinuscula($cadena);
        $this->assertFalse($validacion->validar($this->registro));
    }

    public function dataCadenasQueNoContienenAlMenosUnCaracterEnMinuscula(): array
    {
        return [
            ['MAYUSCULA'],
            ['123'],
            ['!"#$'],
        ];
    }

}
