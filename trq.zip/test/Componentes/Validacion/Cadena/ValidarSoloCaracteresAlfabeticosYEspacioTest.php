<?php

declare(strict_types=1);

namespace Test\Componente\Validacion\Cadena;

use Componente\Validacion\Cadena\ValidarSoloCaracteresAlfabeticosYEspacio;
use Contrato\Componente\IComponenteValidable;
use Contrato\Registro\IRegistro;
use PHPUnit\Framework\TestCase;

class ValidarSoloCaracteresAlfabeticosYEspacioTest extends TestCase
{
    public IRegistro $registro;

    public function setUp(): void
    {
        $this->registro = $this->createMock(IRegistro::class);
    }

    /**
     * @dataProvider dataCadenasValidas
     */
    public function testValidarCadenaValidaDevuelveTrue(string $cadena): void
    {
        $validacion = new ValidarSoloCaracteresAlfabeticosYEspacio($cadena);
        $this->registro
            ->expects($this->never())
            ->method('agregarMensaje');
        $this->registro
            ->expects($this->never())
            ->method('preparar');
        $this->assertTrue($validacion->validar($this->registro));
    }

    public function dataCadenasValidas(): array
    {
        return [
            ['alguien'],
            ['una cadena con espacios'],
            ['español válido'],
            ['CadEna ValiDo'],
            ['    cadena con espacios a los laos    '],
            ['abcdefghijklmnñopqrstuvwxyz'],
            ['áéíóú'],
            ['Agüero'],
        ];
    }

    /**
     * @dataProvider dataCadenasInvalidas
     */
    public function testValidarCadenaInvalidaDevuelveFalseYRegistraUnMensajeDeError(string $cadena): void
    {
        $validacion = new ValidarSoloCaracteresAlfabeticosYEspacio($cadena);
        $this->registro
            ->expects($this->once())
            ->method('agregarMensaje')
            ->with(ValidarSoloCaracteresAlfabeticosYEspacio::ERROR_MENSAJE);
        $this->assertFalse($validacion->validar($this->registro));
    }

    public function dataCadenasInvalidas(): array
    {
        return [
            ['c4d3na 1nv4lid0'],
        ];
    }

}
