<?php

declare(strict_types=1);

namespace Test\Componente\Validacion\Cadena;

use Componente\Validacion\Cadena\ValidarQueContieneAlMenosUnCaracterEspecial;
use Contrato\Registro\IRegistro;
use PHPUnit\Framework\TestCase;

class ValidarQueContieneAlMenosUnCaracterEspecialTest extends TestCase
{
    public IRegistro $registro;

    public function setUp(): void
    {
        $this->registro = $this->createMock(IRegistro::class);
    }

    /**
     * @dataProvider dataCadenasQueSiContienenAlMenosUnCaracterEspecial
     */
    public function testValidarDevuelveTrue(string $cadena): void
    {
        $this->registro
            ->expects($this->never())
            ->method('agregarMensaje');
        $this->registro
            ->expects($this->never())
            ->method('preparar');
        $validacion = new ValidarQueContieneAlMenosUnCaracterEspecial($cadena);
        $this->assertTrue($validacion->validar($this->registro));
    }

    public function dataCadenasQueSiContienenAlMenosUnCaracterEspecial(): array
    {
        return [
            [',.!"#$%&/()=?¡¿\'+-{}[]_@'],
            ['alguien!'],
            ['!"#$'],
            ['.'],
        ];
    }

    /**
     * @dataProvider dataCadenasQueNoContienenAlMenosUnCaracterEspecial
     */
    public function testValidarDevuelveFalse(string $cadena): void
    {
        $this->registro
            ->expects($this->once())
            ->method('agregarMensaje')
            ->with(ValidarQueContieneAlMenosUnCaracterEspecial::ERROR_MENSAJE);
        $validacion = new ValidarQueContieneAlMenosUnCaracterEspecial($cadena);
        $this->assertFalse($validacion->validar($this->registro));
    }

    public function dataCadenasQueNoContienenAlMenosUnCaracterEspecial(): array
    {
        return [
            ['1234567890'],
            ['abcdefghijklmnñopqrstuvwxyz'],
        ];
    }

}
