<?php

declare(strict_types=1);

namespace Test\Cadena\Validar;

use Componente\Validacion\Cadena\ValidarLongitudLimitado;
use Contrato\Registro\IRegistro;
use Gof\Contrato\Registro\Mensajes\MensajeVinculante;
use PHPUnit\Framework\TestCase;

class ValidarLongitudLimitadoTest extends TestCase
{

    public function setUp(): void
    {
        $this->registro = $this->createMock(IRegistro::class);
    }

    /**
     * @dataProvider dataCadenasConLongitudMinimoIncumplidos
     */
    public function testValidarLongitudMinimoIncumplidoReportaElErrorAlRegistoYDevuelveFalse(string $cadena, int $longitudMinimoPermitido, int $longitudMaximoPermitido): void
    {
        $validacion = new ValidarLongitudLimitado($cadena, $longitudMinimoPermitido, $longitudMaximoPermitido);
        $mensajeVinculante = $this->createMock(MensajeVinculante::class);
        $mensajeVinculante
            ->expects($this->once())
            ->method('vincular')
            ->with(1, $longitudMinimoPermitido);
        $mensajeVinculante
            ->expects($this->once())
            ->method('guardar');
        $this->registro
            ->expects($this->once())
            ->method('preparar')
            ->with(ValidarLongitudLimitado::ERROR_LONGITUD_MINIMO_INCUMPLIDO)
            ->willReturn($mensajeVinculante);
        $this->assertFalse($validacion->validar($this->registro));
    }

    public function dataCadenasConLongitudMinimoIncumplidos(): array
    {
        return [
            ['algo', 5, 10],
        ];
    }

    /**
     * @dataProvider dataCadenasConLongitudMaximoExcedido
     */
    public function testValidarLongitudMaximoExcedidoReportaElErrorAlRegistoYDevuelveFalse(string $cadena, int $longitudMinimoPermitido, int $longitudMaximoPermitido): void
    {
        $validacion = new ValidarLongitudLimitado($cadena, $longitudMinimoPermitido, $longitudMaximoPermitido);
        $mensajeVinculante = $this->createMock(MensajeVinculante::class);
        $mensajeVinculante
            ->expects($this->once())
            ->method('vincular')
            ->with(1, $longitudMaximoPermitido);
        $mensajeVinculante
            ->expects($this->once())
            ->method('guardar');
        $this->registro
            ->expects($this->once())
            ->method('preparar')
            ->with(ValidarLongitudLimitado::ERROR_LONGITUD_MAXIMO_EXCEDIDO)
            ->willReturn($mensajeVinculante);
        $this->assertFalse($validacion->validar($this->registro));
    }

    public function dataCadenasConLongitudMaximoExcedido(): array
    {
        return [
            ['cinco', 1, 4],
        ];
    }

    /**
     * @dataProvider dataCadenasConLongitudValidas
     */
    public function testValidarDevuelveTrueSiEstaDentroDelRangoEstablecido(string $cadena, int $longitudMinimoPermitido, int $longitudMaximoPermitido): void
    {
        $validacion = new ValidarLongitudLimitado($cadena, $longitudMinimoPermitido, $longitudMaximoPermitido);
        $this->registro
            ->expects($this->never())
            ->method('agregarMensaje');
        $this->registro
            ->expects($this->never())
            ->method('preparar');
        $this->assertTrue($validacion->validar($this->registro));
    }

    public function dataCadenasConLongitudValidas(): array
    {
        return [
            ['ala', 1, 3],
        ];
    }

}
