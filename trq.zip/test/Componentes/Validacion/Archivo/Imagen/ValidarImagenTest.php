<?php

declare(strict_types=1);

namespace Test\Componente\Validacion\Archivo\Imagen;

use Componente\Validacion\Archivo\Imagen\ValidarImagen;
use Gestor\Registro\GestorDeRegistro;
use PHPUnit\Framework\TestCase;
use RuntimeException;

class ValidarImagenTest extends TestCase
{

    public GestorDeRegistro $registro;

    public function setUp(): void
    {
        $this->registro = new GestorDeRegistro();
    }

    public function testValidarLanzaUnaExcepcionSiElArchivNoExiste(): void
    {
        $componente = new ValidarImagen(__DIR__ . '/archivo_inexistente.extension');
        $this->expectException(RuntimeException::class);
        $componente->validar($this->registro);
    }

}
