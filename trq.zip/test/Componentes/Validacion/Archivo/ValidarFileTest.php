<?php

declare(strict_types=1);

namespace Test\Componente\Validacion\Archivo;

use Componente\Validacion\Archivo\ValidarFile;
use PHPUnit\Framework\TestCase;
use InvalidArgumentException;

class ValidarFileTest extends TestCase
{

    public function setUp(): void
    {
    }

    /**
     * @dataProvider dataEjemploDeFile
     */
    public function testLanzarExcepcionSiMaxsizeEsUnNumeroNegativo(array $file): void
    {
        $numeroNegativo = rand(PHP_INT_MIN, 0);
        $this->expectException(InvalidArgumentException::class);
        new ValidarFile(file: $file, maxsize: $numeroNegativo, extensiones: []);
    }

    public function dataEjemploDeFile(): array
    {
        return [
            [[
                'name' => 'prueba.jpg',
                'type' => 'image/jpeg',
                'size' => 1024,
                'tmp_name' => '/tmp/prueba.jpg',
                'error' => UPLOAD_ERR_OK,
            ]]
        ];
    }

}
